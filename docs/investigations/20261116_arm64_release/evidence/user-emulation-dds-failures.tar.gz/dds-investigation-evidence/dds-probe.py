import os,sys,time,json,subprocess
os.environ.update(ROS_DOMAIN_ID='193',ROS_LOCALHOST_ONLY=os.environ.get('PROBE_LOCALHOST','1'),RMW_IMPLEMENTATION='rmw_fastrtps_cpp')
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile,ReliabilityPolicy
from px4_msgs.msg import VehicleStatus
mode=sys.argv[1]
rclpy.init(args=[]);node=Node('arm_dds_'+mode)
qos=QoSProfile(depth=10,reliability=ReliabilityPolicy.BEST_EFFORT)
counts={'sent':0,'received':0};child=None
if mode in ('single','pub'):
 pub=node.create_publisher(VehicleStatus,'/arm_probe',qos)
if mode in ('single','sub','dual'):
 def recv(m):counts['received']+=1
 sub=node.create_subscription(VehicleStatus,'/arm_probe',recv,qos)
if mode=='dual':child=subprocess.Popen([sys.executable,__file__,'pub'])
start=time.monotonic()
while time.monotonic()-start<float(os.environ.get('PROBE_SECONDS','8')):
 if mode in ('single','pub'):
  pub.publish(VehicleStatus(timestamp=node.get_clock().now().nanoseconds//1000));counts['sent']+=1
 rclpy.spin_once(node,timeout_sec=.02)
 time.sleep(.02)
print(json.dumps(dict(mode=mode,counts=counts,publishers=node.count_publishers('/arm_probe'),subscribers=node.count_subscribers('/arm_probe'),env={k:os.environ.get(k) for k in ('FASTRTPS_DEFAULT_PROFILES_FILE','ROS_LOCALHOST_ONLY')})),flush=True)
if child:child.wait(timeout=15)
node.destroy_node();rclpy.shutdown()
