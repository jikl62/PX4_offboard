#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <string.h>
int main(void){int fd=socket(AF_INET,SOCK_DGRAM,0);struct in_addr addr={.s_addr=inet_addr("127.0.0.1")};int r=setsockopt(fd,IPPROTO_IP,IP_MULTICAST_IF,&addr,sizeof(addr));printf("setsockopt=%d errno=%d %s\n",r,errno,strerror(errno));return r?1:0;}
