import socket,struct
for data in (socket.inet_aton('127.0.0.1'),socket.inet_aton('0.0.0.0')+socket.inet_aton('127.0.0.1'),socket.inet_aton('0.0.0.0')+socket.inet_aton('127.0.0.1')+struct.pack('i',1)):
 s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
 try:s.setsockopt(socket.IPPROTO_IP,socket.IP_MULTICAST_IF,data);print('OK',len(data))
 except Exception as e:print('FAIL',len(data),repr(e))
 s.close()
