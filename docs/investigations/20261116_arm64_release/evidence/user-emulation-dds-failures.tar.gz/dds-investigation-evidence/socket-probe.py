import socket,subprocess,sys,time,json,os,struct
mode=sys.argv[1];multicast=mode.startswith('multi');address='239.255.0.1' if multicast else '127.0.0.1';port=55931
if mode.endswith('send'):
 s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
 if multicast:s.setsockopt(socket.IPPROTO_IP,socket.IP_MULTICAST_IF,socket.inet_aton('127.0.0.1'))
 for _ in range(10):s.sendto(b'arm udp proof',(address,port));time.sleep(.1)
 print('SENT',mode,os.getpid(),flush=True)
else:
 s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('',port));s.settimeout(5)
 if multicast:s.setsockopt(socket.IPPROTO_IP,socket.IP_ADD_MEMBERSHIP,socket.inet_aton(address)+socket.inet_aton('127.0.0.1'))
 p=subprocess.Popen([sys.executable,__file__,'multi-send' if multicast else 'uni-send']);received=0
 try:
  for _ in range(10):
   data,addr=s.recvfrom(4096);received+=1
 except Exception as e:print('ERROR',repr(e),flush=True)
 print(json.dumps(dict(mode=mode,received=received,pid=os.getpid())),flush=True);p.wait()
