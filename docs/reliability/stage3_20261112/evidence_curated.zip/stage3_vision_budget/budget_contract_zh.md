# 视觉身份应用层预算（功能修复，独立于等价重构）

统一上限为每字段 **256 UTF-8 字节**，不是256个Unicode字符。来源包括 source_id、frame_id、body_frame_id、angular_velocity_source、原始 Odometry 坐标名、extrinsics_id、alignment_id，以及仅用于诊断的 relocalization_id。空可选字段仍由原有效位/协议决定；必填身份仍必须非空。所有身份拒绝嵌入NUL与非法UTF-8，不能截断后当成合法来源。

依据：已有纯C++速度预览已限制source_id为256字节，已有Python诊断限制256字符；本次统一为原有更紧的字节合同并补齐生产视觉路径。256字节保留常见UUID、设备/会话/标定版本字符串及普通Unicode短标签。此值是工程约定的资源上限，不是由ARM64性能实测推导出的实时阈值，视觉同学必须确认实际标识符合该合同。消息包、Topic、.msg字段类型与schema_version均不变；普通合格V1消息可直接通信。较长多字节ID、NUL和非法Unicode此前可能被接受，现在明确拒绝，属于有意兼容范围收紧。

C++ ROS字段映射先借用字符串检查，再复制到纯核心值；未通过的值只保留本机无效标记，不复制原文。Inbox拒绝时保留上一次有界来源/坐标/reset与序号水位，避免清空身份后把同源回退序号误认作新来源；测量和有效位均撤销。Inbox借用输入，在复制/序号去重之前检查；即使零序号/迟到/重复的超限包也撤销当前缓存，增加本机revocation_generation。随后的同周期健康包不清除该历史，已有活动视觉任务走原控制器的NAVIGATION_INPUT_REVOKED/降落锁存。初次准备可等待后续新合格输入，没有新增Arm/Offboard或动力权限。直接纯核心控制器和离线预览也检查相同预算。

Python检查先用字符数做O(1)快速拒绝，然后最多编码256个字符；原始巨大字符串不会因UTF-8计数而产生等长编码副本。诊断文本仅保留最多256 UTF-8字节，完整原文从不用于原因拼接。Validator在epoch事件/转换/深拷贝之前检查raw/health；拒绝撤销当前缓存但不推进可信历史。速度诊断拒绝撤销候选，保留异常证据与原有可信水位。

同目录vision_resource_budget.py为Python唯一实现，随CMake安装；C++头文件提供不分配的UTF-8扫描，跨语言回归检查预算常量与边界。ROS/DDS反序列化可能在应用回调之前已经为原始字符串分配内存；本修复不提供线上报文上限、进程总内存配额、拒绝服务防护或严格CPU/实时保证。将.msg改为bounded string会改变ROS类型身份，因此没有混入本轮。

每份State最多4个身份、Command最多2个身份，因此复制后的身份正文各自最多1024/512字节（不含std::string容量、容器/数字字段及分配器开销）。原始健康消息最多6个身份，即1536字节正文。日志JSON转义还可能扩大单字段到约6倍字节，日志原有总文件预算继续生效。原始配对队列长度/QoS是另一项既有容量合同，本次不暗改其阈值。

## 可复核实证

resource_probe_and_diff.cpp分别编译f06715a和当前生产头文件。基线保存两个各1MiB来源且active=true；当前保存0字节来源、generation=2并以NAVIGATION_COMMAND_IDENTITY_RESOURCE_LIMIT拒绝。纯C++12场景、2400完整Result/当前资格记录（含ASCII和4字节Unicode的精确256字节边界）633192字节逐字节相同，容差0。实际PythonValidator/Receiver的80条完整规范JSON记录264740字节相同，涵盖正常、重复、显式invalid、跟踪丢失、恢复。

新C++回归用单线程operator new监视实际ROS映射/Inbox/Session：输入字符串在开启监视前建立，对各个1MiB身份拒绝时没有任何>=4096字节的新分配。它验证本层不复制巨长身份，不代表DDS从未分配。新Python回归覆盖每个raw/health字段、迟到撤销、防重放历史不增长、Unicode精确字节边界、NUL/代理项、日志预算与恢复。受影响97项Python和3个C++程序通过；新预算程序ASan/UBSan通过，参数和原始日志在旁边JSON中。

独立审查发现并修复了本轮预算初稿的回归：直接清空Inbox身份会让seq10→异常包→同源seq1被误认为新来源。现在保留先前有界身份及水位；原独立探针rolled_back_sequence_accepted由true变为false，cached_sequence保持10、valid_fields=0。该问题在本轮提交前修复，不冒称基线f067已有同一实现。新状态/命令双路回归还验证seq10重复不续鲜、seq11恢复，以及真正新source/reset保留原合同。
