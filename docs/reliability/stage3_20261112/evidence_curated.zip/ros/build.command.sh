set -eo pipefail
source /opt/ros/humble/setup.bash
source /home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs/share/px4_msgs/local_setup.bash
colcon --log-base /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/log build --base-paths /home/jikl62/FC01_OrangePi_Navigation_20261028/native/src --packages-select jikl_fc01_system --build-base /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/build --install-base /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/install --event-handlers console_direct+ --parallel-workers 2 --cmake-args -DCMAKE_BUILD_TYPE=Release -DPython3_EXECUTABLE=/usr/bin/python3 -DPYTHON_EXECUTABLE=/usr/bin/python3 -DBUILD_TESTING=OFF
