set -eo pipefail
source /opt/ros/humble/setup.bash
source /home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs/share/px4_msgs/local_setup.bash
source /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/install/local_setup.bash
/usr/bin/python3 /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/verify_install_semantic.py /home/jikl62/FC01_OrangePi_Navigation_20261028 /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/install /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/install_semantic_verification.json
/usr/bin/python3 tests/benchmark_vision_interfaces.py --samples 3000 --output /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/host_performance.json
