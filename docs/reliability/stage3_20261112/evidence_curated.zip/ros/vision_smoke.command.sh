set -eo pipefail
source /opt/ros/humble/setup.bash
source /home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs/share/px4_msgs/local_setup.bash
source /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/install/local_setup.bash
export ROS_LOCALHOST_ONLY=1 ROS_DOMAIN_ID=231
/usr/bin/python3 /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/isolated_precheck.py
/usr/bin/python3 /home/jikl62/FC01_OrangePi_Navigation_20261028/tests/ros_vision_smoke.py --adapter /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/install/jikl_fc01_system/lib/jikl_fc01_system/vision_odometry_adapter.py --check-resource-budget --report /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/vision_smoke.json
