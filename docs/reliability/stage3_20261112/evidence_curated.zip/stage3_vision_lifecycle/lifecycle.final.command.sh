set -eo pipefail
source /opt/ros/humble/setup.bash
source /home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs/share/px4_msgs/local_setup.bash
source /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/install/local_setup.bash
export ROS_DOMAIN_ID=229
export ROS_LOCALHOST_ONLY=1
/usr/bin/python3 /home/jikl62/.cache/fc01-chinese-20261111/ros/clean-20261111T134428Z-54710/check_domain.py /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/stage3_vision_lifecycle/lifecycle.final.preflight.json
/usr/bin/python3 /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/stage3_vision_lifecycle/real_lifecycle_probe.py /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/ros/install/jikl_fc01_system/lib/jikl_fc01_system/vision_odometry_adapter.py /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/stage3_vision_lifecycle/lifecycle.final.report.json
