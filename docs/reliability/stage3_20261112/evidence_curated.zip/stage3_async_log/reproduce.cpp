#include "jikl_fc01_system/async_log.hpp"
#include <cassert>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <pthread.h>
#include <dlfcn.h>
static std::atomic<bool> block_sink{false}, sink_entered{false};
extern "C" ssize_t __real_write(int,const void*,std::size_t);
extern "C" ssize_t __wrap_write(int fd,const void* data,std::size_t n){
 if(fd==STDOUT_FILENO&&block_sink.load()){sink_entered.store(true);while(block_sink.load())std::this_thread::yield();}
 return __real_write(fd,data,n);
}
static int fcntl_failure = -1;
static bool thread_failure = false;
static thread_local bool allocation_failure = false;
void* operator new(std::size_t size) {
  if (allocation_failure) {
    allocation_failure = false;
    throw std::bad_alloc();
  }
  if (void* p = std::malloc(size ? size : 1)) return p;
  throw std::bad_alloc();
}
void operator delete(void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
extern "C" int __real_fcntl(int, int, ...);
extern "C" int __wrap_fcntl(int fd, int command, ...) {
  int value=0;
  if (command == F_SETFL) { va_list args;va_start(args,command);value=va_arg(args,int);va_end(args); }
  if(fd==STDOUT_FILENO&&command==fcntl_failure){fcntl_failure=-1;errno=EIO;return -1;}
  return command==F_SETFL?__real_fcntl(fd,command,value):__real_fcntl(fd,command);
}
extern "C" int pthread_create(pthread_t* thread,const pthread_attr_t* attr,void*(*start)(void*),void* arg){
  if(thread_failure){thread_failure=false;return EAGAIN;}
  using Create=int(*)(pthread_t*,const pthread_attr_t*,void*(*)(void*),void*);
  static auto original=reinterpret_cast<Create>(dlsym(RTLD_NEXT,"pthread_create"));
  if(!original)return EINVAL;
  return original(thread,attr,start,arg);
}
void marker(int) {}
int main(int argc,char** argv){
 assert(argc==2);
 const std::string scenario=argv[1];
 if(scenario=="getfl"||scenario=="setfl"||scenario=="thread"){
  struct sigaction previous{},wanted{},after{};wanted.sa_handler=marker;sigemptyset(&wanted.sa_mask);assert(sigaction(SIGPIPE,&wanted,&previous)==0);
  int flags=fcntl(STDOUT_FILENO,F_GETFL);assert(flags>=0);if(scenario=="getfl")fcntl_failure=F_GETFL;else if(scenario=="setfl")fcntl_failure=F_SETFL;else thread_failure=true;
  bool caught=false;try {fc01::AsyncLog log;}catch(const std::exception&){caught=true;}
  assert(caught);assert(sigaction(SIGPIPE,nullptr,&after)==0);int actual=fcntl(STDOUT_FILENO,F_GETFL);
  std::fprintf(stderr,"scenario=%s flags_restored=%d signal_restored=%d\n",scenario.c_str(),actual==flags,after.sa_handler==marker);
  fcntl(STDOUT_FILENO,F_SETFL,flags);sigaction(SIGPIPE,&previous,nullptr);
  return 0;
 }
 if(scenario=="sync"||scenario=="destructor"){
  int nullfd=open("/dev/null",O_WRONLY);assert(nullfd>=0);assert(dup2(nullfd,STDOUT_FILENO)>=0);close(nullfd);
  block_sink.store(true);sink_entered.store(false);auto* log=new fc01::AsyncLog;std::string record(1024,'x');
  std::cout.write(record.data(),record.size()).flush();while(!sink_entered.load())std::this_thread::yield();
  bool fired=false;auto before=fc01::native_log_dropped.load();
  for(int i=0;i<128&&!fired;++i){std::cout.write(record.data(),record.size());allocation_failure=true;std::cout.flush();fired=!allocation_failure;allocation_failure=false;}
  std::fprintf(stderr,"scenario=sync allocation_fired=%d stream_good=%d drops=%llu\n",fired,bool(std::cout),fc01::native_log_dropped.load()-before);
  std::cout.clear();
  if(scenario=="destructor"){
   std::cout.write(record.data(),record.size());std::thread release([]{std::this_thread::sleep_for(std::chrono::milliseconds(2));block_sink.store(false);});allocation_failure=true;delete log;allocation_failure=false;release.join();
  }else{block_sink.store(false);delete log;}
  return 0;
 }
 fc01::AsyncLog log;
 auto before=fc01::native_log_dropped.load();
 std::string record(40000,'x');
 allocation_failure=true;
 std::cout.write(record.data(),record.size());
 bool fired=!allocation_failure;allocation_failure=false;
 std::fprintf(stderr,"scenario=append allocation_fired=%d stream_good=%d drops=%llu\n",fired,bool(std::cout),fc01::native_log_dropped.load()-before);
 std::cout.clear();
}
