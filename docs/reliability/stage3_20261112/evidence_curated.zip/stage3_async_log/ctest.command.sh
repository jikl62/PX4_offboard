set -euo pipefail
cmake -S /home/jikl62/FC01_OrangePi_Navigation_20261028/native/tests -B /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/stage3_async_log/build -DCMAKE_BUILD_TYPE=Debug
cmake --build /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/stage3_async_log/build --target test_stage3_async_log_resources test_async_log -j2
ctest --test-dir /home/jikl62/.cache/fc01-stage3-20261112/run-jv6ltzrw/stage3_async_log/build -R '^(test_stage3_async_log_resources|test_async_log)$' --output-on-failure
