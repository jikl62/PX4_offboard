from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
r=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028');out=Path(__file__).parent;source=r/'native/tests/test_async_log.cpp';exe=out/'test_async_log_tsan';cmd=['g++','-std=c++17','-O1','-g','-fno-omit-frame-pointer','-fsanitize=thread','-pthread','-Wall','-Wextra','-Werror','-pedantic','-I'+str(r/'native/src/jikl_fc01_system/include'),str(source),'-o',str(exe)];record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compile_command':cmd,'run_command':[str(exe)],'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'production_header_sha256':hashlib.sha256((r/'native/src/jikl_fc01_system/include/jikl_fc01_system/async_log.hpp').read_bytes()).hexdigest(),'passed':False}
try:
 with (out/'tsan.compile.log').open('wb') as log:c=subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 record['compile_exit']=c.returncode
 if c.returncode==0:
  with (out/'tsan.run.log').open('wb') as log:c=subprocess.run([str(exe)],cwd=r,stdout=log,stderr=subprocess.STDOUT,timeout=60)
  record['run_exit']=c.returncode;record['stdout_stderr']=(out/'tsan.run.log').read_text(errors='replace');record['passed']=c.returncode==0
except subprocess.TimeoutExpired as exc:record['timeout_seconds']=exc.timeout
record['runtime_supported']=record['passed'] or 'unexpected memory mapping' not in record.get('stdout_stderr','');record['qualification']='Only return code 0 would count as passed; failed runtime initialization is no race-safety evidence.';(out/'tsan_summary.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
