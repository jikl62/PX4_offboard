from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
OUT=Path(__file__).parent
INCLUDE=ROOT/'native/src/jikl_fc01_system/include'
programs=['test_stage3_publication_combinations','test_stage3_state_invariants','test_stage2_runtime_trace','test_receive_events','test_publication_runtime','test_runtime_history_capacity']
base=['g++','-std=c++17','-O1','-g','-fno-omit-frame-pointer','-fno-pie','-no-pie','-fsanitize=address,undefined','-pthread','-Wall','-Wextra','-Werror','-pedantic','-I'+str(INCLUDE)]
env={**os.environ,'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
files=sorted(list(INCLUDE.rglob('*.hpp'))+list((ROOT/'native/tests').glob('test_*.cpp')))
def snapshot():return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
before=snapshot();(OUT/'source_hashes.json').write_text(json.dumps(before,indent=2)+'\n')
summary={'compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'ASan + UBSan','environment':{k:env[k] for k in ('ASAN_OPTIONS','UBSAN_OPTIONS')},'results':[],'independent_programs':len(programs),'counts_exclude_async_and_budget_programs':True}
for name in programs:
 source=ROOT/'native/tests'/f'{name}.cpp';exe=OUT/name;cmd=base+[str(source),'-o',str(exe)]
 rec={'name':name,'compile_command':cmd,'run_command':[str(exe)],'compile_timeout_seconds':180,'run_timeout_seconds':60,'source_sha256':before[str(source.relative_to(ROOT))]};start=time.monotonic()
 try:
  with (OUT/f'{name}.compile.log').open('wb') as log:r=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  rec['compile_exit']=r.returncode
  if r.returncode==0:
   with (OUT/f'{name}.run.log').open('wb') as log:r=subprocess.run([str(exe)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=60)
   rec['run_exit']=r.returncode
   data=(OUT/f'{name}.run.log').read_bytes();rec['log_sha256']=hashlib.sha256(data).hexdigest();rec['log_bytes']=len(data)
 except subprocess.TimeoutExpired as error:rec['timed_out']=error.timeout
 rec['wall_seconds']=round(time.monotonic()-start,3);summary['results'].append(rec);(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(rec),flush=True)
 if rec.get('compile_exit')!=0 or rec.get('run_exit')!=0:break
summary['passed_programs']=sum(r.get('compile_exit')==0 and r.get('run_exit')==0 for r in summary['results']);summary['source_changed_during_run']=[n for n,h in before.items() if snapshot().get(n)!=h];summary['all_passed']=summary['passed_programs']==len(programs) and not summary['source_changed_during_run'];(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'passed':summary['passed_programs'],'all_passed':summary['all_passed'],'source_changed':summary['source_changed_during_run']}),flush=True)
