set -eo pipefail
source /opt/ros/humble/setup.bash
source /home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs/share/px4_msgs/local_setup.bash
source /home/jikl62/.cache/fc01-chinese-20261111/ros/clean-20261111T134428Z-54710/install/local_setup.bash
/usr/bin/python3 /home/jikl62/.cache/fc01-chinese-20261111/ros/clean-20261111T134428Z-54710/check_domain.py /home/jikl62/.cache/fc01-chinese-20261111/ros/clean-20261111T134428Z-54710/domain_172.json
