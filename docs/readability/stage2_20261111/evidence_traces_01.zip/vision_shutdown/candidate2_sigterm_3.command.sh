set -eo pipefail
source /opt/ros/humble/setup.bash
source /home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs/share/px4_msgs/local_setup.bash
source /home/jikl62/.cache/fc01-chinese-20261111/ros/clean-20261111T134428Z-54710/install/local_setup.bash
/usr/bin/python3 /home/jikl62/.cache/fc01-chinese-20261111/ros/clean-20261111T134428Z-54710/check_domain.py /home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/vision_shutdown/candidate2_sigterm_3.preflight.json
/usr/bin/python3 /home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/vision_shutdown/ros_vision_sigterm_smoke.py --adapter /home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/vision_shutdown/candidate2/vision_odometry_adapter.py --report /home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/vision_shutdown/candidate2_sigterm_3.report.json
