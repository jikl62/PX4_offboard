from pathlib import Path
p=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028/native/tools/vision_odometry_adapter.py')
s=p.read_text()
main_start=s.index('def main(args=None):\n')
class_start=s.index('    class OdometryAdapterNode(Node):\n',main_start)
lifecycle_start=s.index('    # ROS 的异步信号处理会先关闭 context',class_start)
class_text=s[class_start:lifecycle_start].rstrip()
ctor_start=class_text.index('        def __init__(self):\n')
ctx_start=class_text.index('        def source_context(self):\n')
ctor=class_text[ctor_start:ctx_start]
clock_start=ctor.index("            if self.get_parameter('use_sim_time').value:\n")
config_start=ctor.index('            # 没有通用的相机坐标或安装默认值')
topic_start=ctor.index("            input_topic, health_topic = parameter('input_topic', ''), parameter('health_topic', '')")
out_start=ctor.index("            output_topic = parameter('output_topic', '/fc01/vision/state')")
qos_start=ctor.index('            def qos(reliable):\n')
pub_start=ctor.index('            # 只发布 FC01 实际状态消息')
links_start=ctor.index('            # 每个回调都重新观察本机时间')
log_start=ctor.index('            self.get_logger().info(\n')
parameter_start=ctor.index('            def parameter(name, default):\n')
parameter_end=clock_start
parameter=ctor[parameter_start:parameter_end]
parameter=parameter.replace('            def parameter(name, default):','        def startup_parameter(self, name, default):')
parameter='\n'.join(line[4:] if line.startswith('                ') else line for line in parameter.splitlines())
parameter=parameter.replace('        def startup_parameter','        def startup_parameter',1)
# 参数方法比原局部函数少一级缩进；手工构造以避免隐藏闭包。
parameter='''        def startup_parameter(self, name, default):
            """声明一个启动只读参数并返回其值；name/default 原样交给 ROS，不做隐式转换。

            副作用是按构造调用顺序声明参数；必须在创建对应端点前完成，运行时不能续改标定或时钟。
            """
            return self.declare_parameter(
                name,
                default,
                descriptor=ParameterDescriptor(
                    read_only=True,
                    description='Startup-only adapter configuration; restart to change.',
                ),
            ).value
'''
clock=ctor[clock_start:config_start]
config=ctor[config_start:topic_start].replace('parameter(', 'self.startup_parameter(')
topics=ctor[topic_start:out_start].replace('parameter(', 'self.startup_parameter(')
qos=ctor[qos_start:pub_start]
qos=qos.replace('            def qos(reliable):','        def qos(self, depth, reliable):')
qos='\n'.join(line[4:] if line.startswith('                ') else line for line in qos.splitlines())
# 首行函数缩进已经指定，函数体还原为 12 空格。
qos='''        def qos(self, depth, reliable):
            """按给定队列深度和可靠性构造 QoS；返回新配置，不修改节点或保存历史消息。

            depth 已先通过 [1,1000] 校验；VOLATILE 与可靠性选择保持原接口合同。
            """
            return QoSProfile(
                depth=depth,
                durability=DurabilityPolicy.VOLATILE,
                reliability=(
                    ReliabilityPolicy.RELIABLE if reliable else ReliabilityPolicy.BEST_EFFORT
                ),
            )
'''
links=ctor[links_start:log_start].replace("qos(parameter('odometry_reliable', False))", "self.qos(depth, self.startup_parameter('odometry_reliable', False))").replace("qos(parameter('health_reliable', True))", "self.qos(depth, self.startup_parameter('health_reliable', True))")
constructor='''        def __init__(self):
            """按时钟→标定→话题/QoS→输出→配对器→输入的原顺序创建适配节点。

            无输入参数或返回值；持有发布器、订阅、定时器和配对状态。必须在 rclpy.init 后调用，
            首个回调只能在 main 注册 executor 后运行；本节点永不创建飞控控制端点。
            """
            super().__init__('fc01_vision_odometry_adapter')
            self.configure_measurement_clock()
            self.load_conversion_config()
            input_topic, health_topic = self.input_topics()
'''+ctor[out_start:qos_start].replace('parameter(', 'self.startup_parameter(')+ctor[pub_start:links_start].replace("qos(parameter('output_reliable', False))", "self.qos(depth, self.startup_parameter('output_reliable', False))").replace('parameter(', 'self.startup_parameter(')+'''            self.connect_inputs(input_topic, health_topic, depth)
'''+ctor[log_start:]
constructor=constructor.replace('self.startup_self.startup_parameter(', 'self.startup_parameter(')
helpers='''
'''+parameter+'''
        def configure_measurement_clock(self):
            """拒绝模拟时钟并固定系统测量时钟描述符；无返回值，仅修改参数描述符。

            在读取标定和创建端点之前执行；不将单调等待时间解释成 ROS 测量时间。
            """
'''+clock+'''
        def load_conversion_config(self):
            """按原字段次序读取显式坐标/外参并校验，成功后保存在 self.config；无返回值。

            米制 NED/FRD 和 wxyz 约定由 AdapterConfig 验证；缺项仍用 NaN 拒绝，不填充虚构标定。
            必须先完成时钟检查，失败时仍在创建任何数据端点之前抛出原异常。
            """
'''+config+'''
        def input_topics(self):
            """声明并返回 (Odometry, Health) 输入话题；只声明参数，缺一项则按原文本拒绝。

            此步骤在标定验证后、输出话题与 QoS 参数前执行，保持首个错误及声明顺序。
            """
'''+topics+'''            return input_topic, health_topic

'''+qos+'''
        def connect_inputs(self, input_topic, health_topic, depth):
            """按 Odometry→Health→超时定时器次序建立输入，保存三个句柄；无返回值。

            输入参数是已校验的话题和队列深度。self.adapter/publisher/话题状态必须先存在；
            回调逐次重新取单调秒、ROS 纳秒和来源数，不能缓存来源授权或改变撤销事件顺序。
            """
'''+links
class_text=class_text[:ctor_start]+constructor.rstrip()+ '\n\n'+helpers.rstrip()+'\n\n'+class_text[ctx_start:]
emit_start=class_text.index('        def emit(self, states):\n')
emit=class_text[emit_start:]
body_start=emit.index('                message = VisionState()\n')
publish_start=emit.index('                self.publisher.publish(message)\n')
log_body=emit[emit.index('                if converted.reason != self.last_reason:\n'):]
message_body=emit[body_start:publish_start]
message_body='\n'.join(line[4:] for line in message_body.splitlines())
log_body='\n'.join(line[4:] for line in log_body.splitlines())
class_text=class_text[:emit_start]+'''        def state_message(self, converted):
            """将一个已转换状态映射成 VisionState；返回新消息，不发布、不修改配对或日志状态。

            测量/撤销观察时间仍按整数纳秒拆分；字段、有效位和 NaN 原样保留，不能在输出层补有效性。
            """
'''+message_body+'''
            return message

        def report_reason_change(self, converted):
            """仅在原因变化时记录原日志文本，成功写日志后更新 last_reason；无返回值。

            必须在该状态消息发布后调用，日志节流不允许删去撤销消息；日志异常仍原样暴露。
            """
'''+log_body+'''

        def emit(self, states):
            """按输入顺序发布每个转换/撤销状态，再记录原因变化；无返回值。

            states 由配对/来源监控产生；本函数只更新发布器与 last_reason，不授予飞行控制权限。
            消息映射→实际发布→原因日志的顺序与异常传播保持不变。
            """
            for converted in states:
                self.publisher.publish(self.state_message(converted))
                self.report_reason_change(converted)
'''
factory='''def _adapter_node_type():
    """延迟加载 ROS 并返回适配节点类；无参数，不创建节点、上下文或通信端点。

    可在纯转换模块导入后按需调用；返回类必须在 main 初始化 ROS 后实例化。
    将启动配置、端点接线与逐状态输出分开，但保留其原有执行先后顺序。
    """
    from rclpy.node import Node
    from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
    from rcl_interfaces.msg import ParameterDescriptor, ParameterType
    from nav_msgs.msg import Odometry
    from jikl_fc01_system.msg import VisionHealth, VisionState

'''+class_text+'''
    return OdometryAdapterNode


def main(args=None):
    """以可选 ROS 命令行 args 运行适配器；正常停止无返回值，非停止异常继续向上传播。

    仅此入口持有节点、executor 和临时信号处理器。SIGINT/SIGTERM 只请求停止，
    先结束当前回调，再移出/销毁节点、关闭 context、恢复调用者的处理器。
    100 ms 只是空闲 executor 等待上限，不是包含回调/清理的硬实时退出保证。
    """
    import signal

    import rclpy
    from rclpy.executors import ExternalShutdownException
    from rclpy.signals import SignalHandlerOptions

    OdometryAdapterNode = _adapter_node_type()

'''
s=s[:main_start]+factory+s[lifecycle_start:]
s=s.replace('            # 秒为单调等待上限，不改变输入的 ROS 测量时间；空闲时也能在 100 ms 内观察停止。','            # 100 ms 只是空闲等待上限；已开始的回调和清理耗时不属于硬实时保证。')
p.write_text(s)
