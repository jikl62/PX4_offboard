import importlib.util,json,pathlib,sys
from unittest.mock import patch
import rclpy
from rclpy.node import Node
from rclpy.exceptions import InvalidHandle
source=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2])
spec=importlib.util.spec_from_file_location('stage2_startup_resource_adapter',source);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
nodes=[];destroyed=[]
original_init=Node.__init__;original_destroy=Node.destroy_node

def remember_init(node,*args,**kwargs):
 original_init(node,*args,**kwargs);nodes.append(node)

def remember_destroy(node):
 destroyed.append(node);return original_destroy(node)

error=None
with patch.object(Node,'__init__',remember_init),patch.object(Node,'destroy_node',remember_destroy):
 try:module.main([])
 except ValueError as exc:error=str(exc)
assert error=='explicit source_id is required'
assert len(nodes)==1
assert not rclpy.ok()
try:
 name=nodes[0].get_name();handle_usable=True
except InvalidHandle:
 name=None;handle_usable=False
report={'source':str(source),'startup_error':error,'base_node_created':len(nodes),'explicit_destroy_calls':len(destroyed),'context_closed':not rclpy.ok(),'handle_usable_after_main':handle_usable,'node_name':name,'qualification':'Retained reference for probe; proves missing explicit destroy, not quantified permanent memory leak.'}
# 探针持有对象后显式清理，不把探针引用保留到下一轮。
original_destroy(nodes[0])
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
