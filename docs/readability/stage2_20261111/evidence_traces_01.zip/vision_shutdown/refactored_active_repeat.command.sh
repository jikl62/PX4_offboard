set -eo pipefail
source /opt/ros/humble/setup.bash
source /home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs/share/px4_msgs/local_setup.bash
source /home/jikl62/.cache/fc01-chinese-20261111/ros/clean-20261111T134428Z-54710/install/local_setup.bash
/usr/bin/python3 /home/jikl62/.cache/fc01-chinese-20261111/ros/clean-20261111T134428Z-54710/check_domain.py /home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/vision_shutdown/refactored_active_repeat.preflight.json
/usr/bin/python3 /home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/vision_shutdown/active_and_repeat_probe.py /home/jikl62/FC01_OrangePi_Navigation_20261028/native/tools/vision_odometry_adapter.py /home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/vision_shutdown/refactored_active_repeat.report.json
