from pathlib import Path
import hashlib, io, json, zipfile, zlib
BASE=Path(__file__).parent
ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
DOC=ROOT/'docs/readability/stage2_20261111'
old=json.loads((BASE/'evidence_index_before_final.json').read_text())
omit_names={
 'vision_shutdown/powered_node/powered-node-baseline-full.log',
 'vision_shutdown/powered_node/powered-node-current-full.log',
 'cpp_control/pre_full_lifecycle_trace_baseline.log',
 'cpp_control/pre_full_lifecycle_trace_current.log',
 'cpp_control/sanitizers/pre_full_lifecycle_test_stage2_control_trace.run.log',
 'cpp_control/trace_baseline_initial.log',
 'cpp_control/node_metrics_after_2luj7gzm/adapter_under_test.cpp',
 'cpp_control/node_metrics_before_0w6r0j_f/adapter_under_test.cpp',
}
# Cache originals remain; only intermediate successes and temporary source copies leave the curated deliverable.
contents={}
omitted={}
for name,entry in old['members'].items():
 p=BASE/name
 if p.is_file(): data=p.read_bytes()
 else:
  with zipfile.ZipFile(DOC/entry['archive']) as z: data=z.read(entry.get('alias_of',name))
 assert hashlib.sha256(data).hexdigest()==entry['sha256'], name
 if name in omit_names:
  omitted[name]={'sha256':entry['sha256'],'bytes':len(data),'reason':('Unfiltered startup and runtime chatter; complete compared POWERED state and sink records retained in archive. Original unfiltered stdout remains in execution cache.' if 'powered-node-' in name else 'Superseded successful intermediate trace or generated temporary source; original retained in execution cache, final traces and metrics included.')}
 else: contents[name]=data
for name in ('final-python-root-accepted.log','packaging-final.log','final-delivery-review.json','package_evidence.py','git_remote_final_check.json'):
 p=BASE/name
 if p.is_file(): contents[name]=p.read_bytes()
unique={}; members={}
for name,data in sorted(contents.items()):
 sha=hashlib.sha256(data).hexdigest()
 if sha in unique: members[name]={'sha256':sha,'alias_of':unique[sha],'bytes':len(data)}
 else: unique[sha]=name;members[name]={'sha256':sha,'bytes':len(data)}
groups=[[]];estimate=0
for name,entry in members.items():
 if 'alias_of' in entry:continue
 size=len(zlib.compress(contents[name],9))+len(name)*2+180
 if groups[-1] and estimate+size>850000:groups.append([]);estimate=0
 groups[-1].append(name);estimate+=size
outputs={};metadata={}
for i,names in enumerate(groups):
 archive='evidence.zip' if i==0 else f'evidence_traces_{i:02d}.zip'
 bio=io.BytesIO()
 with zipfile.ZipFile(bio,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name in names:
   info=zipfile.ZipInfo(name,(2026,11,11,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
   z.writestr(info,contents[name],compresslevel=9);members[name]['archive']=archive
 data=bio.getvalue();assert len(data)<1024*1024,(archive,len(data))
 outputs[archive]=data
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  assert z.testzip() is None
  for name in z.namelist():assert z.read(name)==contents[name]
 metadata[archive]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'unique_members':len(names)}
for name,entry in members.items():
 if 'alias_of' in entry:entry['archive']=members[entry['alias_of']]['archive']
for archive,data in outputs.items():(DOC/archive).write_bytes(data)
for path in DOC.glob('evidence*.zip'):
 if path.name not in outputs:path.unlink()
index={'format':'ZIP members with SHA256; identical bytes stored once, alias_of points to canonical member','archives':metadata,'members':members,'omitted_intermediate_artifacts':omitted}
(DOC/'evidence_index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archives':metadata,'logical_paths':len(members),'unique_members':len(unique),'omitted':len(omitted)},indent=2))
