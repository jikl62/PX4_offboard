import importlib.util,json,pathlib,signal,sys
import rclpy
from rclpy.executors import SingleThreadedExecutor
from rclpy.exceptions import InvalidHandle
from rclpy.signals import get_current_signal_handlers_options,SignalHandlerOptions
adapter=pathlib.Path(sys.argv[1]);output=pathlib.Path(sys.argv[2])
spec=importlib.util.spec_from_file_location('stage2_vision_adapter_active_probe',adapter);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
params=dict(input_topic='/fc01_demo/odom',health_topic='/fc01_demo/health',output_topic='/fc01_demo/state',source_id='synthetic-active-exception',input_frame_id='demo_enu',input_body_frame_id='demo_flu',world_convention='ENU',body_convention='FLU',extrinsics_id='synthetic-identity',alignment_id='synthetic-identity',body_from_sensor_wxyz='[1.0,0.0,0.0,0.0]',sensor_position_body_frd='[0.0,0.0,0.0]',world_alignment_wxyz='[1.0,0.0,0.0,0.0]',world_translation_ned='[0.0,0.0,0.0]')
args=['--ros-args']
for name,value in params.items():args+=['-p',name+':='+value]
report=dict(passed=False,adapter_path=str(adapter),control_node_started=False,fmu_publishers_created=False,cycles=[])
original_spin_once=SingleThreadedExecutor.spin_once
previous={signum:signal.getsignal(signum) for signum in (signal.SIGINT,signal.SIGTERM)}
node_holder=[]
cycle=0

def injected_callback(executor,*,timeout_sec):
 node=executor.get_nodes()[0];node_holder.append(node)
 assert rclpy.ok() and get_current_signal_handlers_options()==SignalHandlerOptions.NO
 assert timeout_sec==0.1
 if cycle==0:raise RuntimeError('ACTIVE_CONTEXT_PROBE_MUST_PROPAGATE')
 for signum in (signal.SIGINT,signal.SIGTERM,signal.SIGINT):
  signal.getsignal(signum)(signum,None)
  assert rclpy.ok(), 'handler prematurely closed context'

SingleThreadedExecutor.spin_once=injected_callback
try:
 for cycle in range(11):
  if cycle==0:
   try:module.main(args)
   except RuntimeError as exc:assert str(exc)=='ACTIVE_CONTEXT_PROBE_MUST_PROPAGATE',repr(exc)
   else:raise AssertionError('active RuntimeError was swallowed')
  else:module.main(args)
  assert not rclpy.ok()
  try:node_holder[-1].get_name()
  except InvalidHandle:destroyed=True
  else:destroyed=False
  assert destroyed
  assert all(signal.getsignal(signum) is previous[signum] for signum in previous)
  report['cycles'].append(dict(cycle=cycle,active_error_propagated=cycle==0,context_closed=True,node_destroyed=True,handlers_restored=True))
 report['passed']=True
finally:SingleThreadedExecutor.spin_once=original_spin_once
output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
