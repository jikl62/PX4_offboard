import sys,pathlib,unittest,json,time
root=pathlib.Path('/home/jikl62/FC01_OrangePi_Navigation_20261028');sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'))
names=['test_launcher','test_standby','test_standby_writer','test_navigation_feedback_freshness','test_navigation_diagnostics','test_navigation_report','test_navigation_restore','test_navigation_deployment_activation','test_navigation_service','test_autostart','test_control','test_stage2_python_equivalence']
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
start=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(suite)
record={'modules':names,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'elapsed_s':time.monotonic()-start,'success':result.wasSuccessful()}
p=pathlib.Path('/home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/python_services/regressions.json');p.write_text(json.dumps(record,indent=2)+'\n');raise SystemExit(0 if result.wasSuccessful() else 1)
