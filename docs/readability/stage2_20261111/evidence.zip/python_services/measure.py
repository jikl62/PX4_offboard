from pathlib import Path
import ast,hashlib,json
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028');cache=Path('/home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku');base=cache/'baseline'
control=(ast.If,ast.For,ast.While,ast.Try,ast.With,ast.AsyncFor,ast.AsyncWith,ast.Match)
def functions(path):
 tree=ast.parse(path.read_text());result={}
 def visit(node,prefix=''):
  for item in ast.iter_child_nodes(node):
   if isinstance(item,ast.ClassDef):visit(item,prefix+item.name+'.')
   elif isinstance(item,(ast.FunctionDef,ast.AsyncFunctionDef)):
    def depth(n,level=0):
     if n is not item and isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):return level
     own=level+isinstance(n,control)
     return max([own]+[depth(ch,own) for ch in ast.iter_child_nodes(n)])
    result[prefix+item.name]={'physical_lines':item.end_lineno-item.lineno+1,'max_control_nesting':depth(item),'body_statement_count':len(item.body),'line':item.lineno}
   else:visit(item,prefix)
 visit(tree);return result
specs={
'launcher.py':(['run_console','main'],['输入解析/命令分派','状态行节流','参数解析','会话配置派生/写入','参数说明','资源所有权与会话循环'],['交互循环与异常恢复的早返回顺序仍集中；未分离持有channel的异常恢复循环，避免关闭/续租所有权变化。']),
'native/tools/fcctl.py':(['run'],['一次性命令权限门','ARM_ONLY新鲜证据预检','状态显示签名','帮助文本','ACK/速度/人工确认事件循环'],['run仍199行；ACK匹配、速度期限及一次性Arm确认水位继续由单一循环拥有，不为缩短函数分散状态。']),
'navigation.py':(['render_status'],['服务/快照身份判定','显示年龄增长','实际/历史反馈行','恢复诊断行','控制诊断行','最终操作提示'],[]),
'navigation_probe.py':(['probe'],['地面订阅与字段合同','可选RC订阅/闭包kind冻结','Agent所有权','有界证据等待','最终证据/ROS清理'],['Agent取得、ok/verified_at写水位与finally仍处于同一probe；将等待封装成返回值会改变异常期间已观察ok的记录，故保留。','原final写盘失败导致ROS清理跳过，已复现并另留未应用候选。']),
'navigation_report.py':(['collect_report'],['单报告文件预算/去重/NOFOLLOW读取','入口来源识别','只读命令捕获','报告采集编排'],[]),
'navigation_restore.py':(['activate'],['重复启用回滚记录核验','单调期限启动验收','失败恢复','changed/started事务推进'],['activate中的changed/started仍在实际动作前更新，停旧/切换/启动的补偿水位不抽成返回bool，防止异常导致水位丢失。']),
'navigation_service.py':(['main'],['参数/确认解析','配置核验','run监督参数装配','显式分派'],[]),
'standby.py':(['supervise'],['历史反馈/消息去重状态所有者','单次原生生命周期退出清理','可中断重试退避','自建Agent创建','原生创建','监督编排'],['supervise保留启动锁、preflight、配置写入、传输先行、原生创建、日志泵、监控的协调顺序；不把一次资源取得封装成丢失部分失败所有权的返回对象。']),
}
rows=[]
for name,(targets,responsibilities,debt) in specs.items():
 old,new=functions(base/name),functions(root/name)
 before=(base/name).read_bytes();after=(root/name).read_bytes()
 rows.append({'path':name,'baseline_sha256':hashlib.sha256(before).hexdigest(),'current_sha256':hashlib.sha256(after).hexdigest(),'target_functions':{n:{'before':old[n],'after':new[n]} for n in targets},'new_functions':{n:v for n,v in new.items() if n not in old},'separated_responsibilities':responsibilities,'remaining_structural_debt':debt,'completion':'refactored_with_documented_remaining_debt' if debt else 'listed_function_responsibilities_separated','floating_or_flight_parameter_change':False,'numerical_tolerance_used':False})
record={'baseline_commit':'5198d33f25aaaf2abc7e4b078169ae84d5c4b2c4','scope':'8 Python service/tool files only; ordered deterministic side-effect traces compared strictly','metric_definition':'physical_lines includes comments; nesting counts If/For/While/Try/With/Match and excludes nested callable bodies; responsibility lists are manual role descriptions, not line-count quality claims','files':rows,'scope_limitations':['Mocked systemd/ROS/process call order does not replace ARM64 execution or real DDS signal timing.','The known probe write-failure cleanup bug remains in production; equal traces prove preservation, not absence of pre-existing defects.','No hardware, real systemd mutation, ROS flight publisher or automatic remote push used.']}
(cache/'python_services/metrics_and_review.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({r['path']:r['target_functions'] for r in rows},ensure_ascii=False,indent=2))
