from pathlib import Path
from textwrap import dedent,indent

def helper(name,args,doc,body):return f'def {name}({args}):\n    """{doc}"""\n'+indent(dedent(body),'    ')+'\n\n'
p=Path('native/tools/fcctl.py');s=p.read_text();start=s.index('def run(args):');end=s.index('\n\n# 入口只解析',start);body=s[start:end]
a=body.index('    initial = ');b=body.index('    sock = socket.socket',a)
initial=body[a:b]+'    return initial\n';body=body[:a]+'    initial = _initial_console_command(args)\n'+body[b:]
a=body.index('    # 此处只是界面第二道检查');b=body.index('    # 写前消耗序号',a)
preflight=dedent(body[a:b]);preflight=preflight[preflight.index('def arm_only_preflight'):];preflight=preflight.replace('def arm_only_preflight(now):','def _arm_only_preflight(args, arm_attempt_consumed, latest_state, latest_state_at, now):\n    """只读检查单次台架确认的最新状态并返回拒绝文本或None；now/state_at为单调秒，NED地面Vz单位m/s。调用者仍拥有唯一提交水位；本检查不发送ARM，原字段类型和首拒绝顺序严格保留。"""')
body=body[:a]+body[b:]
body=body.replace('arm_only_preflight(time.monotonic())','_arm_only_preflight(\n                        args, arm_attempt_consumed, latest_state, latest_state_at, time.monotonic()\n                    )')
a=body.index('                        signature = tuple(');b=body.index('                        should_show = ',a)
signature=dedent(body[a:b]).replace('signature =','return',1);body=body[:a]+'                        signature = _console_state_signature(obj)\n'+body[b:]
a=body.index('                        print(\n',body.index("                    if op == 'HELP':"));b=body.index('                        continue\n',a)
helpbody=dedent(body[a:b]);body=body[:a]+'                        _print_console_help()\n'+body[b:]
helpers=helper('_initial_console_command','args','解析一次性请求并检查TTY权限，返回初始命令或None；飞行动作/权限切换只允许现场控制台。先完成原拒绝检查再建立socket，错误文本与顺序不变。',initial)
helpers+=preflight+'\n\n'
helpers+=helper('_console_state_signature','obj','返回界面节流所需状态签名；仅读取既有字段，不更新状态寿命、不影响ACK归属或命令提交。字段排列与原输出变化判定一致。',signature)
helpers+=helper('_print_console_help','','显示原两段帮助；无参数、返回None、无飞行或权限副作用。只由显式HELP输入调用，保留文本与输出顺序。',helpbody)
s=s[:start]+helpers+body+s[end:];p.write_text(s)
