from pathlib import Path
from textwrap import dedent,indent

def helper(name,args,doc,body):return f'def {name}({args}):\n    """{doc}"""\n'+indent(dedent(body),'    ')+'\n\n'

p=Path('launcher.py');s=p.read_text();start=s.index('def run_console(');end=s.index('\n\n# 预检验证',start);body=s[start:end]
a=body.index('                    try:\n                        parts = shlex.split(text)');b=body.index('            # Mission.poll',a)
inputbody=dedent(body[a:b]);assert inputbody.count('continue')==1
inputbody=inputbody.replace('continue','return True')+'return False\n'
body=body[:a]+'''                    if _handle_console_input(
                        text, mission, now, send, say, evidence, close_session
                    ):
                        continue
'''+body[b:]
a=body.index('                            phase = obj.get(\'phase\')');b=body.index("                        if obj.get('kind') == 'reply':",a)
statebody=dedent(body[a:b])+'return printed_phase, last_print\n'
body=body[:a]+'''                            printed_phase, last_print = _show_console_state(
                                obj, now, say, mission, closing, printed_phase, last_print
                            )
'''+body[b:]
helpers=helper('_handle_console_input','text, mission, now, send, say, evidence, close_session','处理一次现场输入；now为单调秒，目标高度m。仅显式takeoff推进Mission；EOF由调用者处理。返回True只表示空输入应跳过本轮，命令/错误/退出副作用顺序与原控制台一致。',inputbody)
helpers+=helper('_show_console_state','obj, now, say, mission, closing, printed_phase, last_print','按阶段变化和单调秒节流显示状态，返回新的(printed_phase,last_print)。只读Mission与反馈、不提交动作；先状态行后等待条件，保持原输出及节流间隔。',statebody)
s=s[:start]+helpers+body+s[end:]
start=s.index('def main(argv=None):');end=s.index("\n\nif __name__",start);body=s[start:end]
a=body.index('    parser =');b=body.index('    os.umask',a);parserbody=body[a:b]+'    return args\n';body=body[:a]+'    args = _parse_launcher_args(argv)\n'+body[b:]
a=body.index('        import yaml\n');b=body.index('        ipc = make_socket_path',a)
configbody=dedent(body[a:b]);announce_start=configbody.index('say(\n');announcements=configbody[announce_start:];configbody=configbody[:announce_start]+'return params, config_path\n'
configbody=configbody.replace('args.flight','flight')
announcements=announcements.replace('args.flight','flight')
body=body[:a]+'''        params, config_path = _write_console_config(root, folder, args.flight)
        _announce_console_configuration(say, params, args.flight)
'''+body[b:]
helpers=helper('_parse_launcher_args','argv','只解析交互/检查模式与5至60秒检查期限，返回args；不创建运行资源。错误先于umask/证据目录/信号安装，保持原入口拒绝顺序。',parserbody)
helpers+=helper('_write_console_config','root, folder, flight','在预检已通过后从既有候选派生并独占写入会话runtime.yaml，返回(params, config_path)。不改源配置或PX4参数；保留原模式/来源元数据和写入顺序。',configbody)
helpers+=helper('_announce_console_configuration','say, params, flight','只显示刚写入的原会话参数与现场确认提示；米/秒/角度单位不变，无状态变更或控制请求。调用者须先完成配置写入再调用。',announcements)
s=s[:start]+helpers+body+s[end:];p.write_text(s)
