from pathlib import Path
import importlib.util,sys,hashlib,json
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028');base=Path('/home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/baseline');out=root.parent/'.cache/fc01-stage2-20261111/run-s59h7rku/python_services'
spec=importlib.util.spec_from_file_location('readability_equivalence',root/'tests/readability_equivalence.py');lex=importlib.util.module_from_spec(spec);sys.modules[spec.name]=lex;spec.loader.exec_module(lex)
prefix='native/src/jikl_fc01_system/include/jikl_fc01_system/'
def tokens(text):return [spelling.decode() for kind,spelling in lex.cpp_structure(text.encode(),'/usr/bin/clang-14')]
def loaded(where,name):return tokens((where/(prefix+name+'.hpp')).read_text())
def find(ts,pattern,start=0):
 pat=tokens(pattern) if isinstance(pattern,str) else pattern
 for i in range(start,len(ts)-len(pat)+1):
  if ts[i:i+len(pat)]==pat:return i
 raise ValueError('missing pattern '+str(pat))
def braced(ts,start):
 a=find(ts,['{'],start);n=0
 for b in range(a,len(ts)):
  n+=(ts[b]=='{')-(ts[b]=='}')
  if n==0:return ts[a+1:b]
 raise ValueError('unbalanced')
def function(ts,name):
 for i,t in enumerate(ts):
  if t!=name or i+1>=len(ts) or ts[i+1]!='(':continue
  n=0
  for j in range(i+1,len(ts)):
   n+=(ts[j]=='(')-(ts[j]==')')
   if not n:break
  k=j+1
  while k<len(ts) and ts[k] in ['const','noexcept','override','final']:k+=1
  if k<len(ts) and ts[k]=='{':return braced(ts,k)
 raise ValueError('function '+name)
def span(ts,a,b):return ts[find(ts,a):find(ts,b)]
def replace(ts,a,b):
 a=tokens(a) if isinstance(a,str) else a;b=tokens(b) if isinstance(b,str) else b
 result=[];i=0;count=0
 while i<len(ts):
  if ts[i:i+len(a)]==a:result+=b;i+=len(a);count+=1
  else:result.append(ts[i]);i+=1
 return result,count
checks=[]
def check(name,old,new,adaptation='none'):
 equal=old==new
 if not equal:
  for i,(a,b) in enumerate(zip(old,new)):
   if a!=b:print('MISMATCH',name,i,old[max(0,i-8):i+10],new[max(0,i-8):i+10]);break
 checks.append({'check':name,'equal':equal,'baseline_tokens':len(old),'current_tokens':len(new),'normalization':adaptation})
old,new=loaded(base,'attitude_altitude_core'),loaded(root,'attitude_altitude_core')
for phase,helper in [('RequestArm','advance_requested_arm'),('ThrustRamp','advance_thrust_ramp')]:
 a=braced(old,find(old,'phase_ == Phase::'+phase,find(old,'Output step')))
 b=function(new,helper);b,c=replace(b,'return false;','return {};');assert b[-3:]==tokens('return true;');b=b[:-3]
 check(helper,a,b,'helper failure false maps caller to return {}; final true maps continuation')
a=span(old,'if (s.status_stamp > rc_recovery_last_status_)','//marker' if False else 'const bool detector_window_complete') if False else None
# Original recovery source recording ends immediately before detector window readiness.
start=find(old,'if (s.status_stamp > rc_recovery_last_status_)',find(old,'void observe_rc_recovery'))
end=find(old,'const bool land_window',start) if False else find(old,'const bool detector',start) if False else None
helper=function(new,'record_rc_recovery_sources');check('recovery source body',old[start:start+len(helper)],helper)
helper=function(new,'update_rc_recovery_reason');helper,c=replace(helper,'position_window_checked','vertical.position_window_checked');start=find(old,'if (rc_recovery_ready_)',find(old,'void observe_rc_recovery'));check('recovery reason body',old[start:start+len(helper)],helper,'bool parameter substitutes original local evidence member')
old,new=loaded(base,'attitude_types'),loaded(root,'attitude_types')
expanded=function(new,'validate')
for helper in ['validate_preparation','validate_flight_limits']:expanded,c=replace(expanded,helper+'();',function(new,helper));assert c==1
check('Config validate inlined exact',function(old,'validate'),expanded)
old,new=loaded(base,'authority_telemetry'),loaded(root,'authority_telemetry')
for outer,helper in [('manual','observe_manual_axes'),('switches','observe_switch_values')]:
 expanded=function(new,outer);body=function(new,helper)
 if helper=='observe_manual_axes':body,c=replace(body,'using M = std::decay_t<Manual>;','');assert c==1
 expanded,c=replace(expanded,helper+'(message'+(', timeout' if outer=='switches' else '')+');',body);assert c==1
 check('Authority '+outer+' inlined exact',function(old,outer),expanded,'duplicate unchanged using M removed from helper before inlining' if outer=='manual' else 'none')
old,new=loaded(base,'rc_navigation'),loaded(root,'rc_navigation')
for phase,helper in [('Prestream','step_prestream'),('WaitNavigation','step_wait_navigation')]:
 check('RC '+helper,braced(old,find(old,'phase_ == RcStartPhase::'+phase,find(old,'bool step'))),function(new,helper))
check('RC block same lambda body',braced(old,find(old,'const auto block')),function(new,'block'))
old,new=loaded(base,'velocity_core'),loaded(root,'velocity_core')
a=function(old,'step');start=find(a,'const Velocity cmd');end=len(a)-1
# Last branch starts at const Velocity and ends immediately before final return o.
b=function(new,'motion_output');b,c=replace(b,'Output o;','');assert c==1;assert b[-3:]==tokens('return o;');b=b[:-3]
check('Velocity movement body',a[start:start+len(b)],b,'new local Output default matches original never-written o on else path; final return replaces caller tail')
old,new=loaded(base,'vertical_controller'),loaded(root,'vertical_controller')
a=function(old,'step');b=function(new,'accept_integral');start=find(a,'if (!integral_frozen_');check('vertical antiwindup exact',a[start:start+len(b)],b)
b=function(new,'input_error');assert b[-3:]==tokens('return nullptr;');b=b[:-3]
for reason in ['Z_VZ_STALE_OR_INVALID','NONFINITE_VERTICAL_INPUT_OR_DT','INVALID_TAKEOFF_THRUST_CEILING']:b,c=replace(b,'return "'+reason+'";','return bad("'+reason+'");');assert c==1
check('vertical input first error',a[:len(b)],b,'char error return wraps original bad at caller; identical short circuit order')
old,new=loaded(base,'vertical_feedback_guard'),loaded(root,'vertical_feedback_guard')
a=function(old,'observe');b=function(new,'observe_rate_disagreement');start=find(a,'e_.rate_error_mps');check('rate diagnostic exact',a[start:start+len(b)],b)
b=function(new,'observe_position_window');assert b[-3:]==tokens('return true;');b=b[:-3];b,c=replace(b,'return false;','return fail("VERTICAL_POSITION_RATE_INCONSISTENT");');assert c==1;start=find(a,'if (!last_stamp_)');check('position window exact',a[start:start+len(b)],b,'false maps fail at same caller point before last_stamp/last_rate commit')
old,new=loaded(base,'vision_navigation'),loaded(root,'vision_navigation')
b=function(new,'accepted_input_error');assert b[-4:]==tokens('return {};');b=b[:-4]
reasons=['NAVIGATION_SOURCE_CHANGED','NAVIGATION_FRAME_CHANGED','NAVIGATION_ESTIMATOR_RESET','NAVIGATION_SEQUENCE_REGRESSION','NAVIGATION_REPLAY_PAYLOAD_CHANGED','NAVIGATION_SAMPLE_NOT_ADVANCING','NAVIGATION_ESTIMATOR_JUMP']
for reason in reasons:b,c=replace(b,'return "'+reason+'";','return reject("'+reason+'");');assert c==1
check('vision accepted continuity exact',braced(old,find(old,'if (accepted_)',find(old,'Result step'))),b,'string returned from read-only helper enters same reject with same reason; no mutation precedes allocation')
assert all(c['equal'] for c in checks)
manual=[
 {'file':'attitude_altitude_core.hpp','finding':'No refactor-introduced behavior defect found','review':'Helper false immediately becomes same empty Output return; true falls through same public tail. No second phase dispatch after helper transitions. Output& keeps prior height/speed and transition-tick slew results; arm const ref points to original by-value Transaction local of five booleans. Recovery per-source counting is after guard success and before readiness, reason last.'},
 {'file':'attitude_types.hpp','finding':'No refactor-introduced behavior defect found','review':'validate() expanded tokens exactly equal; two const void helper calls preserve visual->RC->preparation->flight exception priority. Helpers newly public in struct, with no changed callers or mutation.'},
 {'file':'authority_telemetry.hpp','finding':'No refactor-introduced behavior defect found','review':'Template arguments preserve underlying Manual/HasRcAxes specialization via decay_t. Source and dual clocks commit before axis helper. Invalid-clock Kill ON veto remains before helper and OFF clearing retains original time conditions.'},
 {'file':'rc_navigation.hpp','finding':'No refactor-introduced behavior defect found','review':'Direct return delegates identical full branches and result types, not bool postprocessing. WaitGround->Prestream and WaitArm->WaitNavigation same-tick progression remains; deadline precedes new proof. block member uses same const string& and mutation order as old lambda.'},
 {'file':'velocity_core.hpp','finding':'No refactor-introduced behavior defect found','review':'Movement else path original local o was still default initialized; replacement local Output has identical NaN/control/command defaults. Conversion, hypot scaling, filtered xyz/yaw updates and braking dwell all preserve expression tokens.'},
 {'file':'vertical_controller.hpp','finding':'No refactor-introduced behavior defect found','review':'Input_error takes same double scalar types/const sample, no state or calculation before original guards. accept_integral double arguments are previously-computed locals; not wider intermediates under current x86_64 SSE/ARM64 ABI. Original trial->raw->reachable->accept/unwind->raw->slew order and arithmetic tokens remain.'},
 {'file':'vertical_feedback_guard.hpp','finding':'No refactor-introduced behavior defect found','review':'Velocity disagreement stays diagnostic-only and is observed before integration. Position failure returns to caller fail with no intervening writes; failed sample never commits last_stamp/last_rate. Same NED doubles and uint64 source stamps, no parameter narrowing.'},
 {'file':'vision_navigation.hpp','finding':'No refactor-introduced behavior defect found','review':'Continuity helper reads accepted snapshot and returns first same string; source/frame/reset/sequence/payload/time/jump priority exact. Returned std::string may allocate just as old reject(const string&) conversion; no state mutates before either allocation and no exceptions swallowed.'}
]
paths=[prefix+row['file'] for row in manual]
record={'reviewer':'stage2_python_services independent review of cpp_control agent changes','read_only':True,'baseline':'5198d33f25aaaf2abc7e4b078169ae84d5c4b2c4','source_sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},'method':'Full per-file diff inspection plus clang-14 raw lexical comparison of moved bodies with explicitly enumerated call/return substitutions; types, ownership and call site inspected manually. No dynamic result used as a substitute for this review.','token_checks':checks,'manual_reviews':manual,'unresolved_findings':[],'limits':['Does not prove ARM64 scheduling, compiler code generation/optimization equivalence or flight acceptance.','No new broad defect search or production changes performed.','Exact body tokens only prove stated regions and substitutions; caller context separately reviewed.']}
(out/'independent_cpp_review.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'token_checks':len(checks),'all_equal':True,'files_reviewed':len(manual),'unresolved_findings':0,'report':str(out/'independent_cpp_review.json')},ensure_ascii=False))
