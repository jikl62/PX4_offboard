from pathlib import Path
import difflib,hashlib,importlib.util,json,sys,tempfile
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028');sys.path.insert(0,str(root))
cache=Path('/home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/python_services')
p=root/'navigation_probe.py';source=p.read_text();start=source.rindex('    finally:\n');cleanup=source.index('        if node is not None:',start)
body=source[start+len('    finally:\n'):cleanup]
resource=source[cleanup:]
marker='        if rclpy.ok():\n'
first,second=resource.split(marker,1)
indent=lambda text:''.join('    '+line if line.strip() else line for line in text.splitlines(keepends=True))
replacement='    finally:\n        try:\n'+indent(body)+'        finally:\n            try:\n'+indent(indent(first))+'            finally:\n'+indent(indent(marker+second))
candidate=source[:start]+replacement
folder=cache/'probe_cleanup_candidate';folder.mkdir(exist_ok=True)
candidate_path=folder/'navigation_probe.py';candidate_path.write_text(candidate)
patch=''.join(difflib.unified_diff(source.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='a/navigation_probe.py',tofile='b/navigation_probe.py'))
(cache/'probe_cleanup_candidate.patch').write_text(patch)
spec=importlib.util.spec_from_file_location('stage2_trace',root/'tests/stage2_python_trace.py');worker=importlib.util.module_from_spec(spec);spec.loader.exec_module(worker)
results=[]
for label,path,gap in [('production',p,True),('candidate',candidate_path,False)]:
 spec=importlib.util.spec_from_file_location('navigation_probe',path);module=importlib.util.module_from_spec(spec);sys.modules['navigation_probe']=module;spec.loader.exec_module(module)
 with tempfile.TemporaryDirectory(prefix='fc01_stage2_probe_candidate_') as temp:
  values=worker.probe_trace(root,Path(temp),expect_cleanup_gap=gap)
 results.append({'label':label,'scenarios':values})
record={'production_sha256':hashlib.sha256(source.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'production_unchanged':p.read_text()==source,'scope':'mock ROS only; keeps original write OSError visible, no RuntimeError swallowing; independent candidate not applied','results':results}
(cache/'probe_cleanup_candidate_verification.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'production_unchanged':record['production_unchanged'],'scenarios_per_version':len(results[0]['scenarios']),'production_disk_failure':results[0]['scenarios'][-1],'candidate_disk_failure':results[1]['scenarios'][-1]},ensure_ascii=False,indent=2))
