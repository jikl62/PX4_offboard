from pathlib import Path
from textwrap import dedent,indent

def helper(name,args,doc,body):
 return f'def {name}({args}):\n    """{doc}"""\n'+indent(dedent(body),'    ')+'\n\n'

p=Path('navigation.py');s=p.read_text();start=s.index('def render_status(');end=s.index('\n\n# 周期读取状态',start);body=s[start:end]
status_start=body.index('    active = '); status_end=body.index('    # 快照中的age')
status=body[status_start:status_end]+'    return status, reason\n'
body=body[:status_start]+'    status, reason = _snapshot_display_status(row, info, now)\n'+body[status_end:]
age_start=body.index('    age = row.get');age_end=body.index('    native_current = ')
age=body[age_start:age_end]+'    return age\n'
body=body[:age_start]+'    age = _display_feedback_age(row, now)\n'+body[age_end:]
# Isolate recovery diagnostic layout without moving any condition or reading aircraft state anew.
rstart=body.index('        # 恢复显示');rend=body.index('        if state.get(\'takeoff_stage\')',rstart)
recovery=dedent(body[rstart:rend]);body=body[:rstart]+'        _append_recovery_lines(lines, state, status, current, native_current, age, gate)\n'+body[rend:]
# Separate pure aircraft feedback formatting from identity/freshness classification.
fstart=body.index('    mode = ');fend=body.index('    if state:\n        gate =',fstart)
feedback=body[fstart:fend]+'    return lines\n'
body=body[:fstart]+'    lines = _feedback_display_lines(state, status, reason, locked_fault, current, age)\n'+body[fend:]
# The control diagnostic rows have a single mutable output owner: the supplied line list.
cstart=body.index('    if state:\n        gate =');cend=body.index('    if row.get(\'retry_in_seconds\')',cstart)
control=body[cstart:cend];body=body[:cstart]+'    _append_control_lines(lines, state, status, current, native_current, age)\n'+body[cend:]
helpers=''
helpers+=helper('_snapshot_display_status','row, info, now','只读比较服务身份与快照墙钟年龄，返回(status, reason)；不推断飞机状态、不修改输入。先身份后年龄的拒绝优先级保持原样。',status)
helpers+=helper('_display_feedback_age','row, now','返回显示时的反馈年龄(秒)或None；输入now为墙钟秒。只累加快照存放时间，不给历史反馈续鲜、不修改row。',age)
helpers+=helper('_feedback_display_lines','state, status, reason, locked_fault, current, age','按已判定的新鲜度生成首段显示行；高度单位m、推断权限不在此授予。仅返回新列表，当前/历史标签与故障顺序保持不变。',feedback)
helpers+=helper('_append_recovery_lines','lines, state, status, current, native_current, age, gate','在调用者的lines尾部追加恢复诊断；窗口秒数与样本计数仅供观察。按原Runtime/Core阻塞优先级读state，不复位故障或开启动作门。',recovery)
helpers+=helper('_append_control_lines','lines, state, status, current, native_current, age','向lines按原顺序追加动作门、恢复、离地和本地推力信息；state只读。FRD推力与真实PX4采用证据仍区分，函数不发送控制请求。',control)
s=s[:start]+helpers+body+s[end:];p.write_text(s)

p=Path('navigation_probe.py');s=p.read_text();start=s.index('def probe(');end=len(s);body=s[start:end]
a=body.index('        # ROS回调');b=body.index('        # 等待有界',a)
subscriptions=dedent(body[a:b]);subscriptions+='\nreturn subs, rc_topics\n'
body=body[:a]+'''        subs, rc_topics = _create_ground_subscriptions(
            node, evidence, rc, VehicleStatus, VehicleLandDetected, qos_profile_sensor_data
        )
'''+body[b:]
h=helper('_create_ground_subscriptions','node, evidence, rc, status_type, land_type, qos','只创建原只读话题订阅，返回(subs, rc_topics)保持订阅生命周期；回调记录墙钟/单调秒。rc可为None；不创建发布者、不修改飞控。订阅顺序和冻结kind的规则保持原样。',subscriptions.replace('VehicleStatus,','status_type,').replace('VehicleLandDetected,','land_type,').replace('qos_profile_sensor_data,','qos,'))
s=s[:start]+h+body;p.write_text(s)

p=Path('navigation_service.py');s=p.read_text();start=s.index('def main(argv=None):');end=s.index("\n\nif __name__",start);body=s[start:end]
a=body.index('    parser =');b=body.index('    os.umask',a);parserbody=body[a:b]+'    return args, parser\n';body=body[:a]+'    args, parser = _parse_service_args(argv)\n'+body[b:]
a=body.index("        if args.file is None:",body.index("    elif args.action == 'check-config':"));b=body.index("    elif args.action == 'probe':",a)
check=dedent(body[a:b]);body=body[:a]+'        return _check_runtime_config(args, parser)\n'+body[b:]
a=body.index('        # 信号只置停止事件',body.index("    elif args.action == 'probe':"));b=body.index('    return 0',a)
runbody=dedent(body[a:b]);body=body[:a]+'        _run_navigation_service(args, root, agent)\n'+body[b:]
helpers=helper('_parse_service_args','argv','解析并校验入口参数，返回(args, parser)；仅Flight Test双重确认成立才选择该模式。本函数不启动服务、不改配置，错误顺序保留。',parserbody)
helpers+=helper('_check_runtime_config','args, parser','检查所选配置并返回退出码；diagnostic逐门确切False，flight-test调用既有配置检查器。按原错误优先级执行，未提供有效配置时不启动控制器。',check)
helpers+=helper('_run_navigation_service','args, root, agent','按已确认模式构造运行配置并交给既有standby监督器；信号只置停止事件。保留打印、控制器核验与配置工厂调用顺序，不新增解锁或飞行权限。',runbody)
s=s[:start]+helpers+body+s[end:];p.write_text(s)

p=Path('navigation_restore.py');s=p.read_text();start=s.index('def activate(');end=s.index('\n\n# 只检查，不隐式stop',start);body=s[start:end]
a=body.index("        state_path = entry / 'ACTIVATION_STATE.json'");b=body.index("        _activation_state(entry, backup, 'active'",a)
repeat=dedent(body[a:b])+'return backup\n';body=body[:a]+'''        backup = _verified_active_backup(
            entry, home, project, unit, info, binary, agent, boot_policy, units
        )
'''+body[b:]
a=body.index('            deadline = time.monotonic()');b=body.index('            _activation_state(\n',a)
verify=dedent(body[a:b])+'return row\n';body=body[:a]+'''            row = _wait_activation_verified(entry, home, binary, agent, run, verify_timeout)
'''+body[b:]
a=body.index('            try:\n',body.index('        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as exc:'))
recovery=dedent(body[a:]);body=body[:a]+'''            _recover_failed_activation(
                entry, home, project, agent, run, units, path, backup, manifest,
                started=started, changed=changed, error=exc,
            )
'''
# Preserve causal exception chaining; the handler transfers the exact caught exception object.
recovery=recovery.replace('str(exc)','str(error)').replace(' from exc',' from error')
helpers=helper('_verified_active_backup','entry, home, project, unit, info, binary, agent, boot_policy, units','只在重复activate已核验真实运行状态后读取/建立回滚记录并返回backup。路径必须位于受控备份根下；不停止或重启服务，异常不覆盖原服务。',repeat)
helpers+=helper('_wait_activation_verified','entry, home, binary, agent, run, verify_timeout','在单调秒截止时间内重试既有运行验收并返回row；按原0.2秒退避。只读取验收证据，不重启服务，最后一次异常保留为失败原因。',verify)
helpers+=helper('_recover_failed_activation','entry, home, project, agent, run, units, path, backup, manifest, *, started, changed, error','处理单次启用失败并始终抛ControlError；started/changed来自调用者的原事务水位。先停新控制器、确认退出、再按摘要恢复，禁止抢占外来修改；保留原异常因果链。',recovery)
s=s[:start]+helpers+body+s[end:];p.write_text(s)
