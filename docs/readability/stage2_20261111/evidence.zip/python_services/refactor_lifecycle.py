from pathlib import Path
from textwrap import dedent,indent
import io,tokenize

def rename(source,names):
 toks=[]
 for t in tokenize.generate_tokens(io.StringIO(source).readline):
  if t.type==tokenize.NAME and t.string in names:
   t=tokenize.TokenInfo(t.type,names[t.string],t.start,t.end,t.line)
  toks.append(t)
 return tokenize.untokenize(toks)

def helper(name,args,doc,body):return f'def {name}({args}):\n    """{doc}"""\n'+indent(dedent(body),'    ')+'\n\n'

p=Path('navigation_report.py');s=p.read_text();start=s.index('def collect_report(');body=s[start:]
a=body.index('        # 统一文件入口');b=body.index("        initial = include(",a)
include=dedent(body[a:b]);include=include.replace('def include(path, name,','def include(self, path, name,').replace('    nonlocal total\n','')
include=rename(include,{k:'self.'+k for k in ['total','captured_names','capture','archive']})
include=include.replace('def include(self, path, name, *, limit=MAX_METADATA, reserve=0):\n','def include(self, path, name, *, limit=MAX_METADATA, reserve=0):\n    """捕获一份普通文件并返回字节或None；记录去重、预算与变更证据。先标记名字再尝试读取，NOFOLLOW及裁尾/预留顺序保留；只修改本收集器和capture索引。"""\n')
cls='''class _ReportFileCapture:
    """单份报告的文件预算与去重所有者；不查询或改变服务，不跨报告共享状态。"""

    def __init__(self, capture):
        """绑定可变采集索引，初始化字节预算；archive在私有ZIP打开后由调用者设置。"""
        self.capture = capture
        self.total = 0
        self.captured_names = set()
        self.archive = None

'''+indent(include,'    ')+'\n\n'
body=body[:a]+'''        files.archive = archive
        include = files.include
'''+body[b:]
body=body.replace('    total = 0\n    captured_names = set()\n','    files = _ReportFileCapture(capture)\n')
body=body.replace('captured_file_bytes=total,','captured_file_bytes=files.total,')
# Release provenance path discovery is pure; actual include call order stays in collect_report.
a=body.index("        entries = [('invoked_entry', entry)]");b=body.index("        capture['entries']",a)
entries=dedent(body[a:b])+'return entries\n';body=body[:a]+'        entries = _report_entries(home, entry, row)\n'+body[b:]
a=body.index('            try:\n                result = runner(',body.index('# systemctl status/journalctl'));b=body.index('        capture.update(',a)
command=dedent(body[a:b]);body=body[:a]+'            _include_command_report(archive, capture, name, argv, runner)\n'+body[b:]
helpers=helper('_report_entries','home, entry, row','返回调用入口和受控home下的运行版本入口；row只读。只识别既有config/native来源路径，不把新包名冒充已部署版本，也不改变服务。',entries)
helpers+=helper('_include_command_report','archive, capture, name, argv, runner','按原10秒超时执行一项只读查询，裁尾写入ZIP并记录返回码/异常。runner可注入；不重试、不发启停命令，调用顺序由收集器保持。',command)
s=s[:start]+cls+helpers+body;p.write_text(s)

p=Path('standby.py');s=p.read_text();start=s.index('def supervise(');end=s.index('\n\n# 旧版后台入口',start);body=s[start:end]
a=body.index('    last_message = None');b=body.index('    try:\n        while not stopped.is_set():',a)
setup=body[a:b]
# State publisher replaces the closure's explicit four-element state tuple ownership.
pubstart=setup.index('    def publish(row):');pub=dedent(setup[pubstart:]);pub=pub.replace('def publish(row):','def __call__(self, row):').replace('    nonlocal last_message, last_state, last_state_at, last_state_pid\n','')
state_names=['last_message','last_state','last_state_at','last_state_pid','diagnostics','metadata','writer','row_formatter']
pub=rename(pub,{k:'self.'+k for k in state_names})
cls='''class _StatusPublisher:
    """监督器单次进程的历史状态与显示所有者；只向异步writer提交快照，不授予飞行权限。"""

    def __init__(self, writer, status_metadata, row_formatter):
        """绑定writer/可选格式器并记录本监督器身份；时钟为主机单调秒与boot_id，无飞机坐标。"""
        self.writer = writer
        self.row_formatter = row_formatter
        self.last_message = None
        self.last_state, self.last_state_at, self.last_state_pid = {}, -math.inf, None
        self.diagnostics = {}
        self.metadata = dict(status_metadata or {})
        self.metadata['supervisor_pid'] = os.getpid()
        try:
            self.metadata['boot_id'] = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        except OSError:
            self.metadata['boot_id'] = ''

'''+indent(pub,'    ')+'\n\n'
cls=cls.replace('def __call__(self, row):\n','def __call__(self, row):\n        """按原先后顺序合并诊断、维护真实反馈年龄、格式化后提交；无新状态时只保留历史且强制失效。row不用于控制，消息去重状态仅归此对象。"""\n')
body=body[:a]+'''    publish = _StatusPublisher(writer, status_metadata, row_formatter)
    diagnostics = publish.diagnostics

'''+body[b:]
body=body.replace('                diagnostics = {}\n','                diagnostics = {}\n                publish.diagnostics = diagnostics\n')
body=body.replace('                    last_state, last_state_at, last_state_pid = state, state_at, node.pid\n','                    publish.last_state, publish.last_state_at, publish.last_state_pid = (\n                        state, state_at, node.pid\n                    )\n')
a=body.index('                # 清理也要先请求');b=body.index('            # 一次原生生命周期',a)
cleanup=dedent(body[a:b]);body=body[:a]+'''                _close_supervised_attempt(
                    node, agent, transport, channel, diagnostics, pump, native_log,
                    ipc, state, state_at, lock, publish, writer,
                )
'''+body[b:]
a=body.index('            if not stopped.is_set():',body.index('            # 一次原生生命周期'));b=body.index("        publish(dict(status='STOPPED'",a)
retry=dedent(body[a:b]);body=body[:a]+'''            _wait_supervisor_retry(stopped, failure, diagnostics, publish)
'''+body[b:]
helpers=helper('_close_supervised_attempt','node, agent, transport, channel, diagnostics, pump, native_log, ipc, state, state_at, lock, publish, writer','结束一次原生生命周期；参数均为本次资源及真实单调秒证据。先等原生退出且Agent传输仍活，再关传输/IPC/日志，最后仅凭新鲜地面证据处理自建Agent并释放锁；不强杀、不重放任务。',cleanup)
helpers+=helper('_wait_supervisor_retry','stopped, failure, diagnostics, publish','原生已结束后才执行既有30秒可中断重试退避；每5秒发布只读等待原因。无新进程/任务副作用，诊断退出原因拼接与停止优先级保持不变。',retry)
s=s[:start]+cls+helpers+body+s[end:];p.write_text(s)
