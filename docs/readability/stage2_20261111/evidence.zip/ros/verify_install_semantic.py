"""只读安装身份与CDR字段保真检查；不启动节点、不要求无语义填充字节稳定。"""
from __future__ import annotations
import argparse
from array import array
import hashlib
import inspect
import json
from pathlib import Path
import re
import struct
import sys

from rclpy.serialization import serialize_message, deserialize_message
from rosidl_runtime_py.utilities import get_message
import jikl_fc01_system.msg as generated
import px4_msgs
from px4_msgs.msg import VehicleStatus

NAMES=('VisionState','NavigationCommand','VelocityCommand','VisionHealth','AttitudeThrustPreview')


def exact_value(value):
    """递归保留类型、浮点IEEE64位模式和数组形状；不以容差或Python弱数值相等放宽字段。"""
    if hasattr(value,'get_fields_and_field_types'):
        return {'message_class':type(value).__module__+'.'+type(value).__name__,
                'fields':{key:exact_value(getattr(value,key)) for key in value.get_fields_and_field_types()}}
    if isinstance(value,float):return {'type':'float64','ieee754':struct.pack('>d',value).hex()}
    if isinstance(value,bool):return {'type':'bool','value':value}
    if isinstance(value,int):return {'type':'int','value':str(value)}
    if isinstance(value,str):return {'type':'str','value':value}
    if isinstance(value,(list,tuple,array)) or hasattr(value,'tolist'):
        return {'container_type':type(value).__module__+'.'+type(value).__name__,
                'length':len(value),'items':[exact_value(v.item() if hasattr(v,'item') else v) for v in value]}
    raise AssertionError('Uncovered field type '+repr(type(value)))


def canonical(message):
    return json.dumps(exact_value(message),sort_keys=True,separators=(',',':'),ensure_ascii=False)


def populated(cls, trial):
    """为每个字段赋可区分非默认值；传输试验不运行业务准入，质量/坐标等门槛不在此授予。"""
    msg=cls()
    for index,(name,kind) in enumerate(msg.get_fields_and_field_types().items()):
        n=trial+index+1
        if kind=='uint16':value=1 if name=='schema_version' else n%65535
        elif kind=='uint64':value=0x0102030405060708+trial*100+index
        elif kind=='uint32':value=123456+trial*10+index
        elif kind=='uint8':value=n%255
        elif kind=='boolean':value=bool(n%2)
        elif kind=='string':value=name+'-标定-'+str(trial)
        elif kind=='builtin_interfaces/Time':
            msg.stamp.sec=-123+trial;msg.stamp.nanosec=987654321-trial
            continue
        elif kind=='double':value=-0.0 if trial%3==0 else float(n)/8.0
        elif re.fullmatch(r'double\[\d+\]',kind):
            count=int(kind[7:-1]);value=[(-1.0 if j%2 else 1.0)*(n+j)/16.0 for j in range(count)]
            if count>1 and trial%3==0:value[1]=-0.0
        else:raise AssertionError('Uncovered schema kind '+kind)
        setattr(msg,name,value)
    return msg


def cdr_layout(message):
    """依据实际字段类型和值计算CDR1相对payload布局，分别列出全部有效字节与对齐填充。"""
    offset=0;fields=[];padding=[]
    sizes={'boolean':1,'uint8':1,'uint16':2,'uint32':4,'int32':4,'uint64':8,'double':8}
    def align(size):
        nonlocal offset
        extra=(-offset)%size
        padding.extend(range(4+offset,4+offset+extra));offset+=extra
    def field(name,kind,value):
        nonlocal offset
        if kind=='builtin_interfaces/Time':
            field(name+'.sec','int32',value.sec);field(name+'.nanosec','uint32',value.nanosec);return
        if kind=='string':
            align(4);start=offset;offset+=4+len(value.encode('utf8'))+1
        elif re.fullmatch(r'double\[\d+\]',kind):
            align(8);start=offset;offset+=8*len(value)
        elif kind in sizes:
            size=sizes[kind];align(size);start=offset;offset+=size
        else:raise AssertionError('Unsupported CDR layout field '+kind)
        fields.append({'name':name,'type':kind,'absolute_offset':4+start,'bytes':offset-start})
    for name,kind in message.get_fields_and_field_types().items():field(name,kind,getattr(message,name))
    return {'encoding_bytes':4+offset,'fields':fields,'padding_offsets':padding}


def identical(source,installed):
    """按字节核验安装物来自当前源码；路径或权限/模块身份另行核验，不接受同名旧版本。"""
    assert installed.is_file(),str(installed)
    a,b=source.read_bytes(),installed.read_bytes();assert a==b,str(installed)
    return {'source':str(source),'installed':str(installed),'bytes':len(a),'sha256':hashlib.sha256(a).hexdigest(),'byte_identical':True}


def padding_check(prefix):
    """以明确sentinel定位VisionState首两字段，证明所观测8..11只属填充且有效字段仍严格比较。"""
    cls=get_message('jikl_fc01_system/msg/VisionState')
    original=cls(schema_version=0x1234,sequence=0x0102030405060708)
    encoded=serialize_message(original)
    assert encoded[0:4]==b'\x00\x01\x00\x00','Only measured CDR1 little-endian encapsulation covered'
    assert encoded[4:6]==b'\x34\x12'
    assert encoded[12:20]==bytes.fromhex('0807060504030201')
    for positions in [list(range(6,12)),list(range(8,12))]:
        changed=bytearray(encoded)
        for offset in positions:changed[offset]=(0xA5+offset)&255
        restored=deserialize_message(bytes(changed),cls)
        assert canonical(restored)==canonical(original)
    negative=[]
    for offset,field in [(4,'schema_version'),(12,'sequence')]:
        changed=bytearray(encoded);changed[offset]^=1
        restored=deserialize_message(bytes(changed),cls)
        assert canonical(restored)!=canonical(original)
        assert getattr(restored,field)!=getattr(original,field)
        negative.append({'changed_offset':offset,'changed_field':field,'change_detected':True})
    generated_source=prefix.parent.parent/'build/jikl_fc01_system/rosidl_typesupport_fastrtps_cpp/jikl_fc01_system/msg/detail/dds_fastrtps/vision_state__type_support.cpp'
    text=generated_source.read_text()
    assert 'cdr << ros_message.schema_version;' in text and 'cdr << ros_message.sequence;' in text
    assert text.index('cdr << ros_message.schema_version;')<text.index('cdr << ros_message.sequence;')
    assert 'eprosima::fastcdr::Cdr::alignment(current_alignment, item_size);' in text
    return {'encoding':'CDR1 little endian','encapsulation_offsets':[0,1,2,3],
            'payload_origin_absolute':4,'schema_version_offsets':[4,5],
            'sequence_alignment':8,'sequence_offsets':list(range(12,20)),
            'padding_offsets':list(range(6,12)),'observed_difference_offsets':[8,9,10,11],
            'observed_differences_only_padding':True,'padding_mutations_preserve_all_fields':True,
            'effective_field_mutation_negative_controls':negative,
            'generated_cpp_path':str(generated_source),'generated_cpp_sha256':hashlib.sha256(text.encode()).hexdigest(),
            'qualification':'Only layout-proven padding mutations are ignored; every semantic field is still type/bit exact. No message source or generated code changed.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('prefix',type=Path);parser.add_argument('output',type=Path);args=parser.parse_args()
    root=args.root.resolve();prefix=args.prefix.resolve()
    if (prefix/'jikl_fc01_system/lib/jikl_fc01_system').is_dir():prefix=prefix/'jikl_fc01_system'
    assert VehicleStatus.MESSAGE_VERSION==1
    report={'passed':False,'prefix':str(prefix),'python':sys.executable,'px4_msgs_paths':list(px4_msgs.__path__),'nodes_started':False,'hardware_operations':False,'source_tools':[],'source_headers':[],'interfaces':[]}
    for name in ['vision_odometry_adapter.py','velocity_command_diagnostic.py','vision_state_validation.py']:
        report['source_tools'].append(identical(root/'native/tools'/name,prefix/'lib/jikl_fc01_system'/name))
    includes=root/'native/src/jikl_fc01_system/include/jikl_fc01_system'
    headers=sorted(includes.glob('*.hpp'));assert len(headers)==34
    for source in headers:report['source_headers'].append(identical(source,prefix/'include/jikl_fc01_system'/source.name))
    byte_differences=[]
    for name in NAMES:
        typename='jikl_fc01_system/msg/'+name;cls=get_message(typename)
        assert cls is getattr(generated,name)
        snake=re.sub(r'(?<!^)(?=[A-Z])','_',name).lower()
        assert cls.__module__=='jikl_fc01_system.msg._'+snake
        module=Path(inspect.getfile(cls)).resolve();assert module.is_relative_to(prefix)
        assert cls().schema_version==1
        source=root/'native/src/jikl_fc01_system/msg'/(name+'.msg');installed=prefix/'share/jikl_fc01_system/msg'/(name+'.msg')
        file=identical(source,installed)
        trials=[cls()]+[populated(cls,trial) for trial in range(100)]
        field_equality_count=0
        for trial,message in enumerate(trials):
            encoded=serialize_message(message);decoded=deserialize_message(encoded,cls)
            layout=cdr_layout(message);assert len(encoded)==layout['encoding_bytes'],(name,trial,'layout length')
            assert type(decoded) is cls
            assert canonical(decoded)==canonical(message),(name,trial,'field changed')
            encoded_again=serialize_message(decoded);decoded_again=deserialize_message(encoded_again,cls)
            assert canonical(decoded_again)==canonical(message),(name,trial,'second round trip field changed')
            field_equality_count+=2
            if encoded_again!=encoded:
                different=[i for i,(a,b) in enumerate(zip(encoded,encoded_again)) if a!=b]
                assert len(encoded)==len(encoded_again) and set(different)<=set(layout['padding_offsets']),(name,trial,'unexplained byte difference',different)
                byte_differences.append({'type':name,'trial':trial,'different_offsets':different,'all_field_bit_patterns_equal':True,'layout':layout,'all_differences_in_layout_proved_padding':True})
        report['interfaces'].append({'type':typename,'module':str(module),'fields':cls.get_fields_and_field_types(),'source_msg':file,'default_schema_version':1,'round_trip_trials':len(trials),'exact_field_comparisons':field_equality_count,'exact_field_values_preserved':True})
    report['padding_review']=padding_check(prefix)
    report['reserialize_byte_difference_observations']=byte_differences
    report['byte_equality_is_not_acceptance_criterion']=True
    report['passed']=True
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'passed':True,'tools':len(report['source_tools']),'headers':len(report['source_headers']),'interfaces':len(report['interfaces']),'message_trials':sum(row['round_trip_trials'] for row in report['interfaces']),'exact_field_round_trip_comparisons':sum(row['exact_field_comparisons'] for row in report['interfaces']),'padding_mutation_controls':2,'effective_field_negative_controls':2,'output':str(args.output)}))


if __name__=='__main__':main()
