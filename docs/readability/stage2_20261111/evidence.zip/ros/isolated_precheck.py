import rclpy,os,time,json,sys
rclpy.init();node=rclpy.create_node('fc01_stage2_isolation_precheck')
try:
 for _ in range(20):rclpy.spin_once(node,timeout_sec=.05)
 names=node.get_node_names();topics=[name for name,_ in node.get_topic_names_and_types()]
 assert names==[node.get_name()],names
 assert not any(name.startswith('/fmu/') for name in topics),topics
 print(json.dumps(dict(domain=os.environ['ROS_DOMAIN_ID'],localhost=os.environ['ROS_LOCALHOST_ONLY'],nodes=names,topics=topics,isolated=True)))
finally:node.destroy_node();rclpy.shutdown()
