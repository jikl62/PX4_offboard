// 独立反例：只读证明既有视觉身份字符串没有长度门；不属于重构，不请求真实飞行权限。
#include "jikl_fc01_system/vision_navigation.hpp"
#include <iostream>
int main() {
  namespace v = fc01::vision;
  v::Config c;
  c.enabled = true;
  v::Controller core(c);
  v::Input in;
  in.ros_now_ns = 100000000000ULL;
  in.state_publishers = in.command_publishers = 1;
  in.state.sequence = in.command.sequence = 1;
  in.state.stamp_ns = in.command.stamp_ns = in.ros_now_ns;
  in.state.received_at = in.command.received_at = 10;
  in.state.frame_id = in.command.frame_id = "fc01_vision_ned";
  in.state.body_frame_id = "base_link_frd";
  in.state.source_id.assign(1024 * 1024, 's');
  in.command.source_id.assign(1024 * 1024, 'c');
  in.state.initialized = in.state.tracking = in.state.calibration_valid = in.command.valid = true;
  in.state.valid_fields = v::Position | v::Velocity | v::Attitude | v::Quality;
  in.state.position = in.state.velocity = {0, 0, 0};
  in.state.attitude = {1, 0, 0, 0};
  in.state.quality = .9;
  in.command.mode = v::Mode::Hold;
  const auto result = core.step(in, 10, .5, 0, .05);
  std::cout << "state_source_bytes=" << in.state.source_id.size()
            << " command_source_bytes=" << in.command.source_id.size()
            << " active=" << result.active << " current=" << core.current(in, 10)
            << " reason=" << result.reason << '\n';
  return result.active && core.current(in, 10) ? 0 : 1;
}
