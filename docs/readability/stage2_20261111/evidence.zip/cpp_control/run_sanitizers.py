import subprocess,pathlib,json,hashlib,os,concurrent.futures,datetime,time
root=pathlib.Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
cache=pathlib.Path('/home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/cpp_control/sanitizers');cache.mkdir(exist_ok=True)
include=root/'native/src/jikl_fc01_system/include'
source_hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted([*include.rglob('*.hpp'),*(root/'native/tests').glob('*.cpp'),*(root/'native/tests').glob('*.hpp')])}
(cache/'source_hashes.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
names=['test_runtime_history_capacity','test_vision_navigation','test_visual_runtime','test_rc_navigation','test_async_log','test_receive_events','test_receive_schedule_safety','test_publication_runtime','test_velocity_command_input','test_stage2_control_trace']
flags=['g++','-std=c++17','-O1','-g','-fno-omit-frame-pointer','-fsanitize=address,undefined','-fno-pie','-no-pie','-pthread','-Wall','-Wextra','-Werror','-pedantic','-I'+str(include)]
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
def run(name):
 source=root/'native/tests'/(name+'.cpp');binary=cache/name
 command=[*flags,str(source),'-o',str(binary)]
 (cache/(name+'.command.json')).write_text(json.dumps({'compile':command,'run':[str(binary)],'env':{k:env[k]for k in ['ASAN_OPTIONS','UBSAN_OPTIONS']}},indent=2)+'\n')
 started=time.monotonic()
 with (cache/(name+'.compile.log')).open('w')as log:
  compiled=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 record={'name':name,'compile_command':command,'compile_exit':compiled.returncode}
 if compiled.returncode==0:
  with (cache/(name+'.run.log')).open('w')as log:
   executed=subprocess.run([str(binary)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
  record['run_exit']=executed.returncode
  data=(cache/(name+'.run.log')).read_bytes();record['log_sha256']=hashlib.sha256(data).hexdigest();record['log_bytes']=len(data)
 record['wall_seconds']=round(time.monotonic()-started,3)
 (cache/(name+'.result.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'name':name,'compile_exit':record['compile_exit'],'run_exit':record.get('run_exit'),'seconds':record['wall_seconds']}),flush=True)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(run,names))
changed=[name for name,digest in source_hashes.items()if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest]
report={'kind':'ASan + UBSan','compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'executed_programs':len(results),'passed':sum(r.get('run_exit')==0 for r in results),'source_changed_during_run':changed,'source_hashes':'source_hashes.json','environment':{k:env[k]for k in ['ASAN_OPTIONS','UBSAN_OPTIONS']},'results':results,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(cache/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
assert report['passed']==len(results) and not changed
print('SANITIZERS_PASS',len(results),flush=True)
