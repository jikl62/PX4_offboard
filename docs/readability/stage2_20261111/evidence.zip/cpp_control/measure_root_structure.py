import subprocess,pathlib,json,hashlib,sys,tempfile
root=pathlib.Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
cache=pathlib.Path('/home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/cpp_control')
baseline=cache.parent/'baseline'
sys.path.insert(0,str(root/'native/tests'))
import test_rc_recovery_adapter as fixture
items={
'native/src/jikl_fc01_system/include/jikl_fc01_system/runtime.hpp':('fc01::Runtime',['request','ack','step']),
'native/src/jikl_fc01_system/include/jikl_fc01_system/unix_server.hpp':('fc01::UnixServer',['poll']),
'native/src/jikl_fc01_system/include/jikl_fc01_system/publication_guard.hpp':('fc01::attitude::attitude_publication_policy',['attitude_publication_policy']),
'native/src/jikl_fc01_system/src/fc01_system_node.cpp':('SystemNode',['SystemNode','tick','snapshot','state']),
}
controls={'IfStmt','ForStmt','CXXForRangeStmt','WhileStmt','DoStmt','SwitchStmt','CXXTryStmt','CXXCatchStmt'}
def control_depth(node,depth=0):
 d=depth+int(node['kind'] in controls)
 return max([d]+[control_depth(i,d) for i in node.get('inner',[]) if 'kind'in i])
def functions(node):
 if node.get('kind') in {'CXXMethodDecl','CXXConstructorDecl','FunctionDecl'}:
  body=[i for i in node.get('inner',[]) if i.get('kind')=='CompoundStmt']
  if body:yield node,body[0]
 else:
  for child in node.get('inner',[]):
   if child.get('kind') in {'CXXMethodDecl','CXXConstructorDecl','FunctionDecl','FunctionTemplateDecl'}:yield from functions(child)
def line_number(source,location):return source[:location['offset']].count(b'\n')+1
rows=[]
for name,(filter_name,targets) in items.items():
 entry={'path':name,'scope':filter_name}
 for variant,tree in [('before',baseline),('after',root)]:
  p=tree/name;data=p.read_bytes()
  flags=['-I'+str(tree/'native/src/jikl_fc01_system/include')]
  if p.suffix=='.cpp':
   temp=pathlib.Path(tempfile.mkdtemp(prefix='node_metrics_'+variant+'_',dir=cache))
   old=fixture.fixture.ROOT;fixture.fixture.ROOT=tree/'native'
   try:fixture.write_fixture(temp)
   finally:fixture.fixture.ROOT=old
   source='#include <cstdint>\nextern double recovery_test_steady;\nextern std::int64_t recovery_test_wall_ns;\n#include "adapter_under_test.cpp"\n'
   flags+=['-I'+str(temp)]
   data=(temp/'adapter_under_test.cpp').read_bytes()
  else:source='#include "jikl_fc01_system/'+p.name+'"\n'
  cmd=['clang++','-std=c++17','-fsyntax-only',*flags,'-Xclang','-ast-dump=json','-Xclang','-ast-dump-filter='+filter_name,'-x','c++','-']
  run=subprocess.run(cmd,input=source,text=True,capture_output=True)
  assert run.returncode==0,(name,run.stderr)
  ast=json.loads(run.stdout)
  asts=[ast]
  if name.endswith('publication_guard.hpp'):
   for helper in ['attitude_target_policy','rc_preparation_output_policy']:
    helper_cmd=[v.replace(filter_name,'fc01::attitude::'+helper) for v in cmd]
    extra=subprocess.run(helper_cmd,input=source,text=True,capture_output=True)
    assert extra.returncode==0,(helper,extra.stderr)
    if extra.stdout.strip():asts.append(json.loads(extra.stdout))
  metrics={}
  for method,body in [f for a in asts for f in functions(a)]:
   start=line_number(data,method['range']['begin']);end=line_number(data,method['range']['end'])
   def count(n):return int(n.get('kind')in controls)+sum(count(i)for i in n.get('inner',[]))
   metrics[method['name']]={'physical_lines':end-start+1,'start':start,'end':end,'max_control_nesting':control_depth(body),'control_statement_count':count(body)}
  entry[variant]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'methods':metrics}
 entry['targets']={name:{'before':entry['before']['methods'][name],'after':entry['after']['methods'][name]}for name in targets}
 entry['new_helpers']=sorted(set(entry['after']['methods'])-set(entry['before']['methods']))
 rows.append(entry)
report={'method':'Clang 14 JSON AST; physical source range lines; control nesting counts nested If/For/RangeFor/While/Do/Switch/Try/Catch, including else-if AST nesting. Node uses existing deterministic fixture with only clock/access/main test substitutions.','files':rows}
(cache/'root_structure_metrics.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for entry in rows:
 print(entry['path'])
 for name,metrics in entry['targets'].items():print(name,metrics['before']['physical_lines'],metrics['after']['physical_lines'],'nesting',metrics['before']['max_control_nesting'],metrics['after']['max_control_nesting'])
 print('helpers',', '.join(entry['new_helpers']))
