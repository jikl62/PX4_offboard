from pathlib import Path
p=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028/native/src/jikl_fc01_system/include/jikl_fc01_system/attitude_altitude_core.hpp')
s=p.read_text()
helpers=''
for phase,next_phase,name,params,args,docs in [
 ('RequestArm','ArmedGround','advance_requested_arm','const Feedback& s, double now, const Transaction& arm, double elapsed, Output& out','s, now, arm, elapsed, out','''  // 推进程序 Arm 事务阶段；s 为同帧 NED/wxyz 反馈，now/elapsed 为单调秒，arm 为 Runtime 事务摘要。
  // 返回 false 对应原 step 的空计划早退，true 则继续原公共尾部；通过 out 引用保留同帧受限下降/零输出。
  // 仅写 Core 的 Arm/恢复阶段、证据及垂向状态，不发送命令；必须在公共健康/权限/参考检查之后调用。
  // ACK、严格新 armed 状态、迟到 Arm 恢复与原取消优先级完全保留，不能在 helper 返回后再处理另一阶段。
'''),
 ('ThrustRamp',None,'advance_thrust_ramp','const Feedback& s, double now, double elapsed, Output& out','s, now, elapsed, out','''  // 推进起飞斜坡及离地证据；s 使用原 PX4 NED/源微秒，now/elapsed 为单调秒，out 为本次已有计划。
  // 返回 false 必须让 step 立即返回空计划，true 才继续公共发布前校验；不直接发布、不把时间或推力当作离地。
  // 会写垂向积分/slew、轨迹、离地窗口和阶段；先绝对超时恢复，再在仍为 ThrustRamp 时推进原分段斜坡。
  // 保留同帧超时减推力、反馈提前制动、检测器证明与 Ascend 切换顺序，不能把这些判断合并为单次阶段快照。
''')]:
 marker='    } else if (phase_ == Phase::'+phase+') {\n'
 start=s.index(marker,s.index('  Output step('))
 if next_phase:
  end=s.index('    } else if (phase_ == Phase::'+next_phase+') {',start)
 else:
  end=s.index('    } else if (phase_ == Phase::Ascend ||',start)
 block=s[start+len(marker):end]
 block='\n'.join(line[2:] if line.startswith('  ') else line for line in block.splitlines())+'\n'
 assert 'return out;' not in block
 block=block.replace('return {};','return false;')
 s=s[:start]+marker+'      if (!'+name+'('+args+'))\n        return {};\n'+s[end:]
 helpers+=docs+'  bool '+name+'('+params+') {\n'+block+'    return true;\n  }\n'
# Keep independent source counts and diagnostic priority as literal blocks, but give them names.
start=s.index('    // DDS sources advance independently.',s.index('  void observe_rc_recovery('))
end=s.index('    // The detector observations themselves',start)
block=s[start:end]
s=s[:start]+'    record_rc_recovery_sources(s, now);\n'+s[end:]
helpers+='''  // 接受已通过恢复窗口与导数检查的样本，分别累计 status/local/land 的严格新源戳，now 为单调秒。
  // 无返回值，仅写本轮恢复证据水位、计数和最后 NED 样本；不授予恢复、不清故障。
  // 必须在 discontinuity 处理与垂向检查之后、恢复就绪计算之前；独立 DDS 源不能强迫成对推进。
  void record_rc_recovery_sources(const Feedback& s, double now) {
'''+block+'  }\n'
start=s.index('    if (rc_recovery_ready_)\n',s.index('  void observe_rc_recovery('))
end=s.index('\n  }\n  // PX4 Land后备',start)
block=s[start:end]
s=s[:start]+'    update_rc_recovery_reason(discontinuity, vertical.position_window_checked);'+s[end:]
block=block.replace('vertical.position_window_checked','position_window_checked')
helpers+='''  // 只更新恢复等待文本；参数是本轮是否重开证明及垂向窗口是否成立，返回 void。
  // rc_recovery_ready_ 和各源计数已由 observe_rc_recovery 算好，保留原首个未满足条件优先级。
  // 必须最后调用，不移动/删除真实门槛，也不能靠修改显示文本授予新任务或动力权限。
  void update_rc_recovery_reason(bool discontinuity, bool position_window_checked) {
'''+block+'\n  }\n'
s=s.replace('private:\n','private:\n'+helpers,1)
s=s.replace('  // 先健康/权限/时钟/参考，再推进阶段，最后检查输出有限性；长函数保留以便本轮严格保持状态顺序。','  // 先健康/权限/时钟/参考，再按原阶段顺序推进；Arm 和斜坡分支单独命名，最终公共输出校验仍留在本步。')
p.write_text(s)
