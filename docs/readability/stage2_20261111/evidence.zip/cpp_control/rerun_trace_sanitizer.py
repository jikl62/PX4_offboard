import subprocess,pathlib,json,hashlib,os,datetime,time,shutil
root=pathlib.Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
cache=pathlib.Path('/home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/cpp_control/sanitizers')
name='test_stage2_control_trace';source=root/'native/tests'/(name+'.cpp');binary=cache/name
for item in ['summary.json','source_hashes.json',name+'.command.json',name+'.compile.log',name+'.run.log',name+'.result.json']:
 shutil.copy2(cache/item,cache/('pre_full_lifecycle_'+item))
record=json.loads((cache/(name+'.command.json')).read_text())
env=dict(os.environ,**record['env']);started=time.monotonic()
with (cache/(name+'.compile.log')).open('w')as log:p=subprocess.run(record['compile'],stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert p.returncode==0
with (cache/(name+'.run.log')).open('w')as log:p=subprocess.run(record['run'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
assert p.returncode==0
runlog=(cache/(name+'.run.log')).read_bytes()
result={'name':name,'compile_command':record['compile'],'compile_exit':0,'run_exit':0,'log_sha256':hashlib.sha256(runlog).hexdigest(),'log_bytes':len(runlog),'wall_seconds':round(time.monotonic()-started,3),'reason':'Added full production-candidate 1.5m lifecycle trace only; no production change.'}
(cache/(name+'.result.json')).write_text(json.dumps(result,indent=2)+'\n')
summary=json.loads((cache/'summary.json').read_text());hashes=json.loads((cache/'source_hashes.json').read_text())
changed=[n for n,h in hashes.items()if hashlib.sha256((root/n).read_bytes()).hexdigest()!=h]
assert changed==['native/tests/test_stage2_control_trace.cpp'],changed
hashes['native/tests/test_stage2_control_trace.cpp']=hashlib.sha256(source.read_bytes()).hexdigest()
summary['results']=[result if r['name']==name else r for r in summary['results']]
summary['followup']='Full-lifecycle trace added after first 10/10 run. All other source hashes identical; rebuilt and re-executed modified trace under ASan/UBSan. The 10 unique final programs pass; trace executed twice, not counted as 11 unique programs.'
summary['source_changed_during_run']=[];summary['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(cache/'source_hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
(cache/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('FINAL_ASAN_UBSAN_10_PROGRAMS_PASS',result['wall_seconds'],result['log_bytes'])
