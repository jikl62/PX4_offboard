from pathlib import Path
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028/native/src/jikl_fc01_system/include/jikl_fc01_system')
def change(name,fn):
 p=root/name;s=p.read_text();p.write_text(fn(s))
def one(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
def guard(s):
 start=s.index('    // 两个输出虽同为向下速度')
 end=s.index('    // Integrate the position derivative',start)
 block=s[start:end]
 s=s[:start]+'    observe_rate_disagreement(stamp, vz, z_deriv);\n'+s[end:]
 docs='''  // 记录一个严格新采样的速度差诊断；stamp 为 PX4 微秒，两个速度均为 NED 下正 m/s。
  // 仅修改 e_ 的诊断字段和 bad_since_，不返回授权、不锁存硬故障。必须在输入/时钟检查之后、位置积分之前调用。
  void observe_rate_disagreement(std::uint64_t stamp, double vz, double z_deriv) {
'''
 s=one(s,'private:\n','private:\n'+docs+block+'  }\n')
 start=s.index('    // 首个可信新样本保存窗口起点 z')
 end=s.index('    // 最后提交本帧采样水位',start)
 block=s[start:end].replace('          return fail("VERTICAL_POSITION_RATE_INCONSISTENT");','          return false;')
 s=s[:start]+'''    if (!observe_position_window(stamp, z, z_deriv, dt))
      return fail("VERTICAL_POSITION_RATE_INCONSISTENT");
'''+s[end:]
 docs='''  // 对当前新样本推进位置/导数窗口；z 为 NED m，z_deriv 为下正 m/s，dt 为相邻源采样秒数。
  // 返回 false 只表示窗口残差越限，由 observe 在原位置锁存同一硬故障；此时不提交 last_stamp_/last_rate_。
  // 本函数修改窗口积分和 e_ 的位置证据，必须在速度差诊断之后、最后样本水位提交之前调用。
  bool observe_position_window(std::uint64_t stamp, double z, double z_deriv, double dt) {
'''
 s=one(s,'private:\n','private:\n'+docs+block+'    return true;\n  }\n')
 return s
change('vertical_feedback_guard.hpp',guard)
def vertical(s):
 start=s.index('    // 缺少当前可信 Z/Vz')
 end=s.index('    // 已锁定估计器参考后出现重置',start)
 block=s[start:end].replace('return bad(', 'return ').replace(');',';')
 # Keep predicate evaluation and error priority exactly as before; no mutable state in helper.
 s=s[:start]+'''    if (const auto error = input_error(s, target, dt, velocity_feedforward, takeoff_ceiling))
      return bad(error);
'''+s[end:]
 docs='''  // 只读核验本轮闭环输入，按原优先级返回首个英文错误码，成功返回 nullptr。
  // s 使用 NED m/m/s，target 为上正 m，dt 为秒，feedforward 为上正 m/s，ceiling 为归一化推力。
  // 不更新估计器计数、积分或推力；必须先调用，再让 step 接受 reset 水位和计算外环。
  static const char* input_error(const VerticalSample& s, double target, double dt,
                                 double velocity_feedforward, double takeoff_ceiling) {
'''
 s=one(s,'private:\n','private:\n'+docs+block+'    return nullptr;\n  }\n')
 start=s.index('    // 只有误差不会继续把输出推向受限方向时才提交 trial')
 end=s.index('    // 用实际接受的积分重新算推力',start)
 block=s[start:end]
 s=s[:start]+'    accept_integral(trial, raw, reachable, error);\n'+s[end:]
 docs='''  // 在原可达推力已算出后决定是否接受试算积分；各参数都是本次 step 已按原公式算出的标量。
  // 仅更新 integral_；冻结时不写入。先允许不加剧约束的积分，再允许已有积分退零，不能交换判断顺序。
  // 必须在 trial→raw→reachable 之后、重新计算 raw 和调用 slew 限制之前执行，不重排浮点运算。
  void accept_integral(double trial, double raw, double reachable, double error) {
'''
 return one(s,'private:\n','private:\n'+docs+block+'  }\n')
change('vertical_controller.hpp',vertical)
def authority(s):
 start=s.index('    // 归一化 roll/pitch/yaw')
 end=s.index('\n  }\n\n  template <class Switches>',start)
 block=s[start:end]
 s=s[:start]+'    observe_manual_axes(message);'+s[end:]
 docs='''  // 保存已接受 RC 源的四轴安全证据；输入为 PX4 归一化杆量，缺字段时明确无轴证据。
  // 只更新 throttle_/axes_safe_，无返回值；必须在 envelope/raw 双时间戳提交和源选择之后调用。
  // 本函数不能给无效源补成安全中杆，也不改变两个时钟或 RC 控制权。
  template <class Manual> void observe_manual_axes(const Manual& message) {
    using M = std::decay_t<Manual>;
'''
 s=one(s,'private:\n','private:\n'+docs+block+'\n  }\n')
 start=s.index('    // 保存模式/解锁/返航/盘旋/Offboard/Kill')
 end=s.index('\n  }\n\n  // 组合当前来源数量',start)
 block=s[start:end]
 s=s[:start]+'    observe_switch_values(message, timeout);'+s[end:]
 docs='''  // 提交已通过双时间戳检查的原始开关载荷，timeout 单位秒；返回 void，不直接改变 Core 阶段。
  // 修改开关缓存、generation 和遥测 Kill 锁存；ON 立即锁存，OFF 仍须源采样贴近 envelope。
  // 必须在 switch/sample 时间水位提交后调用；无效时钟 ON 的早期否决仍留在 switches 中，不能合并。
  template <class Switches> void observe_switch_values(const Switches& message, double timeout) {
'''
 return one(s,'private:\n','private:\n'+docs+block+'\n  }\n')
change('authority_telemetry.hpp',authority)
def types(s):
 start=s.index('    feedback_guard.validate();')
 end=s.index('    if (flight_actions_enabled)',start)
 prep=s[start:end]
 start2=end
 end2=s.index('\n  }\n};',start2)
 flight=s[start2:end2]
 s=s[:start]+'    validate_preparation();\n    validate_flight_limits();'+s[end2:]
 # These remain public like existing struct fields: no ABI/layout change; const helper only.
 insert='''
  // 校验准备、时间窗口、bench 与恢复合同；无参数/返回值，失败抛原有首个 invalid_argument。
  // 只读配置，不改状态或参数。必须在视觉/RC 交叉校验之后、完整动力限制之前，保留原异常优先级。
  void validate_preparation() const {
'''+prep+'''  }
  // 仅动作门开启时核验完整动力包络；推力无量纲、时间 s、高度 m、速度 m/s、倾角 deg。
  // 无参数/返回值，失败抛原错误码；不修改配置，不推测实机参数。保持确认声明→vertical→飞行限制顺序。
  void validate_flight_limits() const {
'''+flight+'''\n  }
'''
 marker='\n};\n// ROS适配器每轮生成的实际飞机快照'
 s=one(s,marker,insert+marker)
 return s
change('attitude_types.hpp',types)
