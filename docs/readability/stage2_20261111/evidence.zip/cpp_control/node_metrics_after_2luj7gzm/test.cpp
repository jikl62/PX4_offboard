
#include <cstdint>
double recovery_test_steady=0.;
std::int64_t recovery_test_wall_ns=0;
#include "adapter_under_test.cpp"
#define main rc_recovery_fixture_main
#include "test_rc_navigation.cpp"
#undef main
#include <cassert>

struct RecoveryNode {
  SystemNode node;
  fc01::Config config;
  std::uint64_t stamp{};
  unsigned retained_local_events{};
  bool armed{},offboard{},landed{true};
  fc01::attitude::Quaternion measured_q{1,0,0,0};
  double now{};
  int observer{-1};
  RecoveryNode(){
    // Start with a real RC-authorized attempt and observe actual PX4 departure.
    Flight flight(production_no_vision_rc_config());flight.join();
    flight.s.feedback.offboard=false;flight.s.nav_state=15;
    flight.s.attitude.rc_mode_slot=6;++flight.s.attitude.operator_switch_generation;flight.tick();
    assert(flight.r.attitude_core().reason()=="OPERATOR_TAKEOVER_LATCHED");
    config=flight.c;now=flight.t;stamp=flight.s.status_stamp;
    recovery_test_steady=now;recovery_test_wall_ns=std::int64_t(stamp)*1000;
    node.config_=config;node.runtime_=std::make_unique<fc01::Runtime>(std::move(flight.r));
    node.mode_pub_=node.create_publisher<Mode>("/fmu/in/offboard_control_mode",10);
    node.attitude_pub_=node.create_publisher<AttitudeTarget>("/fmu/in/vehicle_attitude_setpoint",10);
    node.graph_count=[](const std::string& topic,bool publishers){
      if(publishers&&(topic=="/fmu/in/trajectory_setpoint"||topic=="/fmu/in/vehicle_rates_setpoint"||
        topic=="/fmu/in/vehicle_thrust_setpoint"||topic=="/fmu/in/vehicle_torque_setpoint"||
        topic=="/fmu/in/actuator_motors"))return std::size_t(0);
      return std::size_t(1);
    };
    // Keep the service supervisor's ordinary read-only IPC connection alive;
    // publication independently requires an attached status consumer.
    observer=::socket(AF_UNIX,SOCK_STREAM|SOCK_NONBLOCK|SOCK_CLOEXEC,0);
    assert(observer>=0);sockaddr_un address{};address.sun_family=AF_UNIX;
    std::strncpy(address.sun_path,std::getenv("FC01_SOCKET"),sizeof(address.sun_path)-1);
    assert(::connect(observer,reinterpret_cast<sockaddr*>(&address),sizeof(address))==0);
  }
  ~RecoveryNode(){if(observer>=0)::close(observer);}
  void local(std::uint64_t raw){
    Local value{};value.timestamp=value.timestamp_sample=raw;value.z=2;
    // A sustained velocity-output difference is diagnostic. Position stays
    // within the independent derivative residual and physical rest limits.
    value.vz=.09f;value.z_deriv=-.15f;value.z_valid=value.v_z_valid=true;
    const auto previous=node.local_;
    node.receive_sampled(value,node.local_,node.local_stamp_,node.local_sample_,
      fc01::SourceSlot::Local,rclcpp::MessageInfo{});
    if(fc01::local_receive_event(previous,value,node.config_.attitude)||
       node.runtime_->attitude_core().local_requires_control_step(
         value.timestamp_sample,value.z,value.vz,value.z_deriv)){
      node.latch_event(node.local_events_,value);++retained_local_events;
    }
  }
  void cycle(int unsafe=0){
    now+=.05;stamp+=50000;
    recovery_test_steady=now;recovery_test_wall_ns=std::int64_t(stamp)*1000;
    node.begin_cycle(now);
    Status status{};status.timestamp=stamp;status.system_id=status.component_id=1;
    status.arming_state=armed?Status::ARMING_STATE_ARMED:Status::ARMING_STATE_DISARMED;
    status.nav_state=offboard?Status::NAVIGATION_STATE_OFFBOARD:Status::NAVIGATION_STATE_STAB;
    status.pre_flight_checks_pass=status.power_input_valid=true;
    status.can_set_nav_states_mask=1U<<Status::NAVIGATION_STATE_STAB;
    node.receive_event(status,node.status_,node.status_stamp_,fc01::SourceSlot::Status,
      rclcpp::MessageInfo{},fc01::status_receive_event<Status>);
    Land land{};land.timestamp=stamp;land.landed=land.at_rest=landed;
    node.receive_event(land,node.land_,node.land_stamp_,fc01::SourceSlot::Land,
      rclcpp::MessageInfo{},fc01::land_receive_event<Land>);
    Battery battery{};battery.timestamp=stamp;battery.id=1;battery.connected=true;battery.voltage_v=7.6f;
    node.receive_event(battery,node.battery_,node.battery_stamp_,fc01::SourceSlot::Battery,
      rclcpp::MessageInfo{},fc01::battery_receive_event<Battery>);
    Flags flags{};flags.timestamp=stamp;
    node.receive_event(flags,node.flags_,node.flags_stamp_,fc01::SourceSlot::Flags,
      rclcpp::MessageInfo{},fc01::flags_receive_event<Flags>);
    Attitude attitude{};attitude.timestamp=attitude.timestamp_sample=stamp;
    for(unsigned i=0;i<4;++i)attitude.q[i]=float(measured_q[i]);
    node.receive_sampled(attitude,node.attitude_,node.attitude_stamp_,node.attitude_sample_,
      fc01::SourceSlot::Attitude,rclcpp::MessageInfo{});
    Manual manual{};manual.timestamp=manual.timestamp_sample=stamp;manual.valid=true;
    manual.data_source=Manual::SOURCE_RC;manual.throttle=-1;
    node.receive_manual(manual);
    Switches switches{};switches.timestamp=switches.timestamp_sample=stamp;
    switches.mode_slot=6;switches.arm_switch=switches.kill_switch=3;
    node.receive_switches(switches);
    // 40Hz local feedback, with both diagnostic observations retained before
    // each 20Hz tick. This previously reset the recovery proof every cycle.
    local(stamp-25000);local(stamp);
    if(unsafe==1){
      Attitude invalid=attitude;invalid.q={0,0,0,0};
      node.latch_event(node.attitude_events_,invalid);
      node.latch_event(node.attitude_events_,attitude);
    }else if(unsafe==2){
      Land moving=land;moving.landed=false;
      node.latch_event(node.land_events_,moving);node.latch_event(node.land_events_,land);
    }
    node.callbacks_done(now);
    assert(node.tick());
    char output[32768];while(::recv(observer,output,sizeof(output),0)>0){}
    // Recovery and readiness never emit automatic Arm, Offboard or Disarm.
    assert(node.command_pub_->calls==0);
    if(node.runtime_->rc_attempts_completed())
      assert(!node.runtime_->attitude_core().flight_started());
    assert(!fc01::attitude::nonzero(node.last_attitude_output_.thrust));
  }
  void remain_faulted(unsigned cycles,int unsafe=0){
    for(unsigned i=0;i<cycles;++i){cycle(unsafe);
      assert(node.runtime_->attitude_core().phase()==fc01::attitude::Phase::Safety);
      assert(node.runtime_->rc_attempts_completed()==0);
      assert(!node.last_attitude_output_.publish);
    }
  }
  void recover(){
    for(unsigned i=0;i<180&&node.runtime_->attitude_core().phase()!=fc01::attitude::Phase::RcWaitArm;++i)
      cycle();
    assert(node.runtime_->rc_attempts_completed()==1);
    assert(node.runtime_->last_rc_attempt_reason()=="OPERATOR_TAKEOVER_LATCHED");
    assert(node.runtime_->attitude_core().phase()==fc01::attitude::Phase::RcWaitArm);
    assert(!node.runtime_->attitude_core().authority_state().takeover_latched);
    assert(node.runtime_->attitude_core().rc_ground_reference_qualified());
    assert(node.last_attitude_output_.publish);
    assert(node.command_pub_->calls==0);
  }
};
int main(){
  {RecoveryNode n;n.recover();assert(n.retained_local_events>=80);
    std::cout<<"ACTUAL_TICK_DIAGNOSTIC_EVENT_RECOVERY_PASS\n";}
  for(int unsafe:{1,2}){RecoveryNode n;n.remain_faulted(100,unsafe);
    // One healthy tick cannot reuse proof accumulated before the unsafe event.
    n.cycle();assert(n.node.runtime_->rc_attempts_completed()==0);n.recover();}
  std::cout<<"ACTUAL_TICK_QUEUED_UNSAFE_EVIDENCE_VETO_PASS\n";
  for(int condition:{1,2}){RecoveryNode n;n.armed=condition==1;n.offboard=condition==2;
    n.remain_faulted(100);n.armed=n.offboard=false;n.cycle();
    assert(n.node.runtime_->rc_attempts_completed()==0);n.recover();}
  std::cout<<"ACTUAL_TICK_NO_ARMED_OR_OFFBOARD_REACQUIRE_PASS\n";
  {RecoveryNode n;n.node.runtime_->abort_attitude("PUBLISHER_BOUNDARY_TEST_INTEGRITY");
    n.remain_faulted(3);
    std::cout<<n.node.state(n.node.snapshot(n.now),n.now)<<std::endl;}
  std::cout<<"ACTUAL_TICK_LATER_FAULT_DIAGNOSTICS_PASS\n";
  for(int condition:{1,2}){
    RecoveryNode n;n.recover();
    const auto previous=n.node.last_attitude_output_;
    const auto previous_stamp=n.node.publication_audit_.mode_last;
    assert(previous.publish);
    n.armed=n.offboard=condition==1;n.landed=condition!=1;
    if(condition==1)n.measured_q={std::sqrt(.5),std::sqrt(.5),0,0};
    n.node.runtime_->abort_attitude("STREAM_EDGE_OBSERVED_STATUS_TEST");
    n.cycle();
    assert(!n.node.last_attitude_output_.publish);
    std::cout<<"{\"kind\":\"stream_edge_expected\",\"armed\":"<<boolean(n.armed)
      <<",\"offboard\":"<<boolean(n.offboard)<<",\"landed\":"<<boolean(n.landed)
      <<",\"status_stamp\":"<<n.stamp<<",\"land_stamp\":"<<n.stamp
      <<",\"local_stamp\":"<<n.stamp
      <<",\"attitude_tilt_deg\":"<<(condition==1?90:0)
      <<",\"previous_heartbeat_commit_monotonic_s\":"<<number(previous_stamp)
      <<",\"last_committed_target_thrust_z\":"<<number(previous.thrust[2])<<"}"<<std::endl;
  }
  std::cout<<"ACTUAL_TICK_STREAM_EDGE_CURRENT_STATUS_PASS\n";
}
