import subprocess,pathlib,json,hashlib
root=pathlib.Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
cache=pathlib.Path('/home/jikl62/.cache/fc01-stage2-20261111/run-s59h7rku/cpp_control')
baseline=cache.parent/'baseline'
items={
'attitude_altitude_core.hpp':('fc01::attitude::Core',['step','observe_safety_event','observe_rc_recovery']),
'attitude_types.hpp':('fc01::attitude::Config',['validate']),
'authority_telemetry.hpp':('fc01::AuthorityTelemetry',['manual','switches','facts']),
'rc_navigation.hpp':('fc01::attitude::RcNavigationStart',['step','observe_ground_reference']),
'velocity_core.hpp':('jikl_velocity::Core',['step']),
'vertical_controller.hpp':('fc01::attitude::VerticalController',['step']),
'vertical_feedback_guard.hpp':('fc01::attitude::VerticalFeedbackGuard',['observe']),
'vision_navigation.hpp':('fc01::vision::Controller',['step']),
}
controls={'IfStmt','ForStmt','CXXForRangeStmt','WhileStmt','DoStmt','SwitchStmt','CXXTryStmt','CXXCatchStmt'}
def control_depth(node,depth=0):
 d=depth+int(node['kind'] in controls)
 return max([d]+[control_depth(i,d) for i in node.get('inner',[]) if 'kind'in i])
def functions(node):
 for child in node.get('inner',[]):
  if child['kind']=='FunctionTemplateDecl':yield from functions(child)
  if child['kind'] in {'CXXMethodDecl','CXXConstructorDecl'}:
   body=[i for i in child.get('inner',[]) if i['kind']=='CompoundStmt']
   if body:yield child,body[0]
def line_number(source,location):return source[:location['offset']].count(b'\n')+1
rows=[]
for filename,(filter_name,targets) in items.items():
 entry={'path':'native/src/jikl_fc01_system/include/jikl_fc01_system/'+filename,'scope':filter_name}
 for variant,tree in [('before',baseline),('after',root)]:
  p=tree/entry['path'];data=p.read_bytes()
  cmd=['clang++','-std=c++17','-fsyntax-only','-I'+str(tree/'native/src/jikl_fc01_system/include'),'-Xclang','-ast-dump=json','-Xclang','-ast-dump-filter='+filter_name,'-x','c++','-']
  run=subprocess.run(cmd,input='#include "jikl_fc01_system/'+filename+'"\n',text=True,capture_output=True)
  assert run.returncode==0,(filename,run.stderr)
  ast=json.loads(run.stdout)
  metrics={}
  for method,body in functions(ast):
   start=line_number(data,method['range']['begin']);end=line_number(data,method['range']['end'])
   metrics[method['name']]={'physical_lines':end-start+1,'start':start,'end':end,'max_control_nesting':control_depth(body),'control_statement_count':0}
   def count(n):return int(n.get('kind')in controls)+sum(count(i)for i in n.get('inner',[]))
   metrics[method['name']]['control_statement_count']=count(body)
  entry[variant]={'sha256':hashlib.sha256(data).hexdigest(),'methods':metrics}
 entry['targets']={name:{'before':entry['before']['methods'][name],'after':entry['after']['methods'][name]}for name in targets}
 entry['new_helpers']=sorted(set(entry['after']['methods'])-set(entry['before']['methods']))
 rows.append(entry)
report={'method':'Clang 14 JSON AST; physical source range lines; control nesting counts nested If/For/RangeFor/While/Do/Switch/Try/Catch, including else-if AST nesting. Counts are structural indicators, not proof of control complexity or behavioral equivalence.','files':rows}
(cache/'structure_metrics.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for entry in rows:
 print(entry['path'])
 for name,metrics in entry['targets'].items():print(name,metrics['before']['physical_lines'],metrics['after']['physical_lines'],'nesting',metrics['before']['max_control_nesting'],metrics['after']['max_control_nesting'])
 print('helpers',', '.join(entry['new_helpers']))
