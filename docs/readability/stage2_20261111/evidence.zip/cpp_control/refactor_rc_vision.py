from pathlib import Path
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028/native/src/jikl_fc01_system/include/jikl_fc01_system')
p=root/'rc_navigation.hpp';s=p.read_text()
old='''    // 终止本轮准入并保留具体原因；是否能新任务重建由外层地面恢复判断。
    const auto block = [this](const std::string& why) {
      phase_ = RcStartPhase::Blocked;
      reason_ = why;
      return false;
    };
'''
assert old in s;s=s.replace(old,'',1)
start=s.index('    if (phase_ == RcStartPhase::Prestream) {',s.index('bool step('))
end=s.index('    // 只有严格新的开关采样',start)
block=s[start:end]
assert block.endswith('    }\n')
block=block[len('    if (phase_ == RcStartPhase::Prestream) {\n'):-len('    }\n')]
block='\n'.join(line[2:] if line.startswith('  ') else line for line in block.splitlines())+'\n'
s=s[:start]+'''    if (phase_ == RcStartPhase::Prestream)
      return step_prestream(c, s, now, arm_on, nav);
'''+s[end:]
helper='''  // 推进预发送阶段，参数均为 step 已核对的同一快照；now 是单调秒，arm_on/nav 是该快照开关状态。
  // 返回 true 仅许可零流；可写地面证据、提交计数和 READY 水位，不能产生 Arm 或非零推力。
  // 必须在 WaitGround 当帧转入 Prestream 后直接调用，保持原同帧累积和首次拒绝原因。
  template <class C, class F>
  bool step_prestream(const C& c, const F& s, double now, bool arm_on, bool nav) {
'''+block+'  }\n'
start=s.index('    if (phase_ == RcStartPhase::WaitNavigation) {',s.index('bool step('))
end=s.index('    return false;\n  }\n\nprivate:',start)
block=s[start:end]
assert block.endswith('    }\n')
block=block[len('    if (phase_ == RcStartPhase::WaitNavigation) {\n'):-len('    }\n')]
block='\n'.join(line[2:] if line.startswith('  ') else line for line in block.splitlines())+'\n'
s=s[:start]+'''    if (phase_ == RcStartPhase::WaitNavigation)
      return step_wait_navigation(c, s, now, arm_on, nav);
'''+s[end:]
helper+='''  // 在固定期限内配对人工解锁与导航，输入使用同一快照；源戳为 PX4 微秒，now 为单调秒，绝不跨域相减。
  // 返回 true 仅维持既有零流；false 表示 Joined 或 Blocked，原因/阶段仍由本对象持有。
  // 会写解锁 epoch、导航边沿及阶段；必须先检查过期再接收证据，且保持 WaitArm→WaitNavigation 的同帧调用。
  template <class C, class F>
  bool step_wait_navigation(const C& c, const F& s, double now, bool arm_on, bool nav) {
'''+block+'  }\n'
helper+='''  // 终止本轮准入，保留原拒绝文本；输入为首个拒绝原因，返回 false 供阶段函数直接早退。
  // 只写本对象 phase_/reason_，不清地面/授权历史；是否允许新任务重建仍由外层安全恢复决定。
  bool block(const std::string& why) {
    phase_ = RcStartPhase::Blocked;
    reason_ = why;
    return false;
  }
'''
s=s.replace('private:\n','private:\n'+helper,1)
p.write_text(s)
p=root/'velocity_core.hpp';s=p.read_text()
start=s.index('      // 超时目标立即替换为零')
end=s.index('    }\n    return o;\n  }\n\nprivate:',start)
block=s[start:end]
block='\n'.join(line[2:] if line.startswith('  ') else line for line in block.splitlines())+'\n'
s=s[:start]+'      return motion_output(f, t, dt);\n'+s[end:]
helper='''  // 计算已进入 Hold/Velocity/Brake 的运动计划；f 为同一 NED 快照，t/dt 为单调秒和已限幅积分步长。
  // 返回完整目标并更新滤波、yaw、制动 dwell/阶段；不发布命令、不跳过上层健康和权限检查。
  // 必须在 step 完成失令/模式/包络检查之后调用；坐标转换→向量限幅→滤波→yaw→制动确认的原顺序不变。
  Output motion_output(const Feedback& f, double t, double dt) {
    Output o;
'''+block+'    return o;\n  }\n'
s=s.replace('private:\n','private:\n'+helper,1)
p.write_text(s)
p=root/'vision_navigation.hpp';s=p.read_text()
start=s.index('    if (accepted_) {',s.index('Result step('))
end=s.index('    // 只在首次进入或模式变化时',start)
block=s[start:end]
assert block.endswith('    }\n')
block=block[len('    if (accepted_) {\n'):-len('    }\n')]
block='\n'.join(line[2:] if line.startswith('  ') else line for line in block.splitlines())+'\n'
import re
block=re.sub(r'return reject\(("[A-Z_]+")\);',r'return \1;',block)
s=s[:start]+'''    if (accepted_) {
      const auto continuity_error = accepted_input_error(in);
      if (!continuity_error.empty())
        return reject(continuity_error);
    }
'''+s[end:]
helper='''  // 对照已接受计划核验输入连续性；输入为已通过本帧状态/目标验证的 NED 快照，返回首个拒绝码或空串。
  // 本函数只读 accepted_input_，不提交新计划、不清撤销/下降锁存。source ns、接收 steady s 各自比较，不互换。
  // 必须在撤销代数/时钟/目标/实际状态校验之后、捕获原点与计算目标之前；保持所有拒绝优先级。
  std::string accepted_input_error(const Input& in) const {
'''+block+'    return {};\n  }\n'
s=s.replace('private:\n','private:\n'+helper,1)
p.write_text(s)
