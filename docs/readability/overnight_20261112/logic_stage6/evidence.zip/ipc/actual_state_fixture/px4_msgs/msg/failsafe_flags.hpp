#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct FailsafeFlags{using ConstSharedPtr=std::shared_ptr<const FailsafeFlags>;std::uint64_t timestamp{};static constexpr int MESSAGE_VERSION=0;bool manual_control_signal_lost{},offboard_control_signal_lost{},fd_critical_failure{};};}
