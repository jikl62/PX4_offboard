#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct TrajectorySetpoint{using ConstSharedPtr=std::shared_ptr<const TrajectorySetpoint>;std::uint64_t timestamp{};static constexpr int MESSAGE_VERSION=0;std::array<float,3> position{},velocity{},acceleration{},jerk{};float yaw{},yawspeed{};};}
