#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct OffboardControlMode{using ConstSharedPtr=std::shared_ptr<const OffboardControlMode>;std::uint64_t timestamp{};bool position{},velocity{},acceleration{},attitude{},body_rate{},thrust_and_torque{},direct_actuator{};};}
