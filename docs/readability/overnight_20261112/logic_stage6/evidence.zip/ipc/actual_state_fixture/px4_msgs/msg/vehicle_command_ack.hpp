#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct VehicleCommandAck{using ConstSharedPtr=std::shared_ptr<const VehicleCommandAck>;std::uint64_t timestamp{};static constexpr int MESSAGE_VERSION=0;std::uint32_t command{};std::uint8_t result{},target_system{};std::uint16_t target_component{};bool from_external{};};}
