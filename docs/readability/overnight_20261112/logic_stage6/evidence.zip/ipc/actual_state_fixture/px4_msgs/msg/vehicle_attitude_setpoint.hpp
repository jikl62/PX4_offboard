#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct VehicleAttitudeSetpoint{using ConstSharedPtr=std::shared_ptr<const VehicleAttitudeSetpoint>;std::uint64_t timestamp{};static constexpr int MESSAGE_VERSION=0;float yaw_sp_move_rate{};std::array<float,4> q_d{};std::array<float,3> thrust_body{};bool reset_integral{},fw_control_yaw_wheel{};};}
