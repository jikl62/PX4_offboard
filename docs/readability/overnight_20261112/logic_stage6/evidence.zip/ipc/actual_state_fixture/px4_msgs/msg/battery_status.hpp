#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct BatteryStatus{using ConstSharedPtr=std::shared_ptr<const BatteryStatus>;std::uint64_t timestamp{};static constexpr int MESSAGE_VERSION=0;int id{},warning{};float voltage_v{};bool connected{};};}
