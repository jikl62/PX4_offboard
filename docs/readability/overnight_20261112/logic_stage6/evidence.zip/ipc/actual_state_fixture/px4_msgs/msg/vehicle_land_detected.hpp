#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct VehicleLandDetected{using ConstSharedPtr=std::shared_ptr<const VehicleLandDetected>;std::uint64_t timestamp{};static constexpr int MESSAGE_VERSION=0;bool at_rest{},landed{};};}
