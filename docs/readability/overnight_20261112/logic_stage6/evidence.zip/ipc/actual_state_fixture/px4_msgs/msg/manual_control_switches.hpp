#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct ManualControlSwitches{using ConstSharedPtr=std::shared_ptr<const ManualControlSwitches>;std::uint64_t timestamp{};std::uint64_t timestamp_sample{};std::uint8_t mode_slot{},arm_switch{},return_switch{},loiter_switch{},offboard_switch{},kill_switch{};std::uint32_t switch_changes{};};}
