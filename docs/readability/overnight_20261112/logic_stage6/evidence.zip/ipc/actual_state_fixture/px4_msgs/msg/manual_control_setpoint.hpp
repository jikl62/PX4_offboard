#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct ManualControlSetpoint{using ConstSharedPtr=std::shared_ptr<const ManualControlSetpoint>;std::uint64_t timestamp{};static constexpr int MESSAGE_VERSION=0;static constexpr std::uint8_t SOURCE_UNKNOWN=0,SOURCE_RC=1,SOURCE_MAVLINK_0=2,SOURCE_MAVLINK_1=3,SOURCE_MAVLINK_2=4,SOURCE_MAVLINK_3=5,SOURCE_MAVLINK_4=6,SOURCE_MAVLINK_5=7;std::uint64_t timestamp_sample{};bool valid{};std::uint8_t data_source{};float roll{},pitch{},yaw{},throttle{},flaps{},aux1{},aux2{},aux3{},aux4{},aux5{},aux6{};bool sticks_moving{};std::uint16_t buttons{};};}
