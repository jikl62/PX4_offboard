#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct VehicleLocalPosition{using ConstSharedPtr=std::shared_ptr<const VehicleLocalPosition>;std::uint64_t timestamp{};static constexpr int MESSAGE_VERSION=0;std::uint64_t timestamp_sample{};float x{},y{},z{},vx{},vy{},vz{},z_deriv{},ax{},ay{},az{},heading{};bool xy_valid{},z_valid{},v_xy_valid{},v_z_valid{},heading_good_for_control{},dead_reckoning{};std::uint8_t xy_reset_counter{},z_reset_counter{},vxy_reset_counter{},vz_reset_counter{},heading_reset_counter{};};}
