#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct VehicleCommand{using ConstSharedPtr=std::shared_ptr<const VehicleCommand>;std::uint64_t timestamp{};static constexpr int MESSAGE_VERSION=0;static constexpr std::uint32_t VEHICLE_CMD_DO_SET_MODE=176,VEHICLE_CMD_COMPONENT_ARM_DISARM=400,VEHICLE_CMD_NAV_LAND=21;std::uint32_t command{};float param1{},param2{};std::uint8_t target_system{},target_component{},source_system{},source_component{};bool from_external{};};}
