#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct VehicleStatus{using ConstSharedPtr=std::shared_ptr<const VehicleStatus>;std::uint64_t timestamp{};static constexpr int MESSAGE_VERSION=1;static constexpr int HIL_STATE_OFF=0,NAVIGATION_STATE_STAB=15,NAVIGATION_STATE_OFFBOARD=14,NAVIGATION_STATE_AUTO_LAND=18,NAVIGATION_STATE_TERMINATION=13,ARMING_STATE_DISARMED=1,ARMING_STATE_ARMED=2;bool calibration_enabled{},rc_calibration_in_progress{},pre_flight_checks_pass{},power_input_valid{},failsafe{},failsafe_and_user_took_over{};std::uint8_t system_id{},component_id{},hil_state{},nav_state{},arming_state{},latest_arming_reason{};std::uint64_t armed_time{};std::uint32_t can_set_nav_states_mask{};};}
