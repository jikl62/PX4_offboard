#pragma once
#include <array>
#include <cstdint>
#include <memory>
namespace px4_msgs::msg {struct VehicleAttitude{using ConstSharedPtr=std::shared_ptr<const VehicleAttitude>;std::uint64_t timestamp{};static constexpr int MESSAGE_VERSION=0;std::uint64_t timestamp_sample{};std::array<float,4> q{};std::array<float,4> delta_q_reset{};std::uint8_t quat_reset_counter{};};}
