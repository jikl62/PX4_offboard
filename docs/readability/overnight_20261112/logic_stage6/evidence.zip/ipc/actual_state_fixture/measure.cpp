
#include <cstdint>
double recovery_test_steady=1.;
std::int64_t recovery_test_wall_ns=1000000000;
#include "adapter_under_test.cpp"
#include <cassert>
#include <fstream>
int main(){
  SystemNode node; // fakeROS Node基类，不初始化真实ROS，也不调用tick/step
  assert(node.config_.profile=="ground");
  int client=socket(AF_UNIX,SOCK_STREAM|SOCK_NONBLOCK|SOCK_CLOEXEC,0);assert(client>=0);
  sockaddr_un address{};address.sun_family=AF_UNIX;
  const auto path=std::getenv("FC01_SOCKET");assert(path);
  std::memcpy(address.sun_path,path,std::strlen(path)+1);
  assert(connect(client,reinterpret_cast<sockaddr*>(&address),sizeof(address))==0);
  std::string payload;for(unsigned i=1;i<=350;++i)payload+=std::to_string(i)+" STATUS\n";
  assert(payload.size()<4096);
  assert(send(client,payload.data(),payload.size(),MSG_NOSIGNAL)==ssize_t(payload.size()));
  unsigned calls=0,dropped=0;std::size_t response_bytes=0,first_reply_bytes=0;
  auto snapshot=node.snapshot(1.);
  const auto start=std::chrono::steady_clock::now();
  node.server_->poll([&](const fc01::Request& request){
    ++calls;auto reply=node.runtime_->request(request.op,request.values,snapshot,1.);
    auto response=node.state(snapshot,1.,"reply",request.seq,reply.accepted,reply.message);
    if(calls==1){first_reply_bytes=response.size();std::ofstream("actual_state_first_reply.json")<<response<<'\n';}
    response_bytes+=response.size()+1;return response;
  },[&]{++dropped;});
  const auto elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
  assert(calls==350&&node.server_->connected()&&response_bytes>65536);
  assert(node.command_pub_->calls==0&&!node.mode_pub_&&!node.attitude_pub_&&!node.target_pub_);
  std::cout<<"ACTUAL_STATE_BURST {\"calls\":"<<calls<<",\"payload_bytes\":"<<payload.size()
    <<",\"first_reply_bytes\":"<<first_reply_bytes<<",\"response_bytes\":"<<response_bytes
    <<",\"first_poll_seconds\":"<<elapsed<<",\"power_publish_calls\":0,\"drop_before_second_poll\":"<<dropped<<"}\n";
  node.server_->poll([](const fc01::Request&){assert(false);return std::string{};},[&]{++dropped;});
  assert(!node.server_->connected()&&dropped==1);
  close(client);
}
