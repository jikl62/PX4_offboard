#pragma once
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include "jikl_fc01_system/msg/stamp.hpp"
namespace jikl_fc01_system::msg {struct NavigationCommand{using ConstSharedPtr=std::shared_ptr<const NavigationCommand>;std::uint16_t schema_version{1};std::uint64_t sequence{};Stamp stamp;std::uint32_t reset_counter{};std::string source_id,frame_id;std::uint8_t mode{};bool valid{},position_valid{},yaw_valid{},sticks_valid{};std::array<double,3> position{};double yaw{};std::array<double,4> sticks{};};}
