#pragma once
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include "jikl_fc01_system/msg/stamp.hpp"
namespace jikl_fc01_system::msg {struct VisionState{using ConstSharedPtr=std::shared_ptr<const VisionState>;std::uint16_t schema_version{1};std::uint16_t valid_fields{};std::uint64_t sequence{};Stamp stamp;std::uint32_t reset_counter{};std::string frame_id,body_frame_id,source_id,angular_velocity_source;bool initialized{},tracking{},calibration_valid{};std::array<double,3> position{},velocity{},angular_velocity{};std::array<double,4> attitude{};std::array<double,36> pose_covariance{},twist_covariance{};double quality{};};}
