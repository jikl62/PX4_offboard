"""只编译fake-ROS中的真实状态编码，不执行生产main、tick或任何发布sink。"""
import hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028');c=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'native/tests'))
import test_rc_recovery_adapter as fixture
build=c/'actual_state_fixture';build.mkdir(mode=0o700,exist_ok=True)
fixture.write_fixture(build)
source=r'''
#include <cstdint>
double recovery_test_steady=1.;
std::int64_t recovery_test_wall_ns=1000000000;
#include "adapter_under_test.cpp"
#include <cassert>
#include <fstream>
int main(){
  SystemNode node; // fakeROS Node基类，不初始化真实ROS，也不调用tick/step
  assert(node.config_.profile=="ground");
  int client=socket(AF_UNIX,SOCK_STREAM|SOCK_NONBLOCK|SOCK_CLOEXEC,0);assert(client>=0);
  sockaddr_un address{};address.sun_family=AF_UNIX;
  const auto path=std::getenv("FC01_SOCKET");assert(path);
  std::memcpy(address.sun_path,path,std::strlen(path)+1);
  assert(connect(client,reinterpret_cast<sockaddr*>(&address),sizeof(address))==0);
  std::string payload;for(unsigned i=1;i<=350;++i)payload+=std::to_string(i)+" STATUS\n";
  assert(payload.size()<4096);
  assert(send(client,payload.data(),payload.size(),MSG_NOSIGNAL)==ssize_t(payload.size()));
  unsigned calls=0,dropped=0;std::size_t response_bytes=0,first_reply_bytes=0;
  auto snapshot=node.snapshot(1.);
  const auto start=std::chrono::steady_clock::now();
  node.server_->poll([&](const fc01::Request& request){
    ++calls;auto reply=node.runtime_->request(request.op,request.values,snapshot,1.);
    auto response=node.state(snapshot,1.,"reply",request.seq,reply.accepted,reply.message);
    if(calls==1){first_reply_bytes=response.size();std::ofstream("actual_state_first_reply.json")<<response<<'\n';}
    response_bytes+=response.size()+1;return response;
  },[&]{++dropped;});
  const auto elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
  assert(calls==350&&node.server_->connected()&&response_bytes>65536);
  assert(node.command_pub_->calls==0&&!node.mode_pub_&&!node.attitude_pub_&&!node.target_pub_);
  std::cout<<"ACTUAL_STATE_BURST {\"calls\":"<<calls<<",\"payload_bytes\":"<<payload.size()
    <<",\"first_reply_bytes\":"<<first_reply_bytes<<",\"response_bytes\":"<<response_bytes
    <<",\"first_poll_seconds\":"<<elapsed<<",\"power_publish_calls\":0,\"drop_before_second_poll\":"<<dropped<<"}\n";
  node.server_->poll([](const fc01::Request&){assert(false);return std::string{};},[&]{++dropped;});
  assert(!node.server_->connected()&&dropped==1);
  close(client);
}
'''
(build/'measure.cpp').write_text(source)
argv=['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-pedantic','-pthread','-I',str(build),'-I',str(root/'native/src/jikl_fc01_system/include'),str(build/'measure.cpp'),'-o',str(c/'actual_state_measure')]
steps=[]
start=time.monotonic();r=subprocess.run(argv,capture_output=True,text=True,timeout=120);(c/'actual_state_compile.log').write_text(r.stdout+r.stderr);steps.append({'argv':argv,'returncode':r.returncode,'seconds':time.monotonic()-start});assert r.returncode==0,r.stderr
with tempfile.TemporaryDirectory(prefix='fc01_s6enc_') as temp:
 os.chmod(temp,0o700);env=dict(os.environ,FC01_SOCKET=str(Path(temp)/'c.sock'))
 start=time.monotonic();r=subprocess.run([str(c/'actual_state_measure')],cwd=c,env=env,capture_output=True,text=True,timeout=10)
 (c/'actual_state_run.log').write_text(r.stdout+r.stderr);steps.append({'argv':[str(c/'actual_state_measure')],'returncode':r.returncode,'seconds':time.monotonic()-start,'env_overrides':{'FC01_SOCKET':env['FC01_SOCKET']},'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,r.stderr
row={'steps':steps,'scope':'Actual SystemNode constructor/state encoder and STATUS request with fake ROS API/messages and private temporary Unix socket. No tick/Runtime.step, DDS, Agent, production main, power publisher or hardware. No real-time or ARM64 conclusion.','production_source_sha256':hashlib.sha256((root/'native/src/jikl_fc01_system/src/fc01_system_node.cpp').read_bytes()).hexdigest(),'fixture_changes':'Existing controlled clock and access labels only; core and encoder logic not modified.'}
(c/'actual_state_measure.json').write_text(json.dumps(row,indent=2)+'\n');print(r.stdout)
