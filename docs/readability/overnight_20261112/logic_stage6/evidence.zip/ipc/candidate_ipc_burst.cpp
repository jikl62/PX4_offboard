// 候选复现：只用临时AF_UNIX和合成handler，不启动ROS、Runtime或真实控制器。
#include "jikl_fc01_system/unix_server.hpp"
#include <cassert>
#include <chrono>
#include <filesystem>
#include <iostream>

int main(int argc, char** argv) {
  const bool require_budget = argc == 2 && std::string(argv[1]) == "--require-budget";
  char pattern[] = "/tmp/fc01_stage6_burst_XXXXXX";
  char* directory = mkdtemp(pattern);
  assert(directory);
  const std::string path = std::string(directory) + "/control.sock";
  std::size_t handled = 0, response_bytes = 0, disconnected = 0;
  bool first_connected = false, second_connected = false;
  double seconds = 0;
  {
    fc01::UnixServer server(path);
    const int client = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    assert(client >= 0);
    sockaddr_un address{};
    address.sun_family = AF_UNIX;
    std::memcpy(address.sun_path, path.c_str(), path.size() + 1);
    assert(connect(client, reinterpret_cast<sockaddr*>(&address), sizeof(address)) == 0);
    std::string payload;
    for (unsigned i = 1; i <= 350; ++i)
      payload += std::to_string(i) + " STATUS\n";
    assert(payload.size() < 4096);
    assert(send(client, payload.data(), payload.size(), MSG_NOSIGNAL) == ssize_t(payload.size()));
    const auto handler = [&](const fc01::Request& request) {
      assert(request.op == "STATUS" && request.seq == handled + 1);
      ++handled;
      const std::string response(4096, 's');
      response_bytes += response.size() + 1;
      return response;
    };
    const auto dropped = [&] { ++disconnected; };
    const auto start = std::chrono::steady_clock::now();
    server.poll(handler, dropped);
    seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
    first_connected = server.connected();
    server.poll(handler, dropped);
    second_connected = server.connected();
    close(client);
  }
  std::filesystem::remove_all(directory);
  std::cout << "{\"handled_in_first_poll\":" << handled
            << ",\"generated_response_bytes\":" << response_bytes
            << ",\"configured_flush_limit\":65536,\"first_poll_still_connected\":"
            << first_connected << ",\"second_poll_still_connected\":" << second_connected
            << ",\"disconnected_callbacks\":" << disconnected
            << ",\"first_poll_seconds\":" << seconds << "}\n";
  if (require_budget) {
    // 64KiB判断若确为即时预算，至多有最后一个回复超过预算，随后立即断连停止处理。
    assert(handled <= 16 && response_bytes <= 65536 + 4097 && !first_connected);
  } else {
    assert(handled == 350 && response_bytes == 350 * 4097 && first_connected);
    assert(!second_connected && disconnected == 1);
  }
}
