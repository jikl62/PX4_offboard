from pathlib import Path
import hashlib,json,zipfile
CACHE=Path(__file__).resolve().parent
OUT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028/docs/readability/overnight_20261112/logic_stage6')
allowed={'.json','.jsonl','.log','.md','.py','.cpp','.hpp','.sh','.txt','.patch','.xml'}
paths=sorted(p for p in CACHE.rglob('*') if p.is_file() and p.suffix in allowed and '__pycache__' not in p.parts)
archive=OUT/'evidence.zip';rows=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in paths:
  data=p.read_bytes();name=str(p.relative_to(CACHE));assert len(data)<1024*1024,(name,len(data))
  z.writestr(name,data);rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))==len(rows)
 for row in rows:
  data=z.read(row['path']);assert len(data)==row['bytes'];assert hashlib.sha256(data).hexdigest()==row['sha256']
assert archive.stat().st_size<1024*1024
index={'archive':'evidence.zip','archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'member_count':len(rows),'crc_and_every_member_sha256_verified':True,'cache_origin':str(CACHE),'members':rows,'scope':'Raw source/commands/JSON/log evidence; no binaries, core dumps, build/install trees or pycache. Some fixture sources are copies with fakeROS/access labels, identified explicitly by measurement scripts. Candidate patches are inert archive members, not production source modifications.'}
(OUT/'evidence_index.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in index.items() if k not in ('members','scope')}))
