import json,subprocess,time
from pathlib import Path
c=Path(__file__).resolve().parent
argv=['cppcheck', '--enable=warning,performance,portability', '--inconclusive', '--std=c++17', '--language=c++', '--inline-suppr', '-j2', '--xml', '--xml-version=2', '-I', 'native/src/jikl_fc01_system/include', 'native/src/jikl_fc01_system/src', 'native/src/jikl_fc01_system/include']
start=time.monotonic()
with (c/"cppcheck.stdout.log").open("w") as out,(c/"cppcheck.xml").open("w") as err:
 r=subprocess.run(argv,stdout=out,stderr=err)
row={"argv":argv,"returncode":r.returncode,"seconds":time.monotonic()-start}
(c/"cppcheck.result.json").write_text(json.dumps(row,indent=2)+"\n")
print(json.dumps(row))
