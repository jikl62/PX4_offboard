// Stage6 safety candidate test: real Runtime/Core and production-value RC fixture.
// All PX4 states are synthetic; sinks only pass through the pure policy and commit count.
// Run against baseline and isolated include overlay. No production source mutation or ROS.
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main original_rc_main
#include "/home/jikl62/FC01_OrangePi_Navigation_20261028/native/tests/test_rc_navigation.cpp"
#undef main
#pragma GCC diagnostic pop

struct Scenario {
  Flight q{production_no_vision_rc_config()};
  double first_land_at{-1}, last_land_at{-1};
  unsigned land_messages{};
  bool wrong{}, seen_ready{};
  void tick(bool new_land) {
    q.t += .05;
    q.s.status_stamp += 50000;
    q.s.attitude.local_stamp += 50000;
    q.s.attitude.vertical_sample_stamp += 50000;
    q.s.attitude.rc_switch_sample_stamp += 50000;
    q.s.attitude.source_host_stamp = q.s.status_stamp;
    if (new_land) {
      q.s.land_stamp = q.s.status_stamp;
      if (first_land_at < 0) first_land_at = q.t;
      last_land_at = q.t;
      ++land_messages;
    }
    q.s.land_fresh = last_land_at >= 0 && q.t-last_land_at < q.c.attitude.land_timeout;
    q.s.attitude.source_clock_valid = f::source_stamp_in_clock(
        q.s.land_stamp,q.s.attitude.source_host_stamp,q.c.attitude.land_timeout);
    q.o = q.r.step(q.s,q.t);
    need(q.o.attitude.command==a::Command::None,"RC proof must not issue flight action");
    need(!a::nonzero(q.o.attitude.thrust),"only zero prestream allowed in this synthetic scenario");
    if (q.o.attitude.publish) {
      const auto d=a::attitude_publication_policy(q.r.publication_context(q.s,q.t,true,true),q.o.attitude);
      need(d.allowed,a::name(d.reason));
      q.r.confirm_rc_output(true,q.t);
    }
    seen_ready = seen_ready || q.r.attitude_core().phase()==a::Phase::RcWaitArm;
    need(!q.r.attitude_core().flight_started(),"no manual arm/navigation means no flight start");
  }
  bool qualified()const{return q.r.attitude_core().rc_ground_reference_qualified();}
  void trace(const char* name)const {
    std::cout<<"{\"trace\":\""<<name<<"\",\"now\":"<<q.t
      <<",\"land_messages\":"<<land_messages<<",\"land_span\":"<<last_land_at-first_land_at
      <<",\"land_idle\":"<<q.t-last_land_at<<",\"land_fresh\":"<<q.s.land_fresh
      <<",\"source_clock_valid\":"<<q.s.attitude.source_clock_valid
      <<",\"allowed_gap\":"<<q.c.attitude.land_sample_max_gap
      <<",\"land_timeout\":"<<q.c.attitude.land_timeout
      <<",\"phase\":\""<<q.r.phase_name()<<"\",\"qualified\":"<<qualified()
      <<",\"flight_started\":"<<q.r.attitude_core().flight_started()<<"}\n";
  }
};
int main(){
  unsigned failures=0;
  Scenario burst;
  for(unsigned i=1;i<=44;++i){burst.tick(i<=3);burst.wrong=burst.wrong||burst.qualified();}
  burst.trace("three_frames_in_100ms_then_frozen");
  failures += burst.wrong;
  Scenario healthy;
  for(unsigned i=1;i<=65;++i) healthy.tick(i==1 || i%20==1);
  healthy.trace("independent_healthy_1Hz_detector");
  need(healthy.seen_ready && healthy.qualified(),"healthy independent1Hz source must reach READY");
  Scenario frozen;
  for(unsigned i=1;i<=45;++i) frozen.tick(true);
  need(frozen.seen_ready && frozen.qualified(),"first establish actual healthy ground proof");
  for(unsigned i=1;i<=27;++i) frozen.tick(false);
  frozen.trace("previously_ready_detector_then_frozen_past_gap");
  failures += frozen.qualified();
  // A strictly new detector sample after a long gap starts a new proof, not immediate READY.
  frozen.tick(true);
  need(!frozen.qualified(),"first detector sample after gap cannot retain old proof");
  for(unsigned i=1;i<=45;++i) frozen.tick(true);
  frozen.trace("new_complete_proof_after_gap");
  need(frozen.qualified() && frozen.seen_ready,"complete new proof can return to READY");
  std::cout<<"S6_C1_GROUND_PROOF failures="<<failures<<"\n";
  return failures?1:0;
}
