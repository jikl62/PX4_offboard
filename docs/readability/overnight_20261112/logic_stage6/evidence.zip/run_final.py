import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
cache=Path(__file__).resolve().parent
argv=['python3','-m','unittest','discover','-s','tests','-v']
start=time.monotonic()
with (cache/'root_final.log').open('wb') as log:
 result=subprocess.run(argv,cwd=root,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=log,stderr=subprocess.STDOUT)
row={'argv':argv,'cwd':str(root),'returncode':result.returncode,'seconds':time.monotonic()-start,'env_overrides':{'PYTHONDONTWRITEBYTECODE':'1'}}
(cache/'root_final.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row))
sys.exit(result.returncode)
