set -eo pipefail
unset AMENT_PREFIX_PATH CMAKE_PREFIX_PATH COLCON_PREFIX_PATH PYTHONPATH LD_LIBRARY_PATH PKG_CONFIG_PATH
source /opt/ros/humble/setup.bash
source /home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs/share/px4_msgs/local_setup.bash
export PYTHONDONTWRITEBYTECODE=1
export ROS_LOCALHOST_ONLY=1
export ROS_DOMAIN_ID=222
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
unset ROS_DISCOVERY_SERVER CYCLONEDDS_URI FASTRTPS_DEFAULT_PROFILES_FILE FASTDDS_DEFAULT_PROFILES_FILE RMW_FASTRTPS_USE_QOS_FROM_XML ROS_STATIC_PEERS
/usr/bin/python3 /home/jikl62/.cache/fc01-logic-stage6-20261112-6_1ed60o/root/collect_domain_preflight.py /home/jikl62/.cache/fc01-logic-stage6-20261112-6_1ed60o/root/collect_domain_before.json
/usr/bin/python3 /home/jikl62/.cache/fc01-logic-stage6-20261112-6_1ed60o/root/collect_humble.py /home/jikl62/.cache/fc01-logic-stage6-20261112-6_1ed60o/root/collect_humble.report.json
/usr/bin/python3 /home/jikl62/.cache/fc01-logic-stage6-20261112-6_1ed60o/root/collect_domain_preflight.py /home/jikl62/.cache/fc01-logic-stage6-20261112-6_1ed60o/root/collect_domain_after.json
