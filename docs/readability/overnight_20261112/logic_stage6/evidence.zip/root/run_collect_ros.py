import json,subprocess,time
from pathlib import Path
c=Path(__file__).resolve().parent
argv=['bash',str(c/'collect_humble.command.sh')]
start=time.monotonic()
with (c/'collect_humble.log').open('w') as log:r=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
row={'argv':argv,'returncode':r.returncode,'seconds':time.monotonic()-start}
(c/'collect_humble.result.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row))
raise SystemExit(r.returncode)
