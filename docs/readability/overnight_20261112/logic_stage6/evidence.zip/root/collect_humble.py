import hashlib,json,os,sys,time
from pathlib import Path
import rclpy
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
sys.path.insert(0,str(root))
import navigation_collect as collect
assert os.environ['ROS_DOMAIN_ID']=='222' and os.environ['ROS_LOCALHOST_ONLY']=='1'
rows=[]
for cycle in range(3):
 assert not rclpy.ok()
 result=collect.sample_ros(.15)
 assert not rclpy.ok()
 assert result['status']=='ok' and len(result['topics'])==9
 assert all(item['messages']==0 for item in result['topics'].values())
 rows.append({'cycle':cycle,'result':result,'context_shutdown':not rclpy.ok()})
report={'passed':True,'domain':222,'localhost_only':True,'source_sha256':hashlib.sha256((root/'navigation_collect.py').read_bytes()).hexdigest(),'rclpy_path':rclpy.__file__,'cycles':rows,'scope':'Only passive observer subscriptions and ROS metadata. No synthetic fmu publishers, flight controller, Agent, service, motor or hardware. Three normal lifecycle cycles; exception paths use deterministic fake resources separately.'}
Path(sys.argv[1]).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':True,'cycles':3,'all_contexts_shutdown':True}))
