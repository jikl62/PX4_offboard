"""Run real start.main with fake signals/processes only; never spawn or signal OS processes."""

import contextlib, difflib, hashlib, importlib.util, io, json, os, signal, subprocess, sys, tempfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path("/home/jikl62/FC01_OrangePi_Navigation_20261028")
FOLDER = Path(__file__).resolve().parent
CANDIDATES = FOLDER.parent / "candidates"
original = subprocess.check_output(
    [
        "git",
        "-C",
        str(ROOT),
        "show",
        "1e824f883fe6255f8d265b1cece339a83594b059:native/tools/start.py",
    ],
    text=True,
)
before = """                os.killpg(node.pid, signal.SIGTERM)
                waiting_since = time.monotonic()
"""
after = """                try:
                    os.killpg(node.pid, signal.SIGTERM)
                except ProcessLookupError:
                    # 候选：poll 后自然退出可让进程组消失；只在再次确认 Node 已退出时继续原清理。
                    # 若 Node 仍活动，保留原错误和 Agent，不能把 ESRCH 当成已安全退出的证据。
                    if node.poll() is None:
                        raise
                waiting_since = time.monotonic()
"""
assert original.count(before) == 1
candidate = original.replace(before, after)
(CANDIDATES / "start_exit_race.original.py").write_text(original)
(CANDIDATES / "start_exit_race.candidate.py").write_text(candidate)
(CANDIDATES / "start_exit_race.patch").write_text(
    "".join(
        difflib.unified_diff(
            original.splitlines(True),
            candidate.splitlines(True),
            fromfile="a/native/tools/start.py",
            tofile="b/native/tools/start.py",
        )
    )
)


def run(source, *, actually_exited=True, external_agent=False):
    spec = importlib.util.spec_from_file_location("stage6_supervisor_candidate", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    events = []
    handlers = {}
    failure = ProcessLookupError("synthetic poll-to-killpg natural exit")
    alive = {"node": True, "agent": True}

    class Process:
        def __init__(self, kind, pid):
            self.kind, self.pid, self.returncode = kind, pid, None

        def poll(self):
            events.append(self.kind + ".poll")
            if not alive[self.kind]:
                self.returncode = 0
            return self.returncode

        def wait(self, timeout=None):
            events.append(self.kind + ".wait")
            assert not alive[self.kind]
            self.returncode = 0
            return 0

    def spawn(argv, **kwargs):
        kind = "agent" if Path(argv[1]).name == "agent.sh" else "node"
        events.append(kind + ".spawn")
        return Process(kind, 1001 if kind == "agent" else 1002)

    def sleep(seconds):
        if seconds == 0.1:
            handlers[signal.SIGTERM](signal.SIGTERM, None)

    def killpg(pid, signum):
        kind = "agent" if pid == 1001 else "node"
        events.append(kind + ".signal")
        if kind == "node":
            alive["node"] = not actually_exited
            raise failure
        assert not alive["node"], "Agent killed before node confirmed exited"
        alive["agent"] = False

    argv = ["start.py"] + (["--external-agent"] if external_agent else [])
    with tempfile.TemporaryDirectory() as folder, contextlib.redirect_stdout(
        io.StringIO()
    ), contextlib.redirect_stderr(io.StringIO()), patch.dict(
        os.environ, {"FC01_HOME": folder}
    ), patch.object(
        sys, "argv", argv
    ), patch.object(
        module.signal, "signal", side_effect=lambda s, h: handlers.__setitem__(s, h)
    ), patch.object(
        module.subprocess, "Popen", side_effect=spawn
    ), patch.object(
        module.time, "sleep", side_effect=sleep
    ), patch.object(
        module.os, "killpg", side_effect=killpg
    ):
        try:
            result = module.main()
            outcome = {"return": result}
        except BaseException as error:
            outcome = {
                "error": type(error).__name__,
                "original_error_identity": error is failure,
                "message": str(error),
            }
    return {"events": events, "alive_after": alive, "outcome": outcome}


sources = {
    "original": CANDIDATES / "start_exit_race.original.py",
    "candidate": CANDIDATES / "start_exit_race.candidate.py",
}
report = {
    "scope": "Pure fake process/signal resources; start.main production entry not launched with real dependencies. Candidate only; no repository production edit.",
    "baseline": "1e824f883fe6255f8d265b1cece339a83594b059",
    "source_sha256": {
        name: hashlib.sha256(path.read_bytes()).hexdigest()
        for name, path in sources.items()
    },
    "scenarios": {},
}
for name, path in sources.items():
    report["scenarios"][name] = {
        "node_exited_between_poll_and_signal": run(path),
        "esrch_but_node_still_unconfirmed": run(path, actually_exited=False),
        "external_agent_not_owned": run(path, external_agent=True),
    }
old = report["scenarios"]["original"]["node_exited_between_poll_and_signal"]
new = report["scenarios"]["candidate"]["node_exited_between_poll_and_signal"]
assert old["outcome"]["error"] == "ProcessLookupError" and old["alive_after"]["agent"]
assert new["outcome"] == {"return": 0} and not new["alive_after"]["agent"]
for name in sources:
    row = report["scenarios"][name]["esrch_but_node_still_unconfirmed"]
    assert row["outcome"]["original_error_identity"] and row["alive_after"]["agent"]
assert (
    "agent.spawn"
    not in report["scenarios"]["candidate"]["external_agent_not_owned"]["events"]
)
report["confirmed_issue"] = (
    "Node natural exit between poll and killpg skips owned Agent cleanup; original error remains visible. No evidence of flight output change or persistent UART ownership in live hardware."
)
report["severity"] = (
    "P2 lifecycle candidate; supervisor/Agent behavior requires human review before production adoption."
)
report["limits"] = (
    "Candidate only addresses ProcessLookupError after node signal and rechecks poll. Other OS/cleanup errors remain outside this narrow patch. It does not prove live flight shutdown safety or send any real signal."
)
(FOLDER / "supervisor_exit_race.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
