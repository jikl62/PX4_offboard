"""No real worker/process: fail Thread.start before launch, then call real cleanup."""

import hashlib, json, sys, tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path("/home/jikl62/FC01_OrangePi_Navigation_20261028")
sys.path.insert(0, str(ROOT))
import standby

folder = Path(__file__).resolve().parent
primary = RuntimeError("synthetic cannot start new thread")
events = []
with tempfile.TemporaryDirectory() as directory:
    transport = standby.AgentTransport(
        Path("/not/a/real/Agent"), None, None, Path(directory), lambda *args: None
    )
    try:
        try:
            with patch.object(standby.threading.Thread, "start", side_effect=primary):
                transport.start()
        finally:
            standby._close_supervised_attempt(
                None,
                None,
                transport,
                None,
                {},
                None,
                None,
                None,
                {},
                float("-inf"),
                SimpleNamespace(close=lambda: events.append("lock.close")),
                lambda row: None,
                SimpleNamespace(message=lambda *args: None),
            )
    except BaseException as error:
        outcome = {
            "error": type(error).__name__,
            "message": str(error),
            "is_original_error": error is primary,
            "original_context_visible": error.__context__ is primary,
        }
    else:
        raise AssertionError("original should fail to join unstarted worker")
assert outcome["message"] == "cannot join thread before it is started"
assert events == []
assert transport.closing.is_set()
row = {
    "baseline": "1e824f883fe6255f8d265b1cece339a83594b059",
    "scope": "Actual threading.Thread object with start replaced by immediate RuntimeError before thread launch; no threads/processes/Agent/ROS/OS signals run.",
    "source_sha256": hashlib.sha256((ROOT / "standby.py").read_bytes()).hexdigest(),
    "outcome": outcome,
    "events": events,
    "closing_requested": transport.closing.is_set(),
    "confirmed": "After worker creation failed before Thread.start, AgentTransport.close calls join on unstarted Thread; secondary RuntimeError prevents remaining attempt cleanup and escapes supervisor retry. Original cause remains implicit context, not lost entirely.",
    "severity": "P2 lifecycle candidate requiring human audit; no proof of persistent lock leak after Python frame teardown or unsafe motor output.",
    "production_fix": "None. Worker publication/start/close ownership contract needs review before changing supervisor/Agent lifecycle.",
}
(folder / "standby_unstarted_transport.json").write_text(
    json.dumps(row, indent=2) + "\n"
)
print(json.dumps(row, indent=2))
