# Stage 6：被动工具与进程生命周期审查

本子任务以 `1e824f883fe6255f8d265b1cece339a83594b059` 为不可变基线，独立检查 8 份相关源码的资源取得、异常传播、销毁顺序、Context 所有权、信号处理和进程退出边界。范围、源码 SHA 与保留理由见 `review.json`。没有启动真实 ROS、Agent、控制器、systemd 或任何串口/动力程序。

## 已应用的普通工具修复：P2

`navigation_collect.sample_ros` 的 ROS init 原本在 try 外；部分激活后失败不会尝试 shutdown。原 finally 中 `destroy_node` 抛错会直接跳过 shutdown，并以次生错误遮住 spin 原错。

基线由 Git 导出成 `navigation_collect.original.py`；同一新增测试文件在原源码上运行：15 个方法，7 FAIL、1 ERROR（停止异常方法另含 KeyboardInterrupt/SystemExit 两个失败子例），原日志完整保存。修复将 init 纳入保护区，记录本轮进入前的默认 Context 状态，Node 和自有 Context 清理分别尝试，原业务异常对象及其 cause 优先；后续错误接入可见异常链而非被吞掉。原先已活动的 Context 不被本次失败关闭。

新增 15 方法覆盖：Node 构造失败、destroy/shutdown 单错与组合、部分 init、已活动 Context、Context 查询失败、图读取失败、订阅失败原部分报告、停止异常及 12 轮重复启动退出。最终原 9 + 新 15 = **24/24**，无跳过。3 组正常/订阅全拒绝/空话题的规范 JSON 文本、资源事件与最终状态与基线精确相同；新错误行为单独测试，不做归一化。采样原 try 主体去掉新增两条所有权/init 语句后完整 AST 相同。

最终文件 SHA、Black、语法及 diff 结果见 `freeze.json`，最后测试见 `collect_final.json/log`。删除新测试中一个未使用导入后已重跑最终 24 方法。源码修改只涉及被动采集器和新测试，不改变控制器或服务管理。

## 未应用的监督器候选：均需人工审核

1. **P2 / native start 的 poll→killpg 自然退出竞态。** `start.py` 在 poll 发现 Node 活动后，Node 可在信号发送前自然退出；killpg 抛 ProcessLookupError 会中止 finally，跳过自建 Agent 后项回收。实际 main 使用假 Popen、假信号、假 sleep 重放，未创建或杀死 OS 进程。`../candidates/start_exit_race.patch` 只在 ESRCH 后再次 poll 确认 Node 已结束时继续原清理；若仍未确认结束则保留 Agent 并抛原错。原/候选均验证自然退出、仍活动、外部 Agent 不归本入口三场景。该工具链入口不同于正式导航服务监督器；没有将这个竞态说成已在当前实机发生。
2. **P2 / standby 未启动 transport 线程的 join。** 用真实 Thread 对象但在 `Thread.start` 启动前注入 RuntimeError。真实 `AgentTransport.close` 随后 join 未启动线程，抛 `cannot join thread before it is started`，跳过剩余清理和重试。原启动错误仍在隐式 context 中，不是完全丢失。保存 `standby_unstarted_transport.py/json/log`；未启动任何线程、Agent 或控制器。此处 start/close 对象发布与活 Agent 交接需要一起审查，没有盲目加“所有资源都继续释放”的生产修复。

不能从上述假资源回放推断实机永久持锁、UART 泄漏或动力错误：Python 帧析构等可能另行关闭文件，恢复安全仍取决于真实原生进程状态。两项都保持生产原字节。

## 既有保护与有限范围

navigation_probe 的地面证据仍检查源推进、接收年龄、单一来源及本轮 armed 锁存；视觉工具已采用先构造 Node 再 configure、信号仅请求停止、主线程回收资源及处理器恢复。feedback_age_probe 的多步异常清理保留。此次独立检查这些路径，未发现需要再改的确认缺陷，也没有把既有测试当作任意时序安全证明。

launcher/standby 中部分 release 自身失败仍会跳过后面的普通语句；不是所有后项都能无条件安全执行。涉及活原生和 Agent 依赖的退出必须保持先后约束，故没有为“完成清理”而停止仍需要 DDS 的 Agent。

另独立检查 root 的 DeploymentLog 修复：8/8 实际测试通过，`offline/online/main/record/step` 完整 AST 与基线一致，构造 BEGIN 失败和 finish 写盘失败只增加本次日志关闭尝试；保留首错，未改任何部署或服务命令。详见 `deployment_logs_cross_review.json/log`。

## 最终候选边界补充

standby 未启动线程问题仍保持“已确认、尚无候选补丁”。不能仅凭 `worker.ident is None` 或 `not is_alive()` 就断言线程今后不会运行：已安装 CPython 3.10 的 `Thread.start` 先调用 `_start_new_thread`，随后才等 `_started`；若后段受异步异常打断，OS 启动获准与 Python 身份发布之间存在窗口。当前串行调用和事件式信号减小可达性，但原 pre-launch 失败测试不能证明泛化跳过 join 的补丁安全。`standby_candidate_disposition.json` 保留原测试覆盖范围、源码行/SHA、拒绝简单补丁的理由和下一步所有权握手要求；本次没有额外启动线程去假装验证这一窗口。

另只读复核 C1 地面候选及 root 的四条回放，未发现新增实现阻塞，但须保留人工审核限制。它不仅影响显示文字，还会改变地面资格、READY 时点及允许更新高度锚点的条件，因此属于安全准入行为修改。接收端单调时间跨度不等于传感器物理测量覆盖或时钟同步证明；原 source/freshness/reset 等检查仍不可删除。目标 PX4 接地检测频率/抖动、DDS 延迟和多轮恢复仍需无动力硬件验证。详见 `ground_candidate_cross_review.json`，没有重跑其 C++ 或更改生产。
