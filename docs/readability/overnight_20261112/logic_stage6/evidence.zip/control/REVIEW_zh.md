# Stage 6 独立控制与接线审查

基线 `1e824f883fe6255f8d265b1cece339a83594b059`。审查使用真实源码、合成快照、假 sink 与本机自有临时 Unix socket；没有运行生产 ROS Node/Agent/服务、部署或操作硬件。没有修改仓库生产控制源码或新增仓库控制测试，候选及驱动均在 cache。

## 确认的 P2 安全准入候选：短检测 burst 可凑满 RC 地面证明

真实 Runtime/Core、现有 `production_no_vision_rc_config` 的1.5m/推力/时间参数下，只在0.05/0.10/0.15s送三条不同land源戳，其他必要源继续健康推进。三条land仅跨0.10s，冻结1.90s后在2.05s进入 `RC_READY_WAIT_ARM`，`rc_ground_reference_qualified=true`。这时接收/源年龄仍小于2.5s，超过独立配置 `land_sample_max_gap=1.25s`。

根因是 `RcNavigationStart::observe_ground_reference` 使用 `now-ground_since`、三条land累计数量计算合格；只在下一条新land到来时检查gap，没有要求land的新观察本身覆盖2s，也没有在缓存冻结时撤销已合格证据。它与故障后 `observe_rc_recovery` 已有的“最后land观察必须跨足停留”门不一致。

现有门依旧有效：没有自动ARM/切Offboard，没有非零推力或flight_started。问题是地面证明的时间证据比设计和注释宽，尚未证明真实机器曾出现这一种具体输入序列。分级P2，涉及起飞准入安全行为，因此**候选不纳入生产，需人工审核**。

隔离 `S6_C1_ground_burst.patch` 镜像恢复路径的两项门：最后新land观察与窗口起点跨足ground_seconds；当前时刻距最后land观察不超过min(land_sample_max_gap,land_timeout/2)。没有改推力、目标、解锁策略或任意其他控制文件。

同一四轨迹驱动原版失败2处（短burst合格、旧READY冻结后保留证明）；候选通过：短burst拒绝、健康独立1Hz land仍READY、先前READY冻结超gap撤销、完整新窗重新READY。候选overlay下原RC导航完整回归、恢复进展、准备延期均通过。ASan/UBSan只对候选四轨迹驱动运行并通过，不冒称全工程sanitizer证明。clang14 analyzer检查该驱动及所达Runtime/Core路径，0诊断；静态工具不证明所有状态安全。

证据：`ground_candidate_runs.json`、`targeted_checks.json`、`static_analyzer.json`，完整原/候选日志和驱动保留。root另独立重跑相同四轨迹并审patch。

## 历史故障的实际代码判定

- `CONTROL_LOOP_STALL`：Core使用原始相邻step elapsed，不先clamp；Node在回调之前开始cycle预算，IPC/Runtime后检查预算，最终各sink还重取上下文。长回调/IPC/日志抖动触发拒绝是存在的安全保护，不应删除。单线程合作调度不能抢占一个慢回调；实际负载原因需板上时序记录。
- `VERTICAL_VELOCITY_INCONSISTENT`：目前仅保留在历史可恢复白名单，guard的`abs(vz-z_deriv)`只更新诊断warning。输入非法、采样回退、缺口、位置变化与z_deriv积分不一致仍有独立硬故障。代码不将两个EKF输出误当独立高度真值。本轮原guard严格编译/回归通过。
- `PARTIAL_OR_FAILED_SETPOINT_PUBLICATION`：目标/心跳非原子；target sink已返回而第三次context拒绝，必须视为部分发布。522组观察/异常组合、既有offline timing回归通过，证据committed只表示本地sink返回，不是PX4采用。
- `HEARTBEAT_FINAL_CONTEXT_CHANGED`：三次context会独立核验cycle与源年龄等门；第三次在目标之后不允许静默返回“完全未发布”。既有测试验证TTL/loop deadline跨界的硬拒绝与未解锁窄延期，未发现可归类为“删掉保护即可解决”的代码证据。
- 地面高度：RC未解锁时允许新独立窗口跟踪缓慢一致参考；arm意图/已armed后冻结z0，reset、跳变和有限高度包络检查保留。本轮发现的是land时间证据漏洞，不是允许空中自动重设z0。

## IPC候选二次审查

原IPC代理的350请求/1.43MB合成回复、真实状态编码4.11MB假ROS测量已经保存。这里仅静态检查其源码、日志、patch和生产tick连接；没有重复突发。该代理在平台风险检测下中止，原记录不是本审查者新完成的执行。

确认production poll会同步请求/编码，64KiB输出门下一poll才查，因此存在单批响应放大和工作量积压的P2可靠性候选；0.0119s x86测量不能外推ARM64或真实flight stall。最终cycle门依旧拒绝过期输出，未证明动力越权。

独立审查发现初候选把即时背压drop放进业务catch中，disconnect自身抛错会重复通知。经root授权仅修隔离候选，保留旧版快照；精确两条STATUS测试旧候选disconnect2返回1，修候选disconnect1且原错误传播返回0，git apply --check通过。未重新执行突发。候选仍需人工审核早断连对Runtime下降/准备取消及LAND/STOP排序影响。

完整证据：`ipc_cross_review.json`、`ipc_candidate_drop_review_runs.json`。仓库UnixServer保持原SHA。

## 审查范围与限度

`source_integrity.json`登记13份实际读过的控制/接线/时钟/IPC源及SHA，本轮均与基线原字节相同。Core/Runtime/Node全状态空间、所有浮点极值、硬件任意资源错误不是有限测试可证明的事实。已有单线程接线不发生ROS回调与tick并发，但日志有独立后台线程；没有把这解释为整个程序无竞争。没有新增关键P0/P1的充分证据，也不能据此宣布不存在。
