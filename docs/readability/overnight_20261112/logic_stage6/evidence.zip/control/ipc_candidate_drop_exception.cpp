// Precision review fixture: two STATUS lines only, own temporary AF_UNIX socket.
// One synthetic response crosses existing backpressure budget; disconnect throws.
#include "jikl_fc01_system/unix_server.hpp"
#include <cassert>
#include <filesystem>
#include <iostream>
#include <stdexcept>
int main(){
 char pattern[]="/tmp/fc01_s6_drop_XXXXXX";const auto folder=mkdtemp(pattern);assert(folder);
 unsigned handled=0,disconnected=0;bool propagated=false;bool connected_after=true;
 {
  const std::string path=std::string(folder)+"/control.sock";fc01::UnixServer server(path);
  const int client=socket(AF_UNIX,SOCK_STREAM|SOCK_CLOEXEC,0);assert(client>=0);
  sockaddr_un address{};address.sun_family=AF_UNIX;std::memcpy(address.sun_path,path.c_str(),path.size()+1);
  assert(connect(client,reinterpret_cast<sockaddr*>(&address),sizeof(address))==0);
  const std::string payload="1 STATUS\n2 STATUS\n";
  assert(send(client,payload.data(),payload.size(),MSG_NOSIGNAL)==ssize_t(payload.size()));
  try {
   server.poll([&](const fc01::Request& r){++handled;assert(r.op=="STATUS");return std::string(65537,'x');},
               [&]{++disconnected;assert(!server.connected());throw std::runtime_error("disconnect synthetic error");});
  } catch(const std::runtime_error& e){propagated=std::string(e.what())=="disconnect synthetic error";}
  connected_after=server.connected();close(client);
 }
 std::filesystem::remove_all(folder);
 std::cout<<"{\"handled\":"<<handled<<",\"disconnect_calls\":"<<disconnected<<",\"propagated_original\":"<<propagated<<",\"connected\":"<<connected_after<<"}\n";
 return handled==1&&disconnected==1&&propagated&&!connected_after?0:1;
}
