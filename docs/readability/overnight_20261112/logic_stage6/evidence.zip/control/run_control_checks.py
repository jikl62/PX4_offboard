from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028');cache=Path('/home/jikl62/.cache/fc01-logic-stage6-20261112-6_1ed60o');out=cache/'control';include=root/'native/src/jikl_fc01_system/include';overlay=cache/'candidates/S6_C1_overlay';rows=[]
items=[('test_rc_navigation.cpp',True),('test_rc_recovery_progress.cpp',True),('test_rc_preparation_defer.cpp',True),('test_rc_timing_recovery.cpp',False),('test_vertical_feedback_guard.cpp',False),('test_stage3_publication_combinations.cpp',False),('test_offline_timing.cpp',False)]
for name,candidate in items:
 src=root/'native/tests'/name;stem=Path(name).stem+('_candidate' if candidate else '_original');binary=out/stem
 flags=['-std=c++17','-Wall','-Wextra','-Werror','-pedantic','-pthread'];argv=['g++',*flags,*(['-I',str(overlay)] if candidate else []),'-I',str(include),str(src),'-o',str(binary)]
 row={'source':str(src.relative_to(root)),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'variant':'isolated candidate overlay' if candidate else 'unchanged production','steps':[]}
 for kind,args in [('compile',argv),('run',[str(binary)])]:
  start=time.monotonic();r=subprocess.run(args,capture_output=True,timeout=60);log=out/(stem+'.'+kind+'.log');log.write_bytes(r.stdout+r.stderr);row['steps'].append({'argv':args,'returncode':r.returncode,'seconds':time.monotonic()-start,'log':str(log)})
  if r.returncode:break
 row['passed']=all(x['returncode']==0 for x in row['steps']);rows.append(row);print(stem,row['passed'],flush=True)
# Only one candidate driver is sanitized; this does not claim sanitizer coverage of all programs.
src=cache/'candidates/S6_C1_ground_burst.cpp';binary=out/'ground_contract_candidate_asan_ubsan';argv=['g++','-std=c++17','-Wall','-Wextra','-Werror','-pedantic','-pthread','-fsanitize=address,undefined','-fno-omit-frame-pointer','-g','-I',str(overlay),'-I',str(include),str(src),'-o',str(binary)]
row={'source':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'variant':'isolated candidate ASan/UBSan','steps':[]}
for kind,args in [('compile',argv),('run',[str(binary)])]:
 start=time.monotonic();r=subprocess.run(args,capture_output=True,timeout=60,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'));log=out/('ground_contract_candidate_sanitizer.'+kind+'.log');log.write_bytes(r.stdout+r.stderr);row['steps'].append({'argv':args,'returncode':r.returncode,'seconds':time.monotonic()-start,'log':str(log)})
 if r.returncode:break
row['passed']=all(x['returncode']==0 for x in row['steps']);rows.append(row);print('candidate_sanitizer',row['passed'],flush=True)
(out/'targeted_checks.json').write_text(json.dumps({'programs':rows,'all_passed':all(x['passed'] for x in rows)},indent=2)+'\n')
