#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main original_rc_main
#include "/home/jikl62/FC01_OrangePi_Navigation_20261028/native/tests/test_rc_navigation.cpp"
#undef main
#pragma GCC diagnostic pop
int main() {
  auto c = production_no_vision_rc_config();
  Flight q(c);
  const auto base = q.s.land_stamp;
  unsigned messages = 0;
  double first_at = -1, last_at = -1;
  for (unsigned i = 1; i <= 44; ++i) {
    q.t += .05;
    q.s.status_stamp += 50000;
    q.s.attitude.local_stamp += 50000;
    q.s.attitude.vertical_sample_stamp += 50000;
    q.s.attitude.rc_switch_sample_stamp += 50000;
    q.s.attitude.source_host_stamp = q.s.status_stamp;
    if (i <= 3) {
      q.s.land_stamp = base + i * 50000;
      if (first_at < 0) first_at = q.t;
      last_at = q.t;
      ++messages;
    }
    q.o = q.r.step(q.s,q.t);
    if (q.o.attitude.publish) {
      const auto d = a::attitude_publication_policy(q.r.publication_context(q.s,q.t,true,true), q.o.attitude);
      need(d.allowed, a::name(d.reason));
      q.r.confirm_rc_output(true,q.t);
    }
    if (q.r.attitude_core().rc_ground_reference_qualified()) {
      std::cout << "{\"now\":" << q.t << ",\"land_messages\":" << messages << ",\"land_span\":" << last_at-first_at << ",\"land_idle\":" << q.t-last_at << ",\"allowed_gap\":" << c.attitude.land_sample_max_gap << ",\"land_timeout\":" << c.attitude.land_timeout << ",\"phase\":\"" << q.r.phase_name() << "\",\"ground_qualified\":true,\"flight_started\":" << q.r.attitude_core().flight_started() << "}\n";
      return 1;
    }
  }
  std::cout << "GROUND_BURST_REFUSED_PASS\n";
  return 0;
}
