import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
cache=Path(__file__).resolve().parent
name=sys.argv[1]
commands={'root':['python3','-m','unittest','discover','-s','tests','-v'], 'native':['python3','-m','unittest','discover','-s','native/tests','-v']}
argv=commands[name]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
start=time.monotonic()
with (cache/(name+'_final.log')).open('w') as log:
 result=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
row={'argv':argv,'cwd':str(root),'env_overrides':{'PYTHONDONTWRITEBYTECODE':'1'},'returncode':result.returncode,'seconds':time.monotonic()-start,'log':str(cache/(name+'_final.log'))}
(cache/(name+'_final.json')).write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row))
sys.exit(result.returncode)
