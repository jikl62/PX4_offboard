import hashlib,json,re,subprocess,zipfile
from pathlib import Path
ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
CACHE=Path(__file__).resolve().parent
OUT=ROOT/'docs/readability/overnight_20261112/vision_stage5'
BASE='68b3221ac297699e1dfed8fd773358bb26789207'
def read(p):return json.loads((CACHE/p).read_text())
def write(name,value): (OUT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args],text=True).strip()
source=read('source_commit.json')['head']
assert git('rev-parse','HEAD')==source
cpp=read('cpp/file_review.json')['files']
python=read('python/review.json')['reviewed']
engineering=read('engineering/static_review.json')
reasons={}
for entry in cpp:reasons[entry['path']]=entry.get('reason',entry.get('status','C++/MSG boundary review'))
for entry in python:reasons[entry['file']]=entry['role']+'; '+entry['edits']
for entry in engineering['modified_files']:reasons[entry['path']]='补充准确中文构建/安装/环境边界；执行内容不变。'
reasons.update({
'vision_settings.py':'独立修复数值溢出错误合同和启用候选同话题；注释明确原地非事务语义。',
'vision_config.py':'明确输出覆盖而非独占/原子写入；执行AST保持本轮起点。',
'native/tests/test_overnight_stage5_vision_contract.cpp':'新增4组39断言；映射有效位、坏时间、撤销与严格时间边界。',
 'tests/ros_generated_interface_check.py':'新增显式离线类型检查：新安装身份、字段/常量/默认值、5类型CDR；不初始化ROS。',
 'tests/test_overnight_stage5_config.py':'新增6测试方法：32数值子例、拒绝先于输出、关闭兼容和9组配置差分。',
 'tests/test_overnight_stage5_ros_contract.py':'新增2静态工程合同方法；生成/类型支持链接及相邻Python安装依赖。',
})
files=[]
for name in git('diff','--name-only',BASE,source).splitlines():
 data=(ROOT/name).read_bytes();old=subprocess.run(['git','-C',str(ROOT),'show',BASE+':'+name],capture_output=True)
 files.append({'path':name,'reason':reasons[name],'sha256':sha(data),'baseline_sha256':sha(old.stdout) if old.returncode==0 else None,'bytes':len(data),'lines':len(data.splitlines()),'delivery':'source '+source})
write('changed_files.json',{'baseline':BASE,'source_commit':source,'file_count':len(files),'files':files})
ledger={'baseline':BASE,'cpp_and_messages':cpp,'python':python,'engineering_modified':engineering['modified_files'],'environment_entries':engineering['reviewed_environment_entries'],'yaml':engineering['yaml'],'shell':engineering['shell_syntax_and_protection'],'root_configuration_and_new_tools':[r for r in files if r['path'] not in {e['path'] for e in cpp} and r['path'] not in {e['file'] for e in python} and r['path'] not in {e['path'] for e in engineering['modified_files']}], 'scope':'Specific visual/configuration engineering review. Full regression is not a claim of renewed line-by-line audit of all historical tests or real flight proof.'}
write('review_ledger.json',ledger)
initial=read('initial.json');before=[r for r in initial['refs'] if ' refs/heads/' in r or ' refs/remotes/' in r]
after=git('show-ref').splitlines();refmap={r.split(' ',1)[1]:r.split(' ',1)[0] for r in after}
current_ref='refs/heads/readability/fc01-chinese-20261111'
other_refs=[{'ref':r.split(' ',1)[1],'before':r.split(' ',1)[0],'after':refmap.get(r.split(' ',1)[1]),'unchanged':refmap.get(r.split(' ',1)[1])==r.split(' ',1)[0]} for r in before if r.split(' ',1)[1]!=current_ref]
assert all(r['unchanged'] for r in other_refs)
assert git('rev-list','--merges',BASE+'..'+source)==''
checks={
'root_python':read('root_final.json'),
'visual_python':read('python/unit.json'),
'cpp':{'verification':'evidence.zip:cpp/verification.json','targeted_programs':5,'new_scenarios':4,'new_assertions':39,'asan_ubsan_new_contract_passed':True,'raw_tokens_identical':9684,'message_declarations_identical':99},
'fresh_humble_build':read('ros/build.result.json'),
'generated_types':read('ros/generated_interfaces_retry2.result.json'),
'vision_communication':{'run':read('ros/vision.result.json'),'report':read('ros/vision.report.json')},
'velocity_communication':{'run':read('ros/velocity.result.json'),'report':read('ros/velocity.report.json')},
'static':read('root_static.json'),
'integrity':read('root_integrity.json'),
'cd_r_checker_first_failures':'Preserved generated_interfaces and generated_interfaces_retry results; SLOT_TYPES and padding assertion errors in the new tool only. See engineering/generated_checker_final_verification.json.',
'not_rerun':['native Python 41 methods unchanged since Stage 4','TSan','ARM64 build/performance','real camera/SLAM performance','production flight controller/Agent/service/motor paths']}
verification={'baseline':BASE,'source_commit':source,'branch':git('branch','--show-current'),'functional_commits':['1124daf076596a2c49a857cbaaa3c883b6bd0d0f','44632a18f5ef403ca09c5a84844f1fc52925595e'],'readability_and_test_commit':source,'checks':checks,'other_local_and_tracking_refs':other_refs,'merges_added':False,'remote_queried_or_pushed':False,'deployment_or_hardware_operations':False,'visual_navigation_enabled':False,'velocity_command_production_connection':False,'root_regression_known_errors':'3 existing extractor payload bound errors retained; no new deployable installer produced. Stage4 independently reproduced on its immutable baseline.','candidate':'P2 API quality history gap reproduced; concrete default Humble single-threaded/ordinary DDS scheduling mitigation verified by source and installed library control flow. Production bypass not established; no safety behavior patch. See cpp/candidate_quality.json and cpp/candidate_integration_review.json.','evidence_archive_policy':'Small raw text/JSON/source/commands only; no binaries, build or installation cache. Relative archive member paths index original cache artifacts; absolute paths in logs are provenance, not shipped build trees.','post_test_changes':'Documentation only after source regression. New isolated CDR checker corrected during root unittest; it is not auto-discovered by unittest. Smoke tools and drivers unchanged.'}
write('verification.json',verification)
print(json.dumps({'source_commit':source,'changed_files':len(files),'other_refs_unchanged':len(other_refs),'reports':str(OUT)},ensure_ascii=False))
