import hashlib,json,zipfile
from pathlib import Path
cache=Path(__file__).resolve().parent
out=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028/docs/readability/overnight_20261112/vision_stage5')
allowed={'.json','.jsonl','.log','.md','.py','.cpp','.sh','.txt'}
paths=[p for p in cache.iterdir() if p.is_file() and p.suffix in allowed]
for directory in ('cpp','python','engineering','ros'):
 paths.extend(p for p in (cache/directory).iterdir() if p.is_file() and p.suffix in allowed)
paths=sorted(paths)
rows=[]
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zipped:
 for p in paths:
  data=p.read_bytes();name=str(p.relative_to(cache));assert len(data)<1024*1024,(name,len(data))
  zipped.writestr(name,data)
  rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as zipped:
 assert zipped.testzip() is None
 assert len(zipped.namelist())==len(set(zipped.namelist()))==len(rows)
 for row in rows:assert hashlib.sha256(zipped.read(row['path'])).hexdigest()==row['sha256']
assert archive.stat().st_size<1024*1024
index={'cache_origin':str(cache),'archive':'evidence.zip','archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'crc_and_all_entry_hashes_verified':True,'member_count':len(rows),'members':rows,'scope':'Curated raw text/JSON/source evidence. Binary/build/install trees omitted; commands and installed identities remain in reports. Absolute original paths in logs are provenance.'}
(out/'evidence_index.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in index.items() if k not in ('members','scope')}))
