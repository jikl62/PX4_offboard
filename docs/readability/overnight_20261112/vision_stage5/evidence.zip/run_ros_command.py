import hashlib,json,subprocess,sys,time
from pathlib import Path
folder=Path(__file__).resolve().parent/'ros'
name=sys.argv[1]
start=time.monotonic()
with (folder/(name+'.log')).open('w') as log:
 result=subprocess.run(['bash',str(folder/(name+'.command.sh'))],stdout=log,stderr=subprocess.STDOUT)
row={'argv':['bash',str(folder/(name+'.command.sh'))],'exit':result.returncode,'seconds':time.monotonic()-start,'log':str(folder/(name+'.log'))}
(folder/(name+'.result.json')).write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row))
sys.exit(result.returncode)
