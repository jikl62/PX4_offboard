# 队列 5/7：C++ 视觉合同与消息审查

基线为 `68b3221ac297699e1dfed8fd773358bb26789207`，本分工不提交、不改核心/权限/配置，不运行真实 ROS 控制节点或 Agent。

先完整阅读已有 `interfaces_stage3/README_zh.md`、`INTERFACES_READING_zh.md`，再审查三份视觉头、五份 MSG、四份既有视觉测试及集成夹具。此前接口、资源预算、协议字段已有充分说明，没有再做函数拆分或普通格式重写。本次只在八份生产合同里补有用算例和边界说明，并新增一份纯主机测试。

## 中文说明的实质

- `vision_ros_adapter.hpp`：说明 ENU[东1,北2,上3]→NED[2,1,-3]、FLU[1,2,3]→FRD[1,-2,-3]只是轴约定，不能免除外参、杆臂、世界对齐和 Odometry 父/子语义检查。该 C++ 层本身只做字段映射。
- `vision_navigation.hpp`：quality 评分与协方差/概率不同；6×6行主序下标与0.04m²→0.2m标准差算例；位置0.5−0.2m乘0.8/s→0.24m/s目标速度；收窄 Inbox 撤销代数的能力声明。
- `velocity_command_input.hpp`：完整三维旋转是同一向量换基，后续限幅才会改变目标大小。原状态/目标分离、reset独立、离线预览无控制权均保留。
- 五份 MSG：分别补实际位置/速度、绝对位置目标、朝东机头的FRD速度目标、纳秒精确配对、NED垂向与上正高度的数值例。消息类型、字段、默认、枚举、顺序和Topic均不改。

## 针对性验证

`run_targeted.py` 保留每次严格编译/运行的精确 argv、输出与日志路径，结果在 `targeted.json`。

1. 既有 `test_vision_navigation`、`test_velocity_command_input`、`test_stage3_vision_resource_budget`、`test_visual_runtime` 全部编译和运行退出0；速度测试报告498断言。
2. 新增 `test_overnight_stage5_vision_contract.cpp` 有4组函数、39个断言：明确字段映射保持输入/NaN；新鲜版本/掩码/枚举失效经Inbox撤销且不被健康尾帧覆盖；精确区分TTL严格边界、arrival/future包含边界。不把缓存true当有效批准。
3. 新测试使用 ASan/UBSan 编译、运行退出0。这仅是新增主机程序检查，不是完整sanitizer、ARM64或真实ROS通信。
4. 既有 `adapter_compile_check.py` 退出0；它是窄类型/API语法夹具，不是真实Humble构建或DDS执行。
5. `check_structure.py` 用Clang完整raw token（含字面量与预处理边界）比三份头，共9,684项，与基线相同；五MSG共99声明完全相同。clang-format与受分工文件的git diff --check均退出0。

本分工未重跑全量回归、完整CMake/CTest、TSan、ARM64、实机和真实ROS；上层可据修改范围安排整体回归，不将历史结果充作本次新结果。

## 保留候选：低质量中间样本的历史

`candidate_quality.cpp`、`record_candidate.py`、`candidate_quality.json` 只保存在cache，不加入普通通过测试，不改变控制逻辑。精确复现：Controller已用quality=.9激活；Inbox缓存seq2/quality=.1，再在下一次step前缓存seq3/.9，撤销代数仍0，Controller继续active；另一条对照在seq2后立即step则沿 `VISION_QUALITY_INVALID` 请求Land。

这证明的是 **Inbox/Controller API不能独立保证记住每个低于Config.min_quality的中间样本**。`state_retracted`不持有Config，只知道质量是否越出[0,1]。注释已如实说明这一能力边界。

生产接线存在重要抵消条件：Node两个视觉回调每次都递增receive_events，活跃任务ReceivePassSchedule遇新事件后不再开始下一整轮spin_some；Humble spin_some为一次收集工作。若同订阅每pass只执行一次，则tick会先观察低质量，纯API反例不能按此顺序到达生产Controller。本分工没有证明可以在单pass内绕过这一条件，没有启动生产Node，也不把API反例写成已证实的真实飞行漏洞。

后续启用视觉或调整executor/接收策略之前，应专项验证到达次序与质量撤销政策。该候选暂定P2待确认；当前默认视觉关闭，没有据此修改RC接管、Kill、起飞或发布逻辑。

## 已有保护与外部条件

实际反馈与目标分别校验；两种时钟分别计龄；reset/sequence/source职责不同；运动后的显式撤销保持下降锁存。协方差C++校验仍仅有限性/非负对角线，不能证明对称或PSD；256 UTF-8字节预算不限制DDS已发生的反序列化分配。单一publisher/source文字不是认证或控制许可。

仍需上游提供米制尺度、准确时钟/抖动、机体安装外参/杆臂、对齐版本、质量定义、协方差变换与真实录包。主机接口通过不证明PX4已采用或板上性能满足。视觉默认false和原无视觉1.5m路线的实现均保持。
