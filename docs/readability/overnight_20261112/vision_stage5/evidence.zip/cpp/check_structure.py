from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
cache=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tests'))
import readability_equivalence as check
baseline='68b3221ac297699e1dfed8fd773358bb26789207'
headers=['native/src/jikl_fc01_system/include/jikl_fc01_system/'+name for name in ['vision_ros_adapter.hpp','vision_navigation.hpp','velocity_command_input.hpp']]
messages=['native/src/jikl_fc01_system/msg/'+name for name in ['VelocityCommand.msg','VisionState.msg','VisionHealth.msg','NavigationCommand.msg','AttitudeThrustPreview.msg']]
rows=[]
for name in headers+messages:
 previous=subprocess.check_output(['git','show',baseline+':'+name],cwd=root)
 current=(root/name).read_bytes()
 if name.endswith('.hpp'):
  a=check.cpp_structure(previous,shutil.which('clang++'))
  b=check.cpp_structure(current,shutil.which('clang++'))
  kind='complete raw token stream including literals and preprocessing boundaries'
 else:
  a=check.message_structure(previous.decode())
  b=check.message_structure(current.decode())
  kind='all ROS message declarations including constants and defaults'
 rows.append({'path':name,'baseline_sha256':hashlib.sha256(previous).hexdigest(),'current_sha256':hashlib.sha256(current).hexdigest(),'kind':kind,'count':len(a),'equivalent':a==b})
format_argv=['clang-format','--dry-run','--Werror',*headers,'native/tests/test_overnight_stage5_vision_contract.cpp']
f=subprocess.run(format_argv,cwd=root,text=True,capture_output=True)
(cache/'clang_format.log').write_text(f.stdout+f.stderr)
d=subprocess.run(['git','diff','--check','--',*headers,*messages,'native/tests/test_overnight_stage5_vision_contract.cpp'],cwd=root,text=True,capture_output=True)
report={'baseline':baseline,'rows':rows,'all_equivalent':all(r['equivalent'] for r in rows),'format':{'argv':format_argv,'returncode':f.returncode,'stderr':f.stderr},'diff_check':{'returncode':d.returncode,'stdout':d.stdout,'stderr':d.stderr}}
(cache/'structure.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(0 if report['all_equivalent'] and f.returncode==0 and d.returncode==0 else 1)
