from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
cache=Path(__file__).resolve().parent
names=['test_vision_navigation','test_velocity_command_input','test_stage3_vision_resource_budget','test_visual_runtime','test_overnight_stage5_vision_contract']
results=[]
for name in names:
 source=root/'native/tests'/(name+'.cpp')
 output=cache/name
 commands=[['g++','-std=c++17','-Wall','-Wextra','-Werror','-pedantic','-I',str(root/'native/src/jikl_fc01_system/include'),str(source),'-o',str(output)],[str(output)]]
 row={'source':str(source.relative_to(root)),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'steps':[]}
 for index,cmd in enumerate(commands):
  start=time.monotonic()
  r=subprocess.run(cmd,cwd=root,text=True,capture_output=True)
  log=cache/(name+('.compile.log' if index==0 else '.run.log'))
  log.write_text(r.stdout+r.stderr)
  row['steps'].append({'argv':cmd,'returncode':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log),'stdout':r.stdout,'stderr':r.stderr})
  if r.returncode: break
 row['passed']=len(row['steps'])==2 and all(s['returncode']==0 for s in row['steps'])
 results.append(row)
 print(name,row['passed'],row['steps'][-1]['stdout'].strip())
# 仅新增合成测试做主机内存/未定义行为检查；不冒充ARM64或全量sanitizer。
source=root/'native/tests/test_overnight_stage5_vision_contract.cpp'
output=cache/'test_overnight_stage5_vision_contract_asan_ubsan'
cmd=['g++','-std=c++17','-Wall','-Wextra','-Werror','-pedantic','-g','-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(root/'native/src/jikl_fc01_system/include'),str(source),'-o',str(output)]
row={'kind':'new contract ASan/UBSan','steps':[]}
for index,argv in enumerate([cmd,[str(output)]]):
 env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
 r=subprocess.run(argv,cwd=root,text=True,capture_output=True,env=env)
 log=cache/('contract_sanitizer'+('.compile.log' if index==0 else '.run.log'))
 log.write_text(r.stdout+r.stderr)
 row['steps'].append({'argv':argv,'returncode':r.returncode,'log':str(log),'stdout':r.stdout,'stderr':r.stderr})
 if r.returncode: break
row['passed']=len(row['steps'])==2 and all(s['returncode']==0 for s in row['steps'])
results.append(row)
print(row['kind'],row['passed'])
r=subprocess.run(['python3','native/tests/adapter_compile_check.py'],cwd=root,text=True,capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
(cache/'adapter_compile_check.log').write_text(r.stdout+r.stderr)
results.append({'kind':'existing narrow ROS/PX4 API syntax fixture','argv':['python3','native/tests/adapter_compile_check.py'],'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'passed':r.returncode==0,'not_real_ROS':True})
report={'baseline':'68b3221ac297699e1dfed8fd773358bb26789207','tests':results,'all_passed':all(r['passed'] for r in results),'scope':'Pure host binaries and syntax-only fixture; no production node/ROS/Agent/service/hardware execution.'}
(cache/'targeted.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
sys.exit(0 if report['all_passed'] else 1)
