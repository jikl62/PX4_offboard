#include "jikl_fc01_system/vision_navigation.hpp"
#include <cassert>
#include <iostream>
namespace v = fc01::vision;
v::Input input() {
  v::Input in;
  in.ros_now_ns = 100000000000ULL;
  in.state_publishers = in.command_publishers = 1;
  auto& s = in.state;
  s.sequence = 1; s.stamp_ns = in.ros_now_ns; s.received_at = 10;
  s.frame_id = "fc01_vision_ned"; s.body_frame_id = "base_link_frd";
  s.source_id = "synthetic-camera";
  s.initialized = s.tracking = s.calibration_valid = true;
  s.valid_fields = v::Position | v::Velocity | v::Attitude | v::Quality;
  s.position = {0,0,0}; s.velocity = {0,0,0}; s.attitude = {1,0,0,0}; s.quality = .9;
  auto& c = in.command;
  c.sequence = 1; c.stamp_ns = in.ros_now_ns; c.received_at = 10;
  c.source_id = "synthetic-client"; c.frame_id = s.frame_id;
  c.valid = true; c.mode = v::Mode::Hold;
  return in;
}
int main() {
  auto in = input();
  v::Config config; config.enabled = true;
  v::Inbox inbox;
  assert(inbox.state(in.state, 10) && inbox.command(in.command, 10));
  v::Controller controller(config);
  assert(controller.step(inbox.snapshot(in.ros_now_ns,1,1),10,1.5,0,.05).active);
  std::cout << "{\"trace\":\"shared_initial\",\"quality\":0.9,\"min_quality\":0.5,\"sequence\":1,\"active\":true,\"revocation_generation\":0}\n";
  auto low = in.state;
  low.sequence = 2; low.stamp_ns += 1000000; low.quality = .1;
  assert(inbox.state(low,10.001));
  const auto at_low = inbox.snapshot(in.ros_now_ns+1000000,1,1);
  v::Controller directly_observing(config);
  assert(directly_observing.step(in,10,1.5,0,.05).active);
  const auto rejected = directly_observing.step(at_low,10.001,1.5,0,.001);
  assert(rejected.request_land && rejected.reason == "VISION_QUALITY_INVALID");
  std::cout << "{\"trace\":\"tick_observes_low_quality\",\"quality\":0.1,\"sequence\":2,\"active\":" << rejected.active << ",\"request_land\":" << rejected.request_land << ",\"reason\":\"" << rejected.reason << "\",\"revocation_generation\":" << at_low.revocation_generation << "}\n";
  auto healthy = in.state;
  healthy.sequence = 3; healthy.stamp_ns += 2000000;
  assert(inbox.state(healthy,10.002));
  const auto after = inbox.snapshot(in.ros_now_ns+2000000,1,1);
  const auto result = controller.step(after,10.002,1.5,0,.002);
  assert(after.revocation_generation == 0 && result.active && !result.request_land);
  std::cout << "{\"trace\":\"tick_observes_healthy_tail_after_low_quality\",\"intermediate_quality\":0.1,\"quality\":0.9,\"sequence\":3,\"active\":" << result.active << ",\"request_land\":" << result.request_land << ",\"reason\":\"" << result.reason << "\",\"revocation_generation\":" << after.revocation_generation << "}\n";
  std::cout << "CANDIDATE_REPRODUCED low_quality=.1 min_quality=.5 direct_reason="
    << rejected.reason << " healthy_tail_active=" << result.active
    << " revocation_generation=" << after.revocation_generation << '\n';
}
