from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
cache=Path(__file__).resolve().parent
source=cache/'candidate_quality.cpp'
binary=cache/'candidate_quality'
commands=[['g++','-std=c++17','-Wall','-Wextra','-Werror','-pedantic','-I',str(root/'native/src/jikl_fc01_system/include'),str(source),'-o',str(binary)],[str(binary)]]
steps=[]
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=root,text=True,capture_output=True)
 (cache/('candidate_quality.compile.log' if i==0 else 'candidate_quality.run.log')).write_text(r.stdout+r.stderr)
 steps.append({'argv':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 if r.returncode:break
paths=['native/src/jikl_fc01_system/src/fc01_system_node.cpp','native/src/jikl_fc01_system/include/jikl_fc01_system/vision_navigation.hpp','native/src/jikl_fc01_system/include/jikl_fc01_system/vision_ros_adapter.hpp','native/src/jikl_fc01_system/include/jikl_fc01_system/runtime.hpp','native/src/jikl_fc01_system/include/jikl_fc01_system/attitude_altitude_core.hpp','native/src/jikl_fc01_system/include/jikl_fc01_system/receive_schedule.hpp']
report={
 'id':'CANDIDATE-VISION-QUALITY-INTERMEDIATE',
 'classification':'Reproduced Inbox/Controller API history gap, production scheduling reachability not established; no control behavior change made.',
 'priority':'P2 candidate before enabling vision; not evidence of a current default-disabled flight defect.',
 'baseline':'68b3221ac297699e1dfed8fd773358bb26789207',
 'candidate_source':str(source),'candidate_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'steps':steps,
 'observed':'Controller observing quality=.1 immediately locks Land with VISION_QUALITY_INVALID. Inbox receiving .1 then .9 before Controller step leaves revocation_generation=0 and Controller active.',
 'source_evidence':[
  {'path':paths[0],'symbol':'SystemNode constructor visual callbacks','fact':'Each received visual callback increments receive_events_ and maps message into visual_inbox_.state/command; no separate quality latch in callback.'},
  {'path':paths[0],'symbol':'SystemNode::snapshot','fact':'When enabled, copies only Inbox snapshot to Snapshot.attitude.visual_input.'},
  {'path':paths[1],'symbol':'Inbox::state_retracted','fact':'Quality range [0,1] checked; Config.min_quality unavailable here.'},
  {'path':paths[1],'symbol':'Controller::validate_state','fact':'Quality below Config.min_quality is rejected at step/current.'},
  {'path':paths[3],'symbol':'Runtime::step/attitude_snapshot/visual_output_current','fact':'Supplies current snapshot to Core; no separate historical quality latch found.'},
  {'path':paths[4],'symbol':'Core HeightHold visual step/current','fact':'Calls visual_.step/current on snapshot after original navigation permission gates.'},
  {'path':paths[0],'symbol':'SystemNode::stop_receive_on_events and main receive loop','fact':'Active-output routes stop extra receive passes when events count changes; visual callbacks always increment it.'},
  {'path':paths[5],'symbol':'ReceivePassSchedule::next_pass','fact':'Event boundary stops before another complete spin_some pass; does not preempt within a pass.'}
 ],
 'production_limit':'Humble spin_some collects work once; one-subscription-per-pass implementation may ensure tick observes each delivered low-quality state before a healthy successor. This is a plausible mitigation and has not been bypassed here. Pure API counterexample is not called a proven production-node defect.',
 'required_followup':'Before enabling vision or changing executor/reception wiring, independently establish callback reachability and decide threshold-based revocation semantics. Do not force fix through generic bad-message latching without ordering/quality-policy review.',
 'source_shas':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},
 'boundary':'Only host API replay; no ROS graph, Agent, production node, motor, deployment, config, or core behavior mutation.'
}
(cache/'candidate_quality.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'classification':report['classification'],'run_exit':steps[-1]['returncode'],'stdout':steps[-1]['stdout']},ensure_ascii=False,indent=2))
