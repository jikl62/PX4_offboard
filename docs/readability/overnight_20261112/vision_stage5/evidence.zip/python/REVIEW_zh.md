# 队列 5：Python 视觉接入独立审查记录

基线为 `68b3221ac297699e1dfed8fd773358bb26789207`。只检查视觉 Python 工具、相关单元测试和真实 ROS 冒烟脚本；没有操作硬件、启动 ROS、提交或部署。代码与测试已冻结，具体文件 SHA 见 `freeze.json`，基线 SHA 见 `baseline.json`。

## 实际修改

| 文件 | 审查后的处理 |
|---|---|
| `native/tools/vision_odometry_adapter.py` | 保留原函数和 docstrings，只补两条中文边界：ROS 主路径使用 GuardedOdometryAdapter；`time_sync_valid` 是上游声明，不是本地测出的同步误差。 |
| `native/tools/vision_state_validation.py` | 只补中文说明，强调独立 Validator 必须由调用方显式运行，其 offset 不会写入系统时钟或上游消息。 |
| `native/tools/velocity_command_diagnostic.py` | 只解释图中 publisher 数量不证明 QoS 匹配或来源真实性；没有新增发布器。 |
| `native/tools/vision_resource_budget.py` | 已有说明足够；原字节保留，没有重复加注释。 |
| `tests/test_vision_adapter.py` | 增强已有组合变换场景，不增加测试方法数量：加入非零速度、角速度，核对世界对齐、安装外参与杆臂同时存在时的位置、姿态、速度、角速度。 |

三份生产工具的完整 AST 均与基线相同，包括全部原 docstrings；资源预算工具原字节相同。没有调整消息字段、schema、CLI、参数默认值、Topic、QoS、配对窗口、质量阈值、时钟政策或控制权限。这里没有新增功能修复提交。

## 实际接线与必须说清的边界

实际状态路径是 `Odometry + 同测量 stamp 的 VisionHealth → GuardedOdometryAdapter → VisionState`。原始 pose 属于世界坐标，twist 属于 child 坐标；转换后位置/线速度是世界 NED，角速度是机体 FRD，姿态 Hamilton wxyz 表示机体 FRD 到世界 NED。目标 `VelocityCommand` 是独立的 `body_frd` 制导意图，不能拿它填补实际线速度。

安装外参与世界对齐分别处理机体/传感器关系和世界关系；非零杆臂的位置需扣除姿态旋转后的传感器偏移，速度需扣除旋转引起的 `omega×r`。新增断言使用可以手算的场景：世界旋转把传感器速度 `(2,3,4)` 变为 `(-3,2,4)`，机体姿态恰为单位旋转，杆臂旋转速度为 `(0,2,0)`，因此机体原点实际速度是 `(-3,0,4)`。测试同时核对位置 `(-6,7,10)`、单位姿态及角速度 `(0,0,2)`。

严格同 stamp 配对只证明两个包声明了同一测量时刻。配对等待用本机单调秒；测量/源年龄使用 ROS 纳秒，两者不能互换。旧配对超时先于新回调处理；重复半包不续期；冲突清队列，数量恢复后需新完整配对。ROS adapter 没有调用离线 Validator，不能把离线 TTL、连续性、可信 epoch、协方差 PSD 诊断说成真实 ROS 链路已经执行的政策。后续消费者仍有自己的接收/源年龄与质量要求。

只读目标诊断器的 `accepted`、`cache_usable`、历史 last accepted 和最近 anomaly 含义不同。旧缓存先检查失效，健康尾包不能抹掉断流事件；同源 reset 允许新序号周期，但不允许测量时钟回退；显式 valid=false 也消耗可信序号。无论是否诊断通过，`control_authority` 均为 false。

资源预算为 256 UTF-8 字节，身份不可截断后再授权；日志可截断显示。这限制应用层复制、缓存和日志，不保证 ROS/DDS 反序列化前的内存分配上界。协方差只在离线诊断原始坐标；输出仍 NaN 且 covariance 有效位清零，没有实现完整坐标与杆臂雅可比变换。

## 真实验证结果

- 6 个相关离线模块共 **148 方法，通过 148，无失败、错误或跳过**：转换、状态验收、只读目标诊断、身份预算、适配器生命周期、目标诊断生命周期。该计数是受影响子集，不可与全量重复累计。
- 完整生产 AST（含 docstrings）与基线一致；全部 5 个审查文件编译语法通过，无生成源码缓存。
- `git diff --check` 通过。最初系统 Python 无 Black，退出 1，保留 `black.initial.log`；使用既有 format_tools 后 5 文件检查通过，退出 0，保留 `black.final.log`。没有下载或安装新工具。
- 阅读了真实 ROS adapter/velocity smoke 的接口、隔离域、消息生成、QoS、来源冲突、资源拒绝、只读参数、图端点、SIGINT/退出证据；**本代理没有再次执行 ROS smoke**。最终真实通信由 root 对冻结 SHA 一并执行，不能把历史阶段通过充作本轮执行。

`unit.json/log` 保存实际测试方法与结果，`ast.json` 保存逐文件原/新哈希和完整结构比较，`review.json` 保存逐文件审查点，`commands.json` 提供复跑入口，`freeze.json` 给出交接快照。

## 本轮结论与仍需外部证据的事项

这次审查没有复现新的 Python 功能缺陷，因而没有人为制造独立修复。已有清理和退出竞态修复保留；有限测试不能证明任意时序或资源耗尽均安全。

视觉接入前仍需要明确实际相机/IMU 标定、世界与机体坐标、安装杆臂、米制尺度、测量时钟对应及抖动、质量定义、真实 tracking/reset 行为和录包。图数量不认证发送者，应用预算不约束反序列化之前的分配，协方差转换未完成。没有证据把这些条件直接标成已造成飞行故障；也不能因此宣布已具备视觉动力试飞条件。
