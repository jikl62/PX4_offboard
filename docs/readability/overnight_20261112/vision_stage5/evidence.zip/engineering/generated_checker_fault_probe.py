from pathlib import Path
import importlib.util,json,hashlib
from unittest.mock import patch
import rclpy.serialization as serialization
from rosidl_runtime_py.utilities import get_message
file=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028/tests/ros_generated_interface_check.py')
spec=importlib.util.spec_from_file_location('fc01_generated_fault_checker',file); helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
prefix=Path('/home/jikl62/.cache/fc01-vision-stage5-20261112-een8twou/ros/install/jikl_fc01_system')
original=serialization.serialize_message;rows=[]
for mode in ['padding_only','uint64_bit','float64_sign_bit','extra_protocol_constant']:
 report={'messages':[]}; calls=[0]
 def corrupt(message):
  wire=original(message);calls[0]+=1
  if calls[0]!=1:return wire
  data=bytearray(wire)
  if mode=='padding_only':data[6]^=0xff
  elif mode=='uint64_bit':data[12]^=1
  elif mode=='float64_sign_bit':data[-1]^=0x80
  return bytes(data)
 extra=patch.object(get_message('jikl_fc01_system/msg/VisionState'),'EXTRA_PROTOCOL_CONSTANT',123,create=True)
 try:
  if mode=='extra_protocol_constant':extra.start()
  with patch.object(serialization,'serialize_message',corrupt):helper.check_installation(prefix,report)
 except Exception as error:
  outcome={'accepted':False,'error_type':type(error).__name__,'error':str(error)}
 else:outcome={'accepted':True,'messages':len(report['messages'])}
 finally:
  if mode=='extra_protocol_constant':extra.stop()
 expected=mode=='padding_only';rows.append({'mode':mode,**outcome,'matches_expected':outcome['accepted']==expected})
result={'checker_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'ros_init_called':False,'nodes_created':False,'cases':rows,'passed':all(x['matches_expected'] for x in rows)}
Path('/home/jikl62/.cache/fc01-vision-stage5-20261112-een8twou/engineering/generated_checker_faults.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(0 if result['passed'] else 1)
