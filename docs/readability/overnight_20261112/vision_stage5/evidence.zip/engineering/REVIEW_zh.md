# 队列 5/7：ROS 2 工程接线与源配置复核

基线为 `68b3221`，工作分支 `readability/fc01-chinese-20261111`。本子任务只改三处生产文件的普通注释，并新增一份静态合同测试；未运行 ROS、构建、Agent、控制节点、串口、部署或 Git 提交。真实 Humble 构建、最终安装身份和通信测试由 root 统一执行。

## 逐文件结论

| 文件/范围 | 审查结果 | 处理 |
|---|---|---|
| `native/src/jikl_fc01_system/CMakeLists.txt` | 五份 MSG 统一在本包生成；引用 `builtin_interfaces/Time`；C++ 节点链接同次生成的 `rosidl_typesupport_cpp`。两个 Python 入口以 PROGRAMS 安装，状态校验和预算模块以 FILES 安装，四者相邻。 | 仅补中文解释：生成不等于只复制 MSG、`nav_msgs` 是 Python 运行依赖、旁置模块定位不依赖工作目录。移除整行注释后与基线逐字节相同。 |
| `native/src/jikl_fc01_system/package.xml` | 包名 `jikl_fc01_system`，版本保持 `0.4.6`；`rosidl_default_generators`、接口包组和 `rosidl_default_runtime` 齐全。`rclpy/rcl_interfaces/nav_msgs` 是 exec_depend。 | 仅补运行依赖与 C++ 构建依赖的边界说明；移除整行 XML 注释后与基线逐字节相同。 |
| `navigation_environment.sh` | 加载 Humble 后再加载选定 SDK；保留 nounset 状态和失败退出码；正式链路域 0/网络 DDS 合同保持。SDK 环境不单独证明本轮生成的 FC01 类型已安装。 | 仅补依赖环境与自研接口身份的区分；移除整行注释后与基线逐字节相同。 |
| `native/scripts/install.sh` | 源包在 `workspace/src/jikl_fc01_system`，同时复制 `workspace/tools`，满足 CMake 的 `../../tools`；构建和 current 切换分开。 | 原字节保留；只读审查，未执行。 |
| `native/scripts/r632_build.sh` | 生产包与选定 px4_msgs workspace 编译到独立 build/install；构建不是节点启动。 | 原字节保留；只读审查，未执行。 |
| `native/scripts/run.sh` | 清除 overlay 变量后按本次 workspace 加载；sim 域有独立限制。它会实际 exec 控制器，因此本轮不运行。 | 原字节保留。 |
| `navigation_build_fresh.sh / navigation_boot.sh / navigation_restore.sh / navigation.sh / standby.sh / start.sh` | 入口职责和环境选择保持；正式导航、历史入口和独立工具不能按同名文件猜同一执行合同。 | 原字节保留，只读复核。 |
| `native/config` 全部 10 份 `.yaml`，含 historical | 名称均对应实际 C++ 声明；标量类型与 bool/double/int64/string 声明匹配。未显式列出的视觉开关沿用 C++ 默认 false；所有显式视觉门均 false。 | 全部原字节保留，不更改任何值、重复项、阈值或动作门。 |
| 根目录/native/scripts 共 36 份 Shell | 全部 `bash -n` 通过；全部非整行注释内容与基线相同。此项是语法/保真检查，不能扩大解释为对每个历史入口逐行重新审查。 | 未执行 Shell 载荷。 |
| `tests/test_overnight_stage5_ros_contract.py` | 两项测试约束五消息生成/类型支持链接，以及四工具的安装相邻关系/运行依赖；不导入 ROS。 | 新增 2 方法，2/2 通过；Black check、diff check 通过。 |

完整 SHA、逐文件条目、参数类型检查和重复键行号在 `static_review.json`；命令及真实结果在 `verification.json`，原始日志并列保存。Black 首次未设置 target 安装路径导致的环境错误也如实保留；之后用现有安装路径成功排版和校验。

## 接口身份和 QoS

原生 `fc01_system` 与两个独立 Python 节点各有自己的参数空间。给原生节点填写 `visual_state_topic` 不会替独立 adapter 填入 `input_topic/health_topic`、外参或来源；adapter 的参数必须显式给对应节点。

| 接收/输出 | 默认话题 | 默认 QoS |
|---|---|---|
| Adapter 转换后的实际状态输出 | `/fc01/vision/state` | depth 5，BEST_EFFORT，VOLATILE |
| Adapter 原始 Odometry | 必须显式配置 | depth 5，BEST_EFFORT，VOLATILE |
| Adapter 配对 Health | 必须显式配置 | depth 5，RELIABLE，VOLATILE |
| 原生视觉状态订阅 | `/fc01/vision/state` | depth 5，BEST_EFFORT，VOLATILE |
| 原生既有 NavigationCommand 订阅 | `/fc01/navigation/command` | depth 5，RELIABLE，VOLATILE |
| 只读 VelocityCommand 诊断订阅 | `/fc01/vision/velocity_command` | depth 5，BEST_EFFORT，VOLATILE；没有控制发布者 |

原生两条视觉订阅仅在视觉配置启用时创建。本轮仍关闭。`VelocityCommand` 与 `NavigationCommand` 是不同 ROS 类型，不能因都表示制导目标就互换。RELIABLE 订阅要求匹配来源能提供可靠性，不能把 QoS 不匹配误判成转换算法没有数据；VOLATILE 和深度限制也不能替代 TTL/来源校验。

## 可复用的 Humble 缓存

已有缓存位于 `/home/jikl62/.cache/fc01-interfaces-stage3-irwed8ap/ros`：

- `build/jikl_fc01_system/CMakeCache.txt` 的 `CMAKE_HOME_DIRECTORY` 指向本次实际源码包。
- px4_msgs underlay 是 `/home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs`。
- `install/jikl_fc01_system` 中四个 Python 文件、五个生成 Python 消息、五份安装 MSG、C/C++/Python 类型支持及控制器产物共 19 项只读检查存在。
- `readelf -d` 确认旧控制器声明本包 C++ 类型支持依赖和 `$ORIGIN` 相对运行路径；没有执行旧控制器。

这些是上一阶段 x86_64 缓存的可复用条件，**不是本阶段已经重新构建或最终安装字节已经验收的结论**。缓存中的旧 Python 文件不可冒称本阶段最终文件；root 应先构建/安装冻结后的源码，再记录实际 import/CDR 路径与最终文件 SHA。

以前的完整命令在 `interfaces_stage3/evidence.zip` 的 `ros/final_build.command.sh`、`ros/vision_smoke.command.sh`、`ros/velocity_retry.command.sh`。建议保留依赖顺序、CMake 的系统 Python、资源限制和 localhost 隔离，以本轮 cache 保存日志；测试域由 root 统一选择并先查空图，不在子任务并发启动第二套 ROS。可复用原 `preflight_domain.py`，速度和状态烟测分别写独立报告。

## 保留的结构债和边界

`diagnostic.yaml` 与 `flight_test.yaml` 各有重复的 `rc_navigation_enabled`、`visual_navigation_enabled`，重复值均为同类型 false。当前检查没有发现同文件冲突值；本轮按“YAML 只注释、不改值/执行内容”保留原字节。这是 P3 结构债，后续若去重应独立确认 ROS 参数解析和全部配置合同，不能混在注释修改里。

静态声明和缓存文件存在不证明最终动态链接成功或对端 QoS 已匹配；真实 Humble 构建/通信由 root 做本阶段新证据。DDS 反序列化前分配、板上 ARM64 性能、真实视觉传感器的时钟/尺度/外参和 PX4 采用，仍需要对应独立证据。本子任务未发现新确认的功能缺陷，未改变 RC、定高起飞、推力、Kill、Failsafe 或任何控制授权。

## 追加：可复用生成接口检查入口

新增 `tests/ros_generated_interface_check.py`，显式传入 `--prefix <本轮 isolated install/jikl_fc01_system>` 与 `--report <cache/文件.json>`。普通 import 和 `--help` 不加载 ROS。正式调用只加载生成类型和本机序列化，不调用 init 或创建 Node/Publisher；失败非零并记录原 traceback，写报告失败也非零。

它校验 ament prefix/share、包与五类 Python 模块和 C typesupport 扩展的实际文件均属于指定前缀，安装 MSG 与本次源码字节相同；从当前简单 MSG 声明取得字段顺序/类型、12 个常量和全部默认值；对五类非默认 fixture 做 CDR 往返和再次编码的字节比对。uint64 fixture 大于 `2**53`，数组用可精确表示且各元素不同的数值，来源字符串包含 UTF-8 中文。合成 fixture 只测试编码，不声称物理有效或有权限。声明解析用于发现生成物漂移，不证明协议本身正确。

本子任务未运行真实 ROS/CDR 检查；已做纯语法、普通 import 不新增 ROS 模块、99 声明解析和标准库替身赋值、help、Black 检查。源码冻结 SHA 与预检结果在 `generated_interface_preflight.json`；最终真实结果由 root 在新构建后统一收集。

### 新安装后的检查工具纠错与最终真实结果

初版 checker 的真实生成接口检查失败，不能把此前纯静态预检当成真实 CDR 通过。原始源码 SHA `2a538a2a96b3a06e96c81c8d5593cf6a5b2840a68de672a5962595d7e2525e7a` 及源码副本、初轮日志/报告均保留。实际读取本轮安装的五类命名空间，确认 `SLOT_TYPES` 是生成器字段类型描述元组，首版误把该大写元数据算成协议常量。现在只排除已核实的 `SLOT_TYPES`，真正的额外大写协议常量仍会失败。

仅修正该筛选的 retry1 又失败：`VelocityCommand` 往返字段完全一致，但 CDR 再编码字节不同。这里确认的是 checker 错误假定了对齐填充必须稳定。独立布局探针按 CDR1 的四字节封装头/负载起点，逐字段计算填充；在本进程先填充并释放自己申请的 A5/5A 堆缓冲后，每类 20 次均复现差异，全部只出现在已计算的填充偏移，字段和总长度全部一致。未修改 ROS 中间件或消息字段；无扰动重复对照也保留。原始字节、精确字段/填充偏移见 `generated_cdr_padding_churn.json`；不要把这些重复次数累计成新的独立测试场景。

最终 checker 仅允许已确认 CDR1 填充变化，仍要求全部非填充字节一致，并再次解码核对全部真实整数、浮点、字符串和数组。未知封装或布局长度不符直接失败。报告记录每段填充所处字段、偏移、长度和实际差异偏移，因此没有把任意字节差异全部忽略。原始 CDR SHA 是本次实际字节记录，不是跨进程稳定内容身份。

最终 `ros/generated_interfaces_retry2.report.json` 五消息全部通过、进程退出 0；SHA `d520e78938f1310945542df9d923064bf896301dc4d754701b187c33a973c9cf` 与实际运行报告一致。另作真实 CDR 故障注入：仅翻转填充字节可通过；翻转 uint64 数据位、float64 符号位或增加协议常量均被原对应检查拒绝。该补充不启动 ROS 图，未调用 init、创建 Node/Publisher 或重跑通信 smoke。Black 和 diff check 通过，最终源码冻结。

`generated_checker_final_verification.json` 汇总两次失败、三份源码快照、命名空间、布局复现、最终通过和拒绝路径证据。这里的修复仅作用于新测试入口，不改变任何生产源码或飞行行为。
