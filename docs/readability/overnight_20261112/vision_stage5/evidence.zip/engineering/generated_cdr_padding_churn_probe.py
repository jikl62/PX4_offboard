from pathlib import Path
import importlib.util,json,hashlib,ctypes
from rclpy.serialization import serialize_message,deserialize_message
from rosidl_runtime_py.utilities import get_message
file=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028/tests/ros_generated_interface_check.py')
spec=importlib.util.spec_from_file_location('fc01_cdr_probe_checker',file); helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
rows=[]
libc=ctypes.CDLL(None)
libc.malloc.argtypes=[ctypes.c_size_t];libc.malloc.restype=ctypes.c_void_p
libc.free.argtypes=[ctypes.c_void_p];libc.free.restype=None
def churn(size,byte):
    address=libc.malloc(size)
    if not address: raise MemoryError('probe allocation failed')
    ctypes.memset(address,byte,size);libc.free(address)

for name in helper.MESSAGE_NAMES:
 fields,constants=helper.parse_declarations((helper.SOURCE_PACKAGE/'msg'/(name+'.msg')).read_bytes()); cls=get_message(helper.PACKAGE+'/msg/'+name); msg=cls();helper.fill_fixture(msg,fields)
 # CDR1 encapsulation is four bytes; alignment is relative to the following payload.
 offset=4; padding=[]; regions=[]
 for field in fields:
  typ=field['type']; value=helper.field_value(msg,field)
  align=4 if typ in ['string','builtin_interfaces/Time'] else 8 if typ.startswith('float64') or typ=='uint64' else 4 if typ=='uint32' else 2 if typ=='uint16' else 1
  gap=(-(offset-4))%align; padding.extend(range(offset,offset+gap));offset+=gap
  length=4+len(value.encode())+1 if typ=='string' else 8 if typ=='builtin_interfaces/Time' else 8*len(value) if '[' in typ else align
  regions.append({'field':field['name'],'offset':offset,'bytes':length});offset+=length
 serial=[]
 for attempt in range(20):
  churn(offset,0xa5);wire=serialize_message(msg); restored=deserialize_message(wire,cls);churn(offset,0x5a);rewire=serialize_message(restored)
  differences=[i for i,(a,b) in enumerate(zip(wire,rewire)) if a!=b]
  serial.append({'attempt':attempt,'wire_hex':wire.hex(),'rewire_hex':rewire.hex(),'bytes':len(wire),'reencoded_bytes':len(rewire),'differing_offsets':differences,'differences_subset_of_padding':set(differences)<=set(padding),'all_fields_equal':all(helper.field_value(msg,f)==helper.field_value(restored,f) for f in fields)})
 rows.append({'name':name,'cdr1_header':serial[0]['wire_hex'][:8],'expected_bytes':offset,'alignment_origin':4,'padding_offsets':padding,'fields':regions,'serializations':serial})
result={'checker_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'ros_init_called':False,'nodes_created':False,'rows':rows}
Path('/home/jikl62/.cache/fc01-vision-stage5-20261112-een8twou/engineering/generated_cdr_padding_churn.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{'name':r['name'],'padding_offsets':r['padding_offsets'],'mismatch_attempts':sum(bool(x['differing_offsets']) for x in r['serializations']),'all_fields_equal':all(x['all_fields_equal'] for x in r['serializations']),'all_differences_padding_only':all(x['differences_subset_of_padding'] for x in r['serializations']),'computed_size_matches':all(x['bytes']==r['expected_bytes']==x['reencoded_bytes'] for x in r['serializations'])} for r in rows],ensure_ascii=False,indent=2))
