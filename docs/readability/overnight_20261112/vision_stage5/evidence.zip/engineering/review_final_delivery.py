from pathlib import Path,PurePosixPath
import ast,hashlib,io,json,re,subprocess,tarfile,zipfile
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028');base=Path('/home/jikl62/.cache/fc01-vision-stage5-20261112-een8twou'); p=root/'docs/readability/overnight_20261112/vision_stage5'
baseline='68b3221ac297699e1dfed8fd773358bb26789207';source='15310f8776d182e668cc846f97ff23c5753995da'
issues=[]; checks={}
def need(ok,msg):
 if not ok:issues.append(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def tree(ref):
 with tarfile.open(fileobj=io.BytesIO(git('archive',ref))) as tar:return {m.name:tar.extractfile(m).read() for m in tar if m.isfile()}
b=tree(baseline); c=tree(source)
v=json.loads((p/'verification.json').read_text()); cf=json.loads((p/'changed_files.json').read_text()); ledger=json.loads((p/'review_ledger.json').read_text())
need(git('rev-parse','HEAD').decode().strip()==source,'actual HEAD differs')
for d,name in [(v,'verification'),(cf,'changed_files')]:need(d['baseline']==baseline and d['source_commit']==source,name+' commit mismatch')
need(ledger['baseline']==baseline,'ledger baseline mismatch')
changed=git('diff','--name-only',baseline,source).decode().splitlines(); need(sorted(changed)==sorted(x['path'] for x in cf['files']),'changed manifest paths differ from git diff')
need(len(changed)==cf['file_count']==21,'changed count not21')
for row in cf['files']:
 f=row['path']; need(c[f]==(root/f).read_bytes() and sha(c[f])==row['sha256'] and len(c[f])==row['bytes'] and len(c[f].splitlines())==row['lines'],f+' changed-file metadata mismatch')
 need((sha(b[f]) if f in b else None)==row['baseline_sha256'],f+' baseline SHA mismatch')
checks['changed_files']=len(changed)
ledgerpaths=set()
for key in ['cpp_and_messages','engineering_modified','environment_entries','yaml','shell','root_configuration_and_new_tools']:
 for row in ledger[key]:
  f=row['path']; ledgerpaths.add(f)
  if 'sha256' in row:need(sha(c[f])==row['sha256'],key+': source SHA mismatch '+f)
for row in ledger['python']:ledgerpaths.add(row['file'])
need(set(changed)<=ledgerpaths,'changed files missing from ledger')
checks['ledger_all_changes_covered']=True
for row in v['checks']['integrity']['protected_files']:
 f=row['path'];need(c[f]==b[f] and sha(c[f])==row['sha256']==row['baseline_sha256'],f+' protected bytes mismatch')
checks['protected_files']=len(v['checks']['integrity']['protected_files']);need(checks['protected_files']==54,'protected count not54')
for row in ledger['yaml']:need(c[row['path']]==b[row['path']] and row['visual_navigation_enabled'] is False,'YAML changed or gate true')
for row in ledger['engineering_modified']:
 prefix=b'<!--' if row['path'].endswith('.xml') else b'#'
 strip=lambda data:b'\n'.join(x for x in data.splitlines() if not x.lstrip().startswith(prefix))
 need(strip(b[row['path']])==strip(c[row['path']]),'engineering executable contents changed '+row['path'])
checks['configuration']={'yaml_exact_bytes':len(ledger['yaml']),'shell_static_records':len(ledger['shell']),'executable_engineering_content_equal':True}
for row in json.loads((base/'python/ast.json').read_text()):
 f=row['file'];need(ast.dump(ast.parse(b[f]),include_attributes=False)==ast.dump(ast.parse(c[f]),include_attributes=False),'full Python AST changed '+f)
for row in v['checks']['integrity']['comment_ast']:
 old=git('show',row['reference']+':'+row['path']);need(ast.dump(ast.parse(old),include_attributes=False)==ast.dump(ast.parse(c[row['path']]),include_attributes=False),'root comment AST differs '+row['path'])
structure=json.loads((base/'cpp/structure.json').read_text()); counts={'cpp':0,'msg':0}
for row in structure['rows']:
 f=row['path']; need(sha(b[f])==row['baseline_sha256'] and sha(c[f])==row['current_sha256'] and row['equivalent'],'structure source snapshot mismatch '+f)
 counts['cpp' if f.endswith('.hpp') else 'msg']+=row['count']
need(counts=={'cpp':9684,'msg':99},'structure count mismatch');checks['structure_record_hashes']=counts
# Test collection is not executed; compare declared test methods and original result logs.
newmethods=[]
for f in changed:
 if f.startswith('tests/test_') and f.endswith('.py'):
  methods=lambda data:{(getattr(parent,'name',''),node.name) for parent in ast.walk(ast.parse(data)) if isinstance(parent,ast.ClassDef) for node in parent.body if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')}
  before=methods(b[f]) if f in b else set();after=methods(c[f]);need(before<=after,'removed unittest method '+f);newmethods.append({'path':f,'added':len(after-before)})
need(sum(x['added'] for x in newmethods)==8,'new unittest methods not8');checks['new_unittest_methods']=newmethods
raw=(base/'root_final.log').read_bytes(); rootlog=raw.decode('utf-8','backslashreplace'); result=json.loads((base/'root_final.json').read_text())
need(result==v['checks']['root_python'],'root result mismatch');need(sha(raw)==result['raw_log_sha256'],'root raw log SHA mismatch');need('Ran 612 tests' in rootlog and 'FAILED (errors=3)' in rootlog,'root log outcome mismatch');need(result['tests_run']==612 and result['passed_methods']==609 and len(result['errors'])==3 and not result['failures'] and not result['skips'],'root counts mismatch')
need(rootlog.count('RuntimeError: Curated source payload exceeds extractor bounds')==3,'root three known exceptions mismatch');need(len([f for f in c if str(PurePosixPath(f).parent)=='native/tests' and PurePosixPath(f).name.startswith('test_') and f.endswith('.cpp')])==81,'native top level sources not81')
unit=json.loads((base/'python/unit.json').read_text());need(unit==v['checks']['visual_python'] and unit['tests_run']==148 and unit['successful'],'visual result mismatch')
checks['regression_records']={'root':[612,609,3],'native_top_level_cpp':81,'visual_subset':148,'overlap_disclosed':True,'not_rerun_by_reviewer':True}
py={f for f in c if f.endswith('.py')};need(py==set(v['checks']['static']['python_compiled_paths']) and len(py)==126,'compiled Python set/count mismatch')
need(len(v['checks']['static']['format_results'][0]['argv'][4:])==9,'Black changed Python count not9')
checks['Python_compile_scope']=len(py)
# Only read existing installation and run records; no ROS import, init, build or subprocess test.
for name in ['build','generated_interfaces_retry2','vision','velocity']:
 d=json.loads((base/'ros'/f'{name}.result.json').read_text());need(d.get('exit',d.get('returncode'))==0,'ROS result nonzero '+name)
pre=json.loads((base/'ros/build.source_before.json').read_text());post=json.loads((base/'ros/build.source_after.json').read_text());need(pre==post and len(pre)==239 and all(sha(c[f])==h for f,h in pre.items()),'239 native build SHA mismatch');checks['native_build_frozen_files']=len(pre)
for row in v['checks']['integrity']['installed_sources']:
 need(Path(row['installed']).read_bytes()==c[row['source']] and sha(c[row['source']])==row['sha256'],'installed source mismatch '+row['source'])
checks['installed_final_source_files']=len(v['checks']['integrity']['installed_sources'])
smoke=json.loads((base/'ros/smoke.source_before.json').read_text());actualdrift=[f for f,h in smoke.items() if sha(c[f])!=h];need(actualdrift==['tests/ros_generated_interface_check.py']==v['checks']['integrity']['smoke_manifest_changed_files'],'smoke SHA drift differs from disclosure')
gen=json.loads((base/'ros/generated_interfaces_retry2.report.json').read_text()); prefix=base/'ros/install/jikl_fc01_system';need(gen['passed'] and len(gen['messages'])==5 and gen['script_sha256']==sha(c['tests/ros_generated_interface_check.py']),'final CDR checker mismatch')
for ident in [gen['python_package'],gen['python_msg_package'],gen['type_support_module']]+[row['python_module'] for row in gen['messages']]:
 path=Path(ident['path']);need(path.resolve().is_relative_to(prefix) and sha(path.read_bytes())==ident['sha256'],'generated identity outside prefix or SHA changed')
need(Path(gen['ament']['prefix'])==prefix,'ament identity mismatch')
for row in gen['messages']:
 need(row['passed'] and row['type_support_loaded'] and row['cdr_twice_decoded_fields_exact'] and row['defaults']['schema_version']==1,'generated row incomplete '+row['name'])
 need(row['source_msg_sha256']==sha(c['native/src/jikl_fc01_system/msg/'+row['name']+'.msg']),'generated MSG source hash mismatch')
 for n in ['sequence','state_sequence','command_sequence']:
  if n in row['fixture']:need(row['fixture'][n]>2**53,'uint64 fixture notlarge')
 faults=json.loads((base/'engineering/generated_checker_faults.json').read_text());need(faults['passed'] and len(faults['cases'])==4,'CDR fault evidence incomplete')
for name,domain,count in [('vision',220,7),('velocity',221,11)]:
 d=json.loads((base/'ros'/f'{name}.report.json').read_text());need(d['passed'] and d.get('domain_id')==domain and d['localhost_only'] and len(d['checks'])==count,'communication report mismatch '+name)
 need(d==v['checks'][name+'_communication']['report'],'communication verification mismatch '+name)
 for phase in ['preflight','postflight']:
  d=json.loads((base/'ros'/f'{name}.domain_{phase}.json').read_text());need(d['passed'] and d['domain_id']==domain and all(x.startswith('fc01_isolated_graph_preflight_') for x in d['nodes']),'domain graph evidence mismatch')
checks['ROS_CDR']={'new_prefix':str(prefix),'generated_messages':5,'all_identity_and_file_hashes_match':True,'communication_domains':[220,221],'communication_checks':[7,11],'only_checker_smoke_manifest_drift_disclosed':True,'initial_checker_failures_retained':(base/'ros/generated_interfaces.report.json').exists() and (base/'ros/generated_interfaces_retry.report.json').exists()}
# Archive is an immutable snapshot for this review; root may append final reviews afterward.
ix=json.loads((p/'evidence_index.json').read_text());data=(p/'evidence.zip').read_bytes();need(sha(data)==ix['archive_sha256'] and len(data)==ix['archive_bytes'],'archive overall metadata mismatch')
with zipfile.ZipFile(io.BytesIO(data)) as z:
 names=z.namelist();need(len(names)==len(set(names))==ix['member_count'] and set(names)=={x['path'] for x in ix['members']},'archive member set mismatch');need(z.testzip() is None,'archive CRC failure')
 for row in ix['members']:
  value=z.read(row['path']);need(len(value)==row['bytes'] and sha(value)==row['sha256'],'archive member hash mismatch '+row['path'])
  original=base/row['path'];need(original.is_file() and original.read_bytes()==value,'archive member differs from cache '+row['path'])
 need(all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names),'unsafe archive member path')
checks['archive_snapshot']={'members':ix['member_count'],'sha256':sha(data),'all_crc_member_size_hashes_and_cache_snapshots_verified':True}
links=[]
for name in ['README_zh.md','VISION_HANDOFF_zh.md']:
 text=(p/name).read_text()
 for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
  if '://' not in target and not target.startswith('#'):
   need((p/target.split('#')[0]).exists(),'broken Markdown link '+name+': '+target);links.append(target)
checks['Markdown_links']=links
need(not git('rev-list','--merges',baseline+'..'+source).strip(),'unexpected merge')
for row in v['other_local_and_tracking_refs']:
 need(row['before']==row['after']==git('rev-parse',row['ref']).decode().strip(),'preserved ref mismatch '+row['ref'])
checks['scope']={'readonly_review_no_tests_or_ROS':True,'native_Python_41_not_claimed_rerun':True,'packaging_blocker_preserved':True,'hardware_ARM64_not_claimed_passed':True,'quality_candidate_production_reachability_not_claimed':True}
result={'reviewer':'overnight_support','baseline':baseline,'source_commit':source,'audited_files_sha256':{f.name:sha(f.read_bytes()) for f in p.iterdir() if f.is_file()},'checks':checks,'blocking_findings':issues,'passed':not issues,'limits':['Existing evidence and source/install bytes reviewed only; no tests, ROS, build or live graph queries rerun.','Quality API candidate production scheduling reachability remains unproved as disclosed.','Three existing packaging errors remain, not a new installer acceptance.','Root may append review evidence and make disclosed wording edits after this archive/document snapshot.']}
out=base/'engineering/final_delivery_review.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'output':str(out),'passed':not issues,'blocking_findings':issues,'changed_files':len(changed),'archive':checks['archive_snapshot']},ensure_ascii=False,indent=2))
