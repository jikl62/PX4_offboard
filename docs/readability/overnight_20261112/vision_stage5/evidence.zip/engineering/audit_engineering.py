from pathlib import Path
import ast,hashlib,json,re,subprocess,time,xml.etree.ElementTree as ET
import yaml
root=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
cache=Path('/home/jikl62/.cache/fc01-vision-stage5-20261112-een8twou/engineering')
ref=subprocess.check_output(['git','rev-parse','68b3221'],cwd=root,text=True).strip()
package=root/'native/src/jikl_fc01_system'; previous=Path('/home/jikl62/.cache/fc01-interfaces-stage3-irwed8ap/ros')
issues=[]
def need(v,m):
 if not v:issues.append(m)
def sha(v):return hashlib.sha256(v).hexdigest()
def before(p):return subprocess.check_output(['git','show',ref+':'+str(p.relative_to(root))],cwd=root)
def without_line_comments(data,prefix):return b'\n'.join(line for line in data.splitlines() if not line.lstrip().startswith(prefix))
modified=[package/'CMakeLists.txt',package/'package.xml',root/'navigation_environment.sh']
rows=[]
for p in modified:
 a,b=before(p),p.read_bytes(); prefix=b'<!--' if p.name=='package.xml' else b'#'
 eq=without_line_comments(a,prefix)==without_line_comments(b,prefix)
 need(eq,'noncomment bytes differ: '+str(p))
 rows.append({'path':str(p.relative_to(root)),'decision':'comment_only','before_sha256':sha(a),'sha256':sha(b),'bytes_without_full_line_comments_equal':eq})
config_sources=[package/'include/jikl_fc01_system/attitude_ros_parameters.hpp',package/'include/jikl_fc01_system/ros_config.hpp',package/'src/fc01_system_node.cpp']
text='\n'.join(p.read_text() for p in config_sources)
parameters={name:typ for typ,name in re.findall(r'declare_parameter<([^>]+)>\(\s*"([^"]+)"',text)}
for name in re.findall(r'\{"([^"]+)", &',config_sources[0].read_text()):parameters[name]='double'
parameters['use_sim_time']='bool'; yamlrows=[]
for p in sorted((root/'native/config').rglob('*.yaml')):
 data=p.read_bytes(); d=yaml.safe_load(data)['fc01_system']['ros__parameters']; duplicates=[]
 composed=yaml.compose(data); node=dict(composed.value)[next(k for k,v in composed.value if k.value=='fc01_system')]
 paramnode=next(v for k,v in node.value if k.value=='ros__parameters'); seen={}
 for k,v in paramnode.value:
  if k.value in seen:duplicates.append({'name':k.value,'line_1based':k.start_mark.line+1,'prior_line_1based':seen[k.value][0],'equal_scalar_text_and_yaml_type':(v.value,v.tag)==seen[k.value][1]})
  seen[k.value]=(k.start_mark.line+1,(v.value,v.tag))
 invalid=[]
 for n,v in d.items():
  typ=parameters.get(n)
  valid=typ is not None
  if typ=='bool': valid=type(v) is bool
  elif typ=='double':valid=type(v) in [int,float]
  elif typ=='std::string':valid=type(v) is str
  elif typ=='std::int64_t':valid=type(v) is int
  if not valid:invalid.append({'name':n,'cpp_type':typ,'yaml_type':type(v).__name__})
 need(not invalid,str(p)+' parameter-name/type mismatch')
 same=data==before(p); need(same,str(p)+' YAML changed')
 visual=d.get('visual_navigation_enabled',False); need(visual is False,str(p)+' visual enabled')
 yamlrows.append({'path':str(p.relative_to(root)),'sha256':sha(data),'source_bytes_unchanged':same,'parameter_count':len(d),'invalid_names_or_types':invalid,'visual_navigation_enabled':visual,'visual_uses_cpp_false_default':'visual_navigation_enabled' not in d,'duplicates':duplicates})
need('node.declare_parameter<bool>("visual_navigation_enabled", false)' in text,'C++ visual false default changed')
shells=sorted(list(root.glob('*.sh'))+list((root/'native/scripts').glob('*.sh'))); shellrows=[]
for p in shells:
 r=subprocess.run(['bash','-n',str(p)],capture_output=True,text=True); need(r.returncode==0,'bash syntax failure '+str(p))
 a,b=before(p),p.read_bytes(); shellrows.append({'path':str(p.relative_to(root)),'sha256':sha(b),'bash_n_exit':r.returncode,'syntax_stderr':r.stderr,'noncomment_bytes_unchanged':without_line_comments(a,b'#')==without_line_comments(b,b'#'),'source_bytes_unchanged':a==b})
cache_text=(previous/'build/jikl_fc01_system/CMakeCache.txt').read_text(); prefix=previous/'install/jikl_fc01_system'
artifact_names=['lib/jikl_fc01_system/vision_odometry_adapter.py','lib/jikl_fc01_system/velocity_command_diagnostic.py','lib/jikl_fc01_system/vision_state_validation.py','lib/jikl_fc01_system/vision_resource_budget.py','lib/libjikl_fc01_system__rosidl_typesupport_cpp.so','lib/libjikl_fc01_system__rosidl_typesupport_c.so','lib/libjikl_fc01_system__rosidl_generator_py.so','lib/jikl_fc01_system/fc01_system_node','share/jikl_fc01_system/package.xml']
message_names={'VisionState':'vision_state','VisionHealth':'vision_health','VelocityCommand':'velocity_command','NavigationCommand':'navigation_command','AttitudeThrustPreview':'attitude_thrust_preview'}
for name,snake in message_names.items():artifact_names.extend(['local/lib/python3.10/dist-packages/jikl_fc01_system/msg/_'+snake+'.py','share/jikl_fc01_system/msg/'+name+'.msg'])
artifactrows=[]
for n in artifact_names:
 p=prefix/n; exists=p.is_file(); need(exists,'previous installation missing '+n)
 artifactrows.append({'path':str(p),'exists':exists,'sha256':sha(p.read_bytes()) if exists else None,'executable':bool(p.stat().st_mode&0o111) if exists else None})
readelf=subprocess.run(['readelf','-d',str(prefix/'lib/jikl_fc01_system/fc01_system_node')],capture_output=True,text=True); (cache/'previous_node.readelf.log').write_text(readelf.stdout+readelf.stderr)
need(readelf.returncode==0,'old installed node readelf failed'); need('$ORIGIN' in readelf.stdout,'old installed node missing relative RPATH'); need('libjikl_fc01_system__rosidl_typesupport_cpp.so' in readelf.stdout,'old installed node typesupport absent')
checks={'CMake_HOME_matches_current_source':'CMAKE_HOME_DIRECTORY:INTERNAL='+str(package) in cache_text,'px4_msgs_underlay':'/home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs','installed_prefix':str(prefix),'readelf_exit':readelf.returncode,'artifacts':artifactrows,'scope':'Existing Stage3 x86_64 cache only, not a new build or final Stage5 installation identity; root will build and smoke separately.'}
need(checks['CMake_HOME_matches_current_source'],'old build cache source directory differs')
contract={'package':'jikl_fc01_system','message_names':list(message_names),'native_visual_gate_default':False,'native_visual_QoS':{'depth':5,'state':'BEST_EFFORT VOLATILE','navigation_command':'RELIABLE VOLATILE','created_only_if_visual_enabled':True},'adapter_QoS':{'depth':5,'odometry':'BEST_EFFORT VOLATILE','health':'RELIABLE VOLATILE','output':'BEST_EFFORT VOLATILE'},'velocity_diagnostic_QoS':{'depth':5,'subscription':'BEST_EFFORT VOLATILE','publishers':False},'topics':{'adapter_output':'/fc01/vision/state','native_navigation_command':'/fc01/navigation/command','velocity_diagnostic':'/fc01/vision/velocity_command'},'parameter_boundary':'Native fc01_system parameters do not configure the independent fc01_vision_odometry_adapter or fc01_velocity_command_diagnostic nodes. Each tool declares its own startup-only ROS parameters.'}
for path in ['native/scripts/install.sh','native/scripts/r632_build.sh','native/scripts/run.sh','navigation_environment.sh','navigation_build_fresh.sh','navigation_boot.sh','navigation_restore.sh','navigation.sh','standby.sh','start.sh']:
 p=root/path; rows.append({'path':path,'decision':'review_environment_or_layout','sha256':sha(p.read_bytes()),'reason':'Reviewed environment ordering, installation layout or thin entry responsibilities; none executed.'})
result={'baseline':ref,'phase':'queue5 engineering static review','modified_files':rows[:3],'reviewed_environment_entries':rows[3:],'yaml':yamlrows,'shell_syntax_and_protection':shellrows,'parameter_source_sha256':{str(p.relative_to(root)):sha(p.read_bytes()) for p in config_sources},'contract':contract,'prior_Humble_cache_readonly_identity':checks,'issues':issues,'passed':not issues,'no_ros_no_build':True,'unresolved':[{'severity':'P3 structural debt','issue':'diagnostic.yaml and flight_test.yaml retain duplicate rc_navigation_enabled and visual_navigation_enabled with identical false values; retained exact bytes to avoid YAML contract changes.'},{'severity':'evidence limit','issue':'Application identity checks do not constrain DDS deserialization allocation; real ROS smoke and installed final identities are root responsibilities.'}]}
(cache/'static_review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':not issues,'issues':issues,'modified_comment_files':len(rows[:3]),'YAML_files':len(yamlrows),'all_YAML_bytes_unchanged':all(x['source_bytes_unchanged'] for x in yamlrows),'shells_syntax_checked':len(shellrows),'prior_install_artifacts_checked':len(artifactrows),'duplicate_keys':[{'path':x['path'],'duplicates':x['duplicates']} for x in yamlrows if x['duplicates']]},ensure_ascii=False,indent=2))
