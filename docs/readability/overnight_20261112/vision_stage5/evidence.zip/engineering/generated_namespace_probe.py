import importlib,json
from pathlib import Path
from rosidl_runtime_py.utilities import get_message
rows=[]
for name in ['VisionState','NavigationCommand','VelocityCommand','VisionHealth','AttitudeThrustPreview']:
    cls=get_message('jikl_fc01_system/msg/'+name)
    namespace={key:{'type':type(value).__name__,'repr':repr(value)[:150]} for key,value in vars(cls).items() if key.isupper()}
    rows.append({'name':name,'module':importlib.import_module(cls.__module__).__file__,'uppercase_namespace':namespace})
Path('/home/jikl62/.cache/fc01-vision-stage5-20261112-een8twou/engineering/generated_namespace.json').write_text(json.dumps({'rows':rows,'ros_init_called':False,'nodes_created':False},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(rows,ensure_ascii=False,indent=2))
