import hashlib,json,zipfile
from pathlib import Path
C=Path(__file__).resolve().parent
output=C/'evidence.zip'
selected={}
# Recompress all full raw behavior traces; this retains both baseline and current, including unequal diagnostic-only full logs.
with zipfile.ZipFile(C/'behavior/behavior_evidence.zip') as z:
    for info in z.infolist():selected['behavior/'+info.filename]=z.read(info)
# Explicit acceptance evidence only; never add build/install/cache binaries recursively.
for folder in ('root','static','readability'):
    for p in (C/folder).iterdir():
        if p.is_file() and p.suffix in ('.py','.json','.log','.md','.tsv','.cpp'):
            selected[folder+'/'+p.name]=p.read_bytes()
for p in (C/'ros').iterdir():
    if p.is_file() and p.suffix in ('.py','.json','.log','.md','.sh'):
        selected['ros/'+p.name]=p.read_bytes()
for n in ('initial.json','run_tests.py','archive_final_evidence.py','assemble_final_delivery.py','validate_final_delivery.py'):
    if (C/n).is_file():selected[n]=(C/n).read_bytes()
R=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028/docs/readability/overnight_20261112')
for src,dest in [('FINAL_REPORT_zh.md','delivery/FINAL_REPORT_zh.md'),('final_stage7/verification.json','delivery/verification.json')]:
    selected[dest]=(R/src).read_bytes()
# Keep each large byte-identical raw trace once. Aliases bind every original logical path to the same verified bytes.
# The original undeduplicated archive remains in cache; this is lossless content preservation, not output filtering.
aliases=[]
seen={}
for n,b in sorted(list(selected.items())):
    if len(b)<1024:
        continue
    h=hashlib.sha256(b).hexdigest()
    if h in seen:
        aliases.append({'logical_path':n,'content_path':seen[h],'bytes':len(b),'sha256':h})
        del selected[n]
    else:
        seen[h]=n
selected['CONTENT_ALIASES.json']=(json.dumps({'purpose':'Byte-identical raw trace content is stored once; copy content_path to logical_path to reconstruct every original path. No trace fields removed.','aliases':aliases},indent=2)+'\n').encode()
# Full pre/post state belongs to this archive, not a promise about future hardware state.
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_LZMA) as z:
    for n,b in sorted(selected.items()):z.writestr(n,b)
index={'archive':'evidence.zip','archive_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'archive_bytes':output.stat().st_size,'compression':'ZIP_LZMA','cache_origin':str(C),'member_count':len(selected),'uncompressed_bytes':sum(map(len,selected.values())),'logical_content_aliases':aliases,'members':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(selected.items())]}
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256'] for x in index['members'])
for row in aliases:
    assert hashlib.sha256(selected[row['content_path']]).hexdigest()==row['sha256']
index['crc_and_every_member_sha256_verified']=True
(C/'evidence_index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in index.items() if k not in ('members','logical_content_aliases')}))
