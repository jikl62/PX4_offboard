from pathlib import Path
import json
import os
import sys
import time
import rclpy
from rclpy.node import Node

domain = int(os.environ['ROS_DOMAIN_ID'])
assert domain in (223, 224, 225) and os.environ['ROS_LOCALHOST_ONLY'] == '1'
rclpy.init(args=[])
name = 'fc01_isolated_graph_preflight_' + str(domain)
node = Node(name)
try:
    deadline = time.monotonic() + 1.5
    while time.monotonic() < deadline:
        rclpy.spin_once(node, timeout_sec=0.1)
    nodes = node.get_node_names()
    topics = node.get_topic_names_and_types()
    result = {'domain_id': domain, 'localhost_only': True, 'nodes': nodes, 'topics': topics}
    result['passed'] = all(item == name for item in nodes) and not any(topic.startswith('/fmu/') for topic, _ in topics)
    Path(sys.argv[1]).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
    if not result['passed']:
        raise RuntimeError('Selected local domain is already occupied; no synthetic traffic sent')
finally:
    node.destroy_node()
    if rclpy.ok():
        rclpy.shutdown()
