import json,subprocess,sys,time
from pathlib import Path
cache=Path(__file__).resolve().parent
name=sys.argv[1]
argv=['bash',str(cache/(name+'.command.sh'))]
start=time.monotonic()
with (cache/(name+'.log')).open('wb') as log:
 result=subprocess.run(argv,cwd='/home/jikl62/FC01_OrangePi_Navigation_20261028',stdout=log,stderr=subprocess.STDOUT)
row={'argv':argv,'returncode':result.returncode,'seconds':time.monotonic()-start,'log':str(cache/(name+'.log'))}
(cache/(name+'.result.json')).write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row))
raise SystemExit(result.returncode)
