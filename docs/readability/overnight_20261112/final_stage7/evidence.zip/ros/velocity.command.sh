set -eo pipefail
unset AMENT_PREFIX_PATH CMAKE_PREFIX_PATH COLCON_PREFIX_PATH PYTHONPATH LD_LIBRARY_PATH PKG_CONFIG_PATH
source /opt/ros/humble/setup.bash
source /home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs/share/px4_msgs/local_setup.bash
source /home/jikl62/.cache/fc01-final-stage7-20261112-r2tfb_gb/ros/install/setup.bash
export PYTHONDONTWRITEBYTECODE=1
export ROS_LOCALHOST_ONLY=1
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
unset ROS_DISCOVERY_SERVER CYCLONEDDS_URI FASTRTPS_DEFAULT_PROFILES_FILE FASTDDS_DEFAULT_PROFILES_FILE RMW_FASTRTPS_USE_QOS_FROM_XML ROS_STATIC_PEERS
export ROS_DOMAIN_ID=224
/usr/bin/python3 /home/jikl62/.cache/fc01-final-stage7-20261112-r2tfb_gb/ros/preflight_domain.py /home/jikl62/.cache/fc01-final-stage7-20261112-r2tfb_gb/ros/velocity.domain_preflight.json
/usr/bin/python3 /home/jikl62/FC01_OrangePi_Navigation_20261028/tests/ros_velocity_command_smoke.py --diagnostic /home/jikl62/.cache/fc01-final-stage7-20261112-r2tfb_gb/ros/install/jikl_fc01_system/lib/jikl_fc01_system/velocity_command_diagnostic.py --report /home/jikl62/.cache/fc01-final-stage7-20261112-r2tfb_gb/ros/velocity.report.json
/usr/bin/python3 /home/jikl62/.cache/fc01-final-stage7-20261112-r2tfb_gb/ros/preflight_domain.py /home/jikl62/.cache/fc01-final-stage7-20261112-r2tfb_gb/ros/velocity.domain_postflight.json
