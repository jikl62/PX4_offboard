#!/usr/bin/env python3
"""Independent report/evidence consistency check; reads results only, does not rerun tests."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
CACHE=Path('/home/jikl62/.cache/fc01-final-stage7-20261112-r2tfb_gb')
REPORT=ROOT/'docs/readability/overnight_20261112/FINAL_REPORT_zh.md'
VERIFY=ROOT/'docs/readability/overnight_20261112/final_stage7/verification.json'
body=REPORT.read_text();v=json.loads(VERIFY.read_text())
d=json.loads((CACHE/'behavior/differential_summary.json').read_text())
s=json.loads((CACHE/'behavior/sanitizers/summary.json').read_text())
c=json.loads((CACHE/'behavior/control_structure.json').read_text())
powered=json.loads((CACHE/'behavior/traces/powered-node.json').read_text())
node=json.loads((CACHE/'behavior/traces/node.json').read_text())
checks=[]
def require(name, ok, evidence):
 checks.append({'name':name,'passed':bool(ok),'evidence':evidence})
require('actual_overnight_baseline',v['overnight_start']==d['baseline']==c['baseline']=='5b86eeb4094ada009903c0140f66289cfe89411e', 'BASELINE.json plus fresh separately compiled traces')
require('accepted_source_head',v['source_accepted_head']==d['head']==c['head']==s['head']=='4c3c360941575049ebac78dbbf4ce58f098d93b6','All fresh source identities agree')
require('seven_trace_methods_exact_and_no_skips',v['fresh_night_baseline_differential']==d and d['testsRun']==7 and d['successful'] and not(d['errors'] or d['failures'] or d['skipped']), 'verification stores original differential summary byte-equivalent JSON values')
for row in d['manifest']:
 path=CACHE/'behavior/traces'/row['path']
 require('trace_sha_'+row['path'],path.stat().st_size==row['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],'Retained original file bytes/SHA')
require('707_is_one_complete_synthetic_task_then_READY',powered['state_samples']==707 and '一次起飞' in body and '不是两次完整飞行验证' in body,'powered-node.json and unchanged production fake-node driver assertions')
require('1350_separate_nine_scenarios',node['state_samples']==1350 and '**1,350 个状态样本**' in body and '另 9 场景' in body,'node.json; 9 scenarios x150 cycles')
require('publication_order_counts',powered['sink_order_counts']=={'TARGET,HEARTBEAT':587,'TARGET,HEARTBEAT,COMMAND':1} and '587 次 TARGET→HEARTBEAT' in body,'Original powered sink trace aggregation')
require('all_60_production_structure_items_equal',len(c['files'])==60 and c['all_equal'] and c['profile_equal'] and c['counts_by_kind']['cpp_raw_tokens']==38 and c['profile_source']=='native/config/flight_test.yaml','Original per-file token/literal/preprocessor/config/MSG comparison')
require('ASanUBSan_9x3_not_added_to82',v['asan_ubsan']['programs']==len(s['tests'])==9 and v['asan_ubsan']['runs_per_program']==3 and s['successful'] and sum(len(t['runs']) for t in s['tests'])==27 and all(t['build_exit']==0 and all(r['exit']==0 for r in t['runs']) for t in s['tests']) and '与普通 82 个程序分开' in body,'Nine fresh assertion-enabled sanitizer programs, three executions each, explicit separate denominator')
for key,filename in [('python_root','python_root.json'),('python_native','python_native.json')]:
 orig=json.loads((CACHE/'root'/filename).read_text())
 require(key+'_matches_raw_summary',v[key]==orig,'Original root runner JSON and full log retained')
require('676_method_executions_673_pass_3_errors',v['python_total']=={'method_executions':676,'passed':673,'errors':3,'failed':0,'skipped':0},'635/632/3 root plus41/41 native; C++/ROS/sanitizer not added')
require('C1_not_resolved_by_normal_trace', 'C1 的异常输入反例仍成立' in body and '生产未修' in body and '没有复现自动解锁或非零推力' in body,'Actual C1 stage6 source evidence; production C++ unchanged')
require('all_C1_C4_candidates_not_integrated',v['candidates']['applied'] is False and v['candidates']['fresh_candidate_tests_in_stage7'] is False and v['candidates']['C2_final_candidate_burst_tested'] is False,'Stage6 candidate_index and current final report agree; no fresh candidate test falsely claimed')
require('finite_fake_sinks_no_proof_or_PX4_adoption_claim','有限离线输入' in body and '没有真实电机或 PX4' in body and '不证明飞控收到并采用' in body and 'No mathematical safety proof; finite synthetic traces and fake sinks.' in v['remaining_limits'],'No extension from local sink success to flight safety/adoption')
require('protective_faults_retained','CONTROL_LOOP_STALL` 拒绝过期计划' in body and '部分发布和最终上下文改变仍是合理保护' in body,'Core elapsed guard and final publish resampling still present')
require('git_overnight_history_intact',int(subprocess.check_output(['git','rev-list','--count',v['overnight_start']+'..'+v['source_accepted_head']],cwd=ROOT))==23 and not subprocess.check_output(['git','rev-list','--merges',v['overnight_start']+'..'+v['source_accepted_head']],cwd=ROOT).strip(),'Read-only current Git ancestry/count, no merges')
findings=[]
old='`VERTICAL_VELOCITY_INCONSISTENT` 目前是诊断差值'
if old in body:
 findings.append({'severity':'P3 documentation precision','line':next(i for i,l in enumerate(body.splitlines(),1) if old in l),'required_change':'Clarify that vz-z_deriv is diagnostic-only; the old VERTICAL_VELOCITY_INCONSISTENT string appears only in historical recoverable-reason enumeration, not current emitted warning/rejection.','source':'rg in native/src/jikl_fc01_system found only attitude_altitude_core.hpp:2227; VerticalFeedbackGuard emits rate_warning rather than this reason.'})
pending=[str(p.relative_to(ROOT)) for p in [VERIFY.parent/'evidence.zip',VERIFY.parent/'evidence_index.json',VERIFY.parent/'final_payload_audit.json'] if not p.exists()]
result={'reviewer':'independent final_behavior agent','scope':'Behavior/baseline/test/candidate report consistency; no tests rerun or production/report edits',
 'report_sha256':hashlib.sha256(REPORT.read_bytes()).hexdigest(),'verification_sha256':hashlib.sha256(VERIFY.read_bytes()).hexdigest(),
 'checks':checks,'all_evidence_checks_passed':all(x['passed'] for x in checks),'required_documentation_fixes':findings,
 'pending_final_archive_artifacts':pending,'meaning':'All checked substantive control/evidence claims match. Finish archive artifacts before commit; one wording precision correction requested if still present.'}
(CACHE/'root/final_behavior_cross_review.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'checks':len(checks),'all_passed':result['all_evidence_checks_passed'],'required_fixes':findings,'pending_final_artifacts':pending},ensure_ascii=False,indent=2))
