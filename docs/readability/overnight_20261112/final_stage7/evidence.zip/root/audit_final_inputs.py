import hashlib, importlib.util, json, subprocess, time, zipfile
from pathlib import Path
ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
CACHE=Path(__file__).resolve().parent
BASE='5b86eeb4094ada009903c0140f66289cfe89411e'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def sha(blob):return hashlib.sha256(blob).hexdigest()
initial=json.loads((CACHE.parent/'initial.json').read_text())
base=json.loads((ROOT/'docs/readability/overnight_20261112/BASELINE.json').read_text())
refs={line.split(' ',1)[1]:line.split(' ',1)[0] for line in git('show-ref').splitlines()}
refrows=[]
for line in base['initial_refs']:
    value,name=line.split(' ',1)
    if name.startswith(('refs/heads/','refs/remotes/')) and name!='refs/heads/readability/fc01-chinese-20261111':
        refrows.append({'ref':name,'before':value,'now':refs.get(name),'unchanged':refs.get(name)==value})
changes=[]
for line in git('diff','--name-status',BASE,'HEAD').splitlines():
    status,path=line.split('\t',1)
    blob=(ROOT/path).read_bytes()
    changes.append({'path':path,'status':status,'sha256':sha(blob),'bytes':len(blob),'category':'report/evidence' if path.startswith('docs/') else ('test' if path.startswith(('tests/','native/tests/')) else 'production/tool/interface'),'touching_commits':git('log','--format=%H',BASE+'..HEAD','--',path).splitlines()})
commits=[]
for line in git('log','--reverse','--format=%H%x09%s',BASE+'..HEAD').splitlines():
    value,subject=line.split('\t',1)
    commits.append({'commit':value,'subject':subject,'files':git('diff-tree','--no-commit-id','--name-only','-r',value).splitlines()})
preserved=[{'path':p,'before':s,'now':sha((ROOT/p).read_bytes()),'unchanged':sha((ROOT/p).read_bytes())==s} for p,s in initial['sha256'].items()]
phasearchives=[]
for p in sorted((ROOT/'docs/readability/overnight_20261112').rglob('*.zip')):
    row={'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
    with zipfile.ZipFile(p) as z:
        row.update(member_count=len(z.infolist()),crc_error=z.testzip())
        idx=p.parent/'evidence_index.json'
        if idx.exists():
            index=json.loads(idx.read_text())
            row['archive_sha_matches_index']=index.get('archive_sha256',index.get('sha256'))==row['sha256']
            row['all_indexed_members_match']=all(sha(z.read(e.get('path',e.get('archive_path'))))==e['sha256'] and len(z.read(e.get('path',e.get('archive_path'))))==e['bytes'] for e in index.get('members',index.get('entries',[])))
    phasearchives.append(row)
# Reproduce the builder's collection predicate without calling extraction, installation or generating files.
spec=importlib.util.spec_from_file_location('fc01_pack_readonly',ROOT/'build_navigation_bundle.py')
pack=importlib.util.module_from_spec(spec);spec.loader.exec_module(pack)
files=[p for p in ROOT.iterdir() if p.is_file() and p.suffix in ('.py','.sh','.md','.json') and p.name not in pack.RUNTIME_FILES]
files.extend(p for directory in ('native','tests','docs') for p in (ROOT/directory).rglob('*') if p.is_file() and not(set(p.relative_to(ROOT).parts)&pack.CACHE_PARTS) and not p.is_relative_to(ROOT/'native/tests/ros_receive_ab'))
payload=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'symlink':p.is_symlink()} for p in sorted(files)]
try: pack.names(ROOT)
except Exception as exc: package_result={'error_type':type(exc).__name__,'error':str(exc)}
else: package_result={'unexpected_pass':True}
package_result.update(files_without_manifest=len(payload),files_with_manifest=len(payload)+1,bytes_without_manifest=sum(r['bytes'] for r in payload),file_limit=pack.MAX_FILES,byte_limit=pack.MAX_BYTES,oversized_members=[r for r in payload if r['bytes']>1048576],manifest_preserved=(ROOT/pack.MANIFEST).read_bytes()==subprocess.check_output(['git','show',BASE+':'+pack.MANIFEST],cwd=ROOT),payload=payload)
(CACHE/'packaging.json').write_text(json.dumps(package_result,indent=2)+'\n')
(CACHE/'changes_and_history.json').write_text(json.dumps({'baseline':BASE,'source_head':git('rev-parse','HEAD'),'commits':commits,'files':changes},ensure_ascii=False,indent=2)+'\n')
result={'baseline':BASE,'source_head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'initial_status':initial['status'],'status_after_tests':git('status','--porcelain=v1'),'baseline_is_ancestor':subprocess.run(['git','merge-base','--is-ancestor',BASE,'HEAD'],cwd=ROOT).returncode==0,'merge_commits':git('rev-list','--merges',BASE+'..HEAD').splitlines(),'protected_refs':refrows,'all_protected_refs_unchanged':all(x['unchanged'] for x in refrows),'tracked_source_identity':preserved,'all_initial_tracked_files_unchanged':all(x['unchanged'] for x in preserved),'phase_archives':phasearchives,'changes_count':len(changes),'changes_by_category':{c:sum(x['category']==c for x in changes) for c in sorted({x['category'] for x in changes})},'commit_count':len(commits),'source_packaging_summary':{k:v for k,v in package_result.items() if k!='payload'},'prohibitions':'This stage did not invoke push/fetch/merge/rebase, production controller, Agent, service management, deployer, extraction, UART or hardware. Local reference verification is not a live remote query.'}
(CACHE/'git_integrity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('tracked_source_identity','protected_refs')},ensure_ascii=False))
