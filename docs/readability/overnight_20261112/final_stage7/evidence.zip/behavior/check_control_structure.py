#!/usr/bin/env python3
"""Read-only production token/protocol/config comparison against actual overnight baseline."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
OUT = Path(__file__).resolve().parent
BASELINE = '5b86eeb4094ada009903c0140f66289cfe89411e'
sys.path[:0] = [str(ROOT/'tests'), str(ROOT)]
import readability_equivalence as eq
import yaml
import navigation_service
clang = shutil.which('clang++')
paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
selected = []
for path in paths:
    if path.startswith('native/src/jikl_fc01_system/'):
        suffix = Path(path).suffix
        if suffix in eq.CPP_SUFFIXES:
            selected.append((path, 'cpp_raw_tokens'))
        elif suffix == '.msg':
            selected.append((path, 'ros_message_declarations'))
        elif path.endswith('CMakeLists.txt'):
            selected.append((path, 'cmake_execution_tokens'))
        elif path.endswith('package.xml'):
            selected.append((path, 'package_xml_semantics'))
    elif path.startswith('native/config/'):
        selected.append((path, 'yaml_typed_values' if path.endswith(('.yaml','.yml')) else 'protected_bytes'))
    elif path in ('navigation_settings.json', 'vision_settings.json'):
        selected.append((path, 'protected_bytes'))
    elif path.startswith('native/tools/') and Path(path).suffix in eq.CPP_SUFFIXES:
        selected.append((path, 'cpp_raw_tokens'))

def check(item):
    path, kind = item
    before = subprocess.check_output(['git', 'show', BASELINE + ':' + path], cwd=ROOT)
    after = (ROOT/path).read_bytes()
    a, b = eq.structure(kind, before, clang), eq.structure(kind, after, clang)
    return {'path': path, 'kind': kind, 'before_sha256': hashlib.sha256(before).hexdigest(),
            'after_sha256': hashlib.sha256(after).hexdigest(), 'byte_equal': before == after,
            'structure_equal': a == b, 'structure_items': len(b) if hasattr(b,'__len__') else None}

started = time.monotonic()
with ThreadPoolExecutor(max_workers=2) as pool:
    rows = list(pool.map(check, selected))
base = json.loads((ROOT/'docs/readability/overnight_20261112/BASELINE.json').read_text())
settings = json.loads((ROOT/'navigation_settings.json').read_text())
profile_source = navigation_service.candidate_config_path(navigation_service.FLIGHT_TEST, ROOT)
profile = navigation_service.navigation_profile(yaml.safe_load(profile_source.read_text()),
    settings['target_height_m'],settings['navigation_mode_slot'])['fc01_system']['ros__parameters']
protected_profile = {key: profile[key] for key in base['configured_navigation_profile']}
profile_equal = protected_profile == base['configured_navigation_profile']
from collections import Counter
summary = {'baseline': BASELINE, 'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'elapsed_seconds':time.monotonic()-started, 'files': rows, 'counts_by_kind':dict(Counter(r['kind'] for r in rows)),
 'all_equal':all(r['structure_equal'] for r in rows), 'profile_equal':profile_equal,
 'configured_navigation_profile':protected_profile, 'profile_source':profile_source.relative_to(ROOT).as_posix(),
 'scope':'Complete tracked production C++ tree plus authored C++ tools, five MSG declarations, package generation and all tracked native/config files. Raw Clang token/literal/preprocessor equality excludes debug source-line changes.'}
(OUT/'control_structure.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='files'},ensure_ascii=False,indent=2))
raise SystemExit(not (summary['all_equal'] and profile_equal))
