#!/usr/bin/env python3
"""Fresh assert-enabled GCC ASan+UBSan tests of current production headers; no ROS/hardware."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
OUT=Path(__file__).resolve().parent/'sanitizers'
OUT.mkdir(exist_ok=True)
NAMES=['test_rc_navigation','test_rc_timing_recovery','test_rc_recovery_progress',
 'test_vertical_feedback_guard','test_offline_timing','test_stage3_publication_combinations',
 'test_stage3_state_invariants','test_overnight_stage6_ipc','test_stage3_async_log_resources']

def run(name):
    source=ROOT/'native/tests'/(name+'.cpp')
    binary=OUT/name
    cmd=['g++','-std=c++17','-Wall','-Wextra','-Werror','-pedantic','-pthread',
         '-fsanitize=address,undefined','-fno-omit-frame-pointer','-g','-fno-pie','-no-pie',
         '-I',str(ROOT/'native/src/jikl_fc01_system/include'),str(source),'-o',str(binary)]
    if name=='test_stage3_async_log_resources': cmd+=['-Wl,--wrap=fcntl','-Wl,--wrap=write','-ldl']
    started=time.monotonic()
    built=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=180)
    (OUT/(name+'.build.log')).write_text(built.stdout+built.stderr)
    row={'test':name,'command':cmd,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
         'build_exit':built.returncode,'build_seconds':time.monotonic()-started,'runs':[]}
    if built.returncode:return row
    for repeat in range(3):
        env=os.environ.copy(); env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        started=time.monotonic()
        execution=subprocess.run([str(binary)],cwd=OUT,capture_output=True,text=True,timeout=60,env=env)
        log=OUT/(name+f'.run{repeat+1}.log')
        log.write_text(execution.stdout+execution.stderr)
        row['runs'].append({'repeat':repeat+1,'exit':execution.returncode,'seconds':time.monotonic()-started,
                            'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
    return row

with ThreadPoolExecutor(max_workers=2) as pool: rows=list(pool.map(run,NAMES))
headers=[]
for path in sorted((ROOT/'native/src/jikl_fc01_system').rglob('*')):
    if path.is_file() and path.suffix in ('.cpp','.hpp'):
        headers.append({'path':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
result={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'compiler':subprocess.check_output(['g++','--version'],text=True), 'files':headers, 'tests':rows,
        'successful':all(r['build_exit']==0 and len(r['runs'])==3 and all(x['exit']==0 for x in r['runs']) for r in rows),
        'runtime_env':{'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'},
        'scope':'Nine meaningful fault/lifecycle/safety tests, three executions each, ASan+UBSan with leak detection. Non-PIE sanitizer binaries reduce host shadow-map conflicts; production flags unchanged.'}
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'successful':result['successful'],'tests':len(rows),'runs':sum(len(x['runs']) for x in rows)}))
raise SystemExit(not result['successful'])
