#!/usr/bin/env python3
"""Stage7: compile actual overnight baseline/current implementations with unchanged exact trace drivers."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest

ROOT = Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
OUT = Path(__file__).resolve().parent
BASELINE = '5b86eeb4094ada009903c0140f66289cfe89411e'
sys.path.insert(0, str(ROOT / 'tests'))
import test_stage3_control_equivalence as stage3
stage3.BASELINE = BASELINE
os.environ['FC01_STAGE3_TRACE_DIR'] = str(OUT / 'traces')
HEAD = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
started = time.monotonic()
loader = unittest.TestLoader()
suite = unittest.TestSuite([
    loader.loadTestsFromTestCase(stage3.Stage3CoreEquivalenceTests),
    loader.loadTestsFromTestCase(stage3.Stage3PoweredNodeEquivalenceTests),
])
result = unittest.TextTestRunner(verbosity=2).run(suite)
manifest = []
for file in sorted((OUT / 'traces').glob('*')):
    if file.is_file():
        manifest.append({'path': file.name, 'bytes': file.stat().st_size,
                         'sha256': hashlib.sha256(file.read_bytes()).hexdigest()})
summary = {
    'baseline': BASELINE, 'head': HEAD, 'seconds': time.monotonic() - started,
    'testsRun': result.testsRun, 'failures': len(result.failures),
    'errors': len(result.errors), 'skipped': result.skipped,
    'successful': result.wasSuccessful(), 'manifest': manifest,
    'scope': 'No hardware or actual ROS control node; fake sinks run actual production Core, Runtime and SystemNode.',
}
(OUT / 'differential_summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
sys.exit(not result.wasSuccessful())
