from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028');CACHE=Path(__file__).resolve().parent/'root'
name=sys.argv[1];argv=['python3','-m','unittest','discover','-s','tests' if name=='python_root' else 'native/tests','-v']
start=time.monotonic()
with (CACHE/(name+'.log')).open('wb') as log:r=subprocess.run(argv,cwd=ROOT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=log,stderr=subprocess.STDOUT)
raw=(CACHE/(name+'.log')).read_bytes();text=raw.decode('utf-8','backslashreplace');m=re.search(r'Ran (\d+) tests',text)
row={'argv':argv,'cwd':str(ROOT),'returncode':r.returncode,'seconds':time.monotonic()-start,'env_overrides':{'PYTHONDONTWRITEBYTECODE':'1'},'tests_run':int(m[1]) if m else None,'errors':re.findall(r'^ERROR: (.+)$',text,re.M),'failures':re.findall(r'^FAIL: (.+)$',text,re.M),'skips':re.findall(r'^.* \.\.\. skipped.*$',text,re.M),'log_sha256':hashlib.sha256(raw).hexdigest()}
if row['tests_run'] is not None:row['passed_methods']=row['tests_run']-len(row['errors'])-len(row['failures'])-len(row['skips'])
(CACHE/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row));sys.exit(r.returncode)
