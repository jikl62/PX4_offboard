import hashlib,importlib.util,json,re,subprocess,zipfile
from pathlib import Path
C=Path(__file__).resolve().parent
R=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
D=R/'docs/readability/overnight_20261112/final_stage7'
REPORT=D.parent/'FINAL_REPORT_zh.md'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
initial=json.loads((C/'initial.json').read_text())
assert git('rev-parse','HEAD')==initial['head']
assert all(sha((R/p).read_bytes())==h for p,h in initial['sha256'].items())
refs={row.split(' ',1)[1]:row.split(' ',1)[0] for row in git('show-ref').splitlines()}
protected=json.loads((C/'root/git_integrity.json').read_text())['protected_refs']
assert all(refs[x['ref']]==x['before'] for x in protected)
index=json.loads((D/'evidence_index.json').read_text())
assert sha((D/'evidence.zip').read_bytes())==index['archive_sha256']
with zipfile.ZipFile(D/'evidence.zip') as z:
    assert z.testzip() is None
    assert len(z.infolist())==index['member_count']
    for row in index['members']:
        b=z.read(row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256']
    for row in index.get('logical_content_aliases',[]):
        b=z.read(row['content_path']);assert len(b)==row['bytes'] and sha(b)==row['sha256']
    # Report only locations/counts on a suspected credential, never the matching text.
    patterns=[re.compile(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----'),re.compile(rb'(?<![A-Za-z0-9])gh[pousr]_[A-Za-z0-9]{30,}'),re.compile(rb'sk-proj-[A-Za-z0-9_-]{30,}')]
    suspected=[]
    for info in z.infolist():
        blob=z.read(info)
        for i,p in enumerate(patterns):
            if p.search(blob):suspected.append({'path':info.filename,'pattern':i})
    assert not suspected,suspected
pending_audit=D/'final_payload_audit.json'
if not pending_audit.exists():pending_audit.write_text('{}\n')
links=[]
for label,target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',REPORT.read_text()):
    if not target.startswith(('http:','https:','#')):
        path=(REPORT.parent/target.split('#',1)[0]).resolve()
        links.append({'target':target,'exists':path.exists()})
assert all(x['exists'] for x in links)
jsons=[]
for p in D.glob('*.json'):
    json.loads(p.read_text());jsons.append(p.name)
tsv=(D/'file_index.tsv').read_text().splitlines();assert len(tsv)==351
summary=json.loads((D/'verification.json').read_text())
assert summary['python_total']=={'method_executions':676,'passed':673,'errors':3,'failed':0,'skipped':0}
assert summary['asan_ubsan']['programs']==9 and summary['asan_ubsan']['successful']
assert summary['fresh_night_baseline_differential']['baseline']==initial['overnight_baseline']
assert summary['fresh_night_baseline_differential']['testsRun']==7 and summary['fresh_night_baseline_differential']['successful']
assert summary['fresh_ROS_Humble']['passed']
checks={'source_head':initial['head'],'report_sha256':sha(REPORT.read_bytes()),'initial_528_tracked_files_byte_identical':True,'protected_14_refs_unchanged':True,'report_local_links':links,'json_parsed':jsons,'tsv_candidates':len(tsv)-1,'archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes'],'archive_member_count':index['member_count'],'crc_and_all_member_sha_passed':True,'duplicate_text_content_alias_count':len(index.get('logical_content_aliases',[])),'aliases_content_sha_passed':True,'credential_pattern_scan':{'checked':'new acceptance ZIP only; raw keys/tokens are never printed','suspected_count':len(suspected),'limits':'Pattern check is not an exhaustive privacy guarantee.'},'test_counts_and_source_identity_cross_checks':True,'current_HEAD_frozen_during_acceptance':True,'candidate_application':False,'push_deploy_hardware':False,'review_artifacts':['root/final_behavior_cross_review.json','root/final_readability_cross_review.json','root/final_ros_cross_review.json','root/python_changes_independent_review.json'],'review_followup':'Root applied the reported wording corrections for TSV fields, C++ compression-rule scope and historical vertical diagnostic label; no production edits.'}
(D/'delivery_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
# Enumerate actual final disk using the same builder predicate. Include this audit's own bytes via a stable size fixpoint, without recursive self-hash.
spec=importlib.util.spec_from_file_location('pack_readonly',R/'build_navigation_bundle.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
audit=D/'final_payload_audit.json'
files=[q for q in R.iterdir() if q.is_file() and q.suffix in ('.py','.sh','.md','.json') and q.name not in p.RUNTIME_FILES]
files.extend(q for folder in ('native','tests','docs') for q in (R/folder).rglob('*') if q.is_file() and not(set(q.relative_to(R).parts)&p.CACHE_PARTS) and not q.is_relative_to(R/'native/tests/ros_receive_ab'))
files=[q for q in files if q!=audit]
rows=[{'path':str(q.relative_to(R)),'bytes':q.stat().st_size,'sha256':sha(q.read_bytes()),'symlink':q.is_symlink()} for q in sorted(files)]
selfsize=0
for _ in range(30):
    allrows=sorted(rows+[{'path':str(audit.relative_to(R)),'bytes':selfsize,'sha256':None,'self_hash_note':'No recursive hash; covered by final Git object and external final receipt.','symlink':False}],key=lambda x:x['path'])
    total=sum(x['bytes'] for x in allrows)
    payload={'source_head':initial['head'],'scope':'Actual final disk including all stage7 docs and this audit; no build/extract/deploy called. Bytes exclude the not-generated new release manifest.','files_without_manifest':len(allrows),'files_with_manifest':len(allrows)+1,'bytes_without_manifest':total,'file_limit':p.MAX_FILES,'byte_limit':p.MAX_BYTES,'per_member_limit':1048576,'total_excess_bytes_before_manifest':max(0,total-p.MAX_BYTES),'count_exceeds_limit':len(allrows)+1>p.MAX_FILES,'oversized_members':[x for x in allrows if x['bytes']>1048576],'symlinks':[x['path'] for x in allrows if x['symlink']],'manifest_refreshed':False,'new_installer_generated':False,'builder_result':'RuntimeError: Curated source payload exceeds extractor bounds','payload':allrows}
    blob=(json.dumps(payload,ensure_ascii=False,indent=2)+'\n').encode()
    if len(blob)==selfsize:break
    selfsize=len(blob)
else:raise AssertionError('payload size fixed point did not converge')
audit.write_bytes(blob)
assert len(blob)==selfsize
assert sum((R/x['path']).stat().st_size for x in allrows)==total
try:p.names(R)
except RuntimeError as e:assert str(e)=='Curated source payload exceeds extractor bounds'
else:raise AssertionError('expected retained package failure was absent')
print(json.dumps({'delivery_checks':checks,'final_payload':{k:v for k,v in payload.items() if k!='payload'}},ensure_ascii=False))
