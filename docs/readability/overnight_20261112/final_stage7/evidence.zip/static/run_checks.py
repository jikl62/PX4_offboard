import concurrent.futures, hashlib, json, os, subprocess, time
from pathlib import Path
import yaml
ROOT = Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
CACHE = Path(__file__).resolve().parent
BASE = '5b86eeb4094ada009903c0140f66289cfe89411e'
paths = subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')[:-1]
changed = subprocess.check_output(['git','diff','--name-only',BASE,'HEAD'],cwd=ROOT,text=True).splitlines()
py = [p for p in paths if p.endswith('.py')]
syntax = []
for p in py:
    try:
        compile((ROOT/p).read_bytes(),str(ROOT/p),'exec')
        syntax.append({'path':p,'passed':True})
    except Exception as exc:
        syntax.append({'path':p,'passed':False,'error':repr(exc)})
yamls = []
for p in paths:
    if p.endswith(('.yaml','.yml')):
        try:
            value = yaml.safe_load((ROOT/p).read_text())
            yamls.append({'path':p,'passed':True,'root_type':type(value).__name__})
        except Exception as exc:
            yamls.append({'path':p,'passed':False,'error':repr(exc)})

def run(label,argv,env=None,timeout=180):
    start=time.monotonic()
    try:
        r=subprocess.run(argv,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
        blob=r.stdout
        row={'argv':argv,'returncode':r.returncode,'seconds':time.monotonic()-start}
    except subprocess.TimeoutExpired as exc:
        blob=exc.stdout or b''
        row={'argv':argv,'returncode':None,'timed_out':True,'seconds':time.monotonic()-start}
    (CACHE/(label+'.log')).write_bytes(blob)
    row.update(log=label+'.log',log_sha256=hashlib.sha256(blob).hexdigest())
    (CACHE/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
    return row
shell = [p for p in paths if p.endswith('.sh')]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    shells=list(pool.map(lambda p: dict(path=p,**run('bash_'+hashlib.sha256(p.encode()).hexdigest()[:12],['bash','-n',str(ROOT/p)])),shell))
format_env=dict(os.environ,PYTHONPATH='/home/jikl62/.cache/fc01-chinese-20261111/format_tools',PYTHONDONTWRITEBYTECODE='1')
formats=[]
formats.append(run('black_changed',['python3','-m','black','--check',*[p for p in changed if p.endswith('.py')]],format_env))
formats.append(run('clang_format_changed',['clang-format','--dry-run','--Werror',*[p for p in changed if p.endswith(('.cpp','.hpp'))]]))
formats.append(run('git_diff_check',['git','diff','--check',BASE,'HEAD']))
# These static tools inspect current production sources; their return code alone is not a completeness claim.
cpp=run('cppcheck',['cppcheck','--enable=warning,performance,portability','--inconclusive','--std=c++17','--language=c++','--inline-suppr','-j2','--xml','--xml-version=2','-I','native/src/jikl_fc01_system/include','native/src/jikl_fc01_system/src','native/src/jikl_fc01_system/include'])
cpp['internal_error_observed']='internalAstError' in (CACHE/'cppcheck.log').read_text()
probe=CACHE/'tsan_runtime_probe.cpp'
probe.write_text('#include <atomic>\n#include <thread>\nint main(){std::atomic<int> value{0};std::thread a([&]{for(int i=0;i<1000;++i)++value;});a.join();return value.load()==1000?0:1;}\n')
tsan=[run('tsan_compile',['g++','-std=c++17','-pthread','-fsanitize=thread','-fno-omit-frame-pointer',str(probe),'-o',str(CACHE/'tsan_runtime_probe')])]
if tsan[0]['returncode']==0:
    tsan.append(run('tsan_runtime',[str(CACHE/'tsan_runtime_probe')]))
result={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'python':syntax,'yaml':yamls,'shell':shells,'format':formats,'cppcheck':cpp,'tsan':tsan,'tsan_scope':'Minimal host runtime probe; not production coverage.','tools':{k:subprocess.run(v,capture_output=True,text=True).stdout.strip() for k,v in {'clang_format':['clang-format','--version'],'cppcheck':['cppcheck','--version'],'g++':['g++','--version']}.items()}}
(CACHE/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'python':len(py),'python_failed':sum(not x['passed'] for x in syntax),'yaml':len(yamls),'yaml_failed':sum(not x['passed'] for x in yamls),'bash':len(shells),'bash_failed':sum(x['returncode']!=0 for x in shells),'format_returncodes':[x['returncode'] for x in formats],'cppcheck':cpp,'tsan':[x['returncode'] for x in tsan]},ensure_ascii=False))
