#include <atomic>
#include <thread>
int main(){std::atomic<int> value{0};std::thread a([&]{for(int i=0;i<1000;++i)++value;});a.join();return value.load()==1000?0:1;}
