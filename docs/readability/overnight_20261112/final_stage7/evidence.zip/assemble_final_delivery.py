import collections,hashlib,json,shutil
from pathlib import Path
C=Path(__file__).resolve().parent
R=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
D=R/'docs/readability/overnight_20261112/final_stage7'
D.mkdir(exist_ok=True)
def get(p):return json.loads((C/p).read_text())
def write(n,d): (D/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
for p,n in [('readability/READABILITY_REVIEW_zh.md','READABILITY_REVIEW_zh.md'),('readability/final_file_index.tsv','file_index.tsv'),('behavior/REVIEW_zh.md','BEHAVIOR_REVIEW_zh.md'),('ros/REVIEW_zh.md','ROS_REVIEW_zh.md'),('root/changes_and_history.json','night_changes.json')]:
    shutil.copyfile(C/p,D/n)
a=get('root/git_integrity.json');s=get('static/checks.json');b=get('behavior/differential_summary.json');ros=get('ros/verification.json');san=get('behavior/sanitizers/summary.json');read=get('readability/final_readability_summary.json')
py=get('root/python_root.json');native=get('root/python_native.json')
write('verification.json',{
 'schema_version':1,'stage':7,'source_accepted_head':a['source_head'],'overnight_start':a['baseline'],'branch':a['branch'],
 'final_archive_commit':'Obtain with git log -1 --format=%H -- docs/readability/overnight_20261112/FINAL_REPORT_zh.md; self commit is not embedded recursively.',
 'stage7_production_changes':0,'all_528_initial_tracked_files_unchanged_before_new_docs':a['all_initial_tracked_files_unchanged'],
 'night_changes':{'files_before_stage7_docs':a['changes_count'],'categories':a['changes_by_category'],'commits_before_stage7_archive':a['commit_count'],'independent_fix_commits':12,'added_python_test_methods':sum(len(x['new_test_methods']) for x in get('root/new_tests.json')),'added_top_level_host_cpp_programs':2},
 'readability':read,
 'python_root':py,'python_native':native,'python_total':{'method_executions':py['tests_run']+native['tests_run'],'passed':py['passed_methods']+native['passed_methods'],'errors':len(py['errors'])+len(native['errors']),'failed':len(py['failures'])+len(native['failures']),'skipped':len(py['skips'])+len(native['skips'])},
 'host_cpp':{'current_program_count':82,'passed':True,'evidence':'root/python_root.log: NativeNavigationTests.test_cpp_regressions_and_rc_navigation passed; it executes tests/run_native_cpp.py and requires exit0. Each content-keyed program is actually run; successful child stdout captured by unittest, not printed.','included_in_python_root_aggregate':True,'no_extra_82_added_to_unittest_count':True},
 'fresh_night_baseline_differential':b,'asan_ubsan':{'programs':len(san['tests']),'runs_per_program':3,'successful':san['successful'],'details':'behavior/sanitizers/summary.json','leak_detection':True,'note':'Separate from regular82; not added to unittest totals.'},
 'fresh_ROS_Humble':ros,'static':{'python_compile_count':len(s['python']),'shell_parse_count':len(s['shell']),'yaml_parse_count':len(s['yaml']),'all_python_syntax_passed':all(x['passed'] for x in s['python']),'all_shell_syntax_passed':all(x['returncode']==0 for x in s['shell']),'all_yaml_parse_passed':all(x['passed'] for x in s['yaml']),'format_returncodes':[x['returncode'] for x in s['format']],'clang_analyzer':get('static/clang_analyze.json'),'cppcheck':s['cppcheck'],'tsan':s['tsan'],'meaning':'cppcheck internal AST error and TSan initialization failure are not passes.'},
 'packaging_before_stage7_docs':a['source_packaging_summary'],'packaging_after_stage7_docs':'See final_payload_audit.json for read-only final disk enumeration; no installer generated, no bounds altered.',
 'earlier_phase_evidence':a['phase_archives'],'protected_refs':a['protected_refs'],'all_protected_refs_unchanged':a['all_protected_refs_unchanged'],'baseline_is_ancestor':a['baseline_is_ancestor'],'merge_commits':a['merge_commits'],
 'candidates':{'P2':['C1 ground observation span','C2 per-poll IPC work/reply bound','C3 start poll-killpg race','C4 standby failed thread start/join'],'applied':False,'source':'../logic_stage6/candidate_index.json and evidence.zip','fresh_candidate_tests_in_stage7':False,'C2_final_candidate_burst_tested':False},
 'independent_changed_python_review':{'files':23,'AST_equal':14,'AST_changed':9,'result':'All changed hunks reviewed; no new flight permission finding; not a proof of unchanged lines.','evidence':'root/python_changes_independent_review.json'},
 'unresolved_release_blocker':'P2 packaging payload bounds; three errors retained.',
 'unreproduced_P3_lead':'Existing navigation_deploy.main prints after log creation and before try may raise BrokenPipeError before explicit close; static lead only, not confirmed failure.',
 'remaining_limits':['276 current readability candidates retain only byte/structure indexing in dedicated audit; cannot claim exhaustive semantic review.','No mathematical safety proof; finite synthetic traces and fake sinks.','No ARM64 build/performance, real PX4/DDS adoption, flight or real camera/SLAM validation.','R62 complete historical CSV replay remains unavailable.','Application budgets do not bound pre-callback DDS allocation.','TSan initialization unavailable; cppcheck incomplete.'],
 'network_push_merge_rebase_deploy_hardware':False,'visual_navigation_enabled':False,'velocity_command_is_read_only':True,
 'evidence':'evidence.zip and evidence_index.json; full original raw trace contents preserved once with exact SHA aliases for duplicate bytes. No binaries or build/install directories.'})
print(json.dumps({'directory':str(D),'files':[p.name for p in D.iterdir()]},ensure_ascii=False))
