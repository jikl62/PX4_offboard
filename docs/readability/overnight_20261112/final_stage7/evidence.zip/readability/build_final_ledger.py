"""只读生成第七阶段可读性证据；所有产物写入外部缓存。"""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
OUT = Path(__file__).parent
START = '5b86eeb4094ada009903c0140f66289cfe89411e'
HEAD = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
inv = json.loads((OUT / 'inventory_work.json').read_text())
fiches = {x['path']: x for x in json.loads((OUT / 'per_file_structure.json').read_text())}
metrics = json.loads((OUT / 'long_function_metrics.json').read_text())
PREFIX = 'native/src/jikl_fc01_system/include/jikl_fc01_system/'
full = {
 '.clang-format', '.gitignore', 'pyproject.toml', 'navigation_settings.json', 'vision_settings.json',
 'native/src/jikl_fc01_system/CMakeLists.txt', 'native/src/jikl_fc01_system/package.xml',
 'native/src/jikl_fc01_system/src/fc01_config_check.cpp', 'native/config/ground.yaml',
 'native/scripts/common.sh', 'native/scripts/install.sh', 'native/scripts/run.sh',
 'native/scripts/service.sh', 'native/scripts/test.sh',
} | {PREFIX + n + '.hpp' for n in [
 'vertical_controller','vertical_feedback_guard','publication_boundary','receive_events',
 'source_clock','vision_ros_adapter','vision_resource_budget','parent_lifetime',
 'discrete_event_latch','attitude_reference','attitude_diagnostics','attitude_wire','authority',
 'control_diagnostics','publication_audit',
]} | {'native/src/jikl_fc01_system/msg/' + n + '.msg' for n in [
 'VisionState','VisionHealth','NavigationCommand','VelocityCommand','AttitudeThrustPreview']}
key = {
 PREFIX+'attitude_types.hpp': [(1,160)],
 PREFIX+'attitude_altitude_core.hpp': [(1,25),(1130,1290),(2426,2446)],
 PREFIX+'runtime.hpp': [(1000,1175),(1318,1341)],
 PREFIX+'rc_navigation.hpp': [(1,160),(200,320)],
 'native/src/jikl_fc01_system/src/fc01_system_node.cpp': [(1,25),(380,535),(610,765),(1521,1590),(1955,1985),(2088,2116)],
 'native/tools/source_readability_audit.py': [(1,260)],
 'native/tools/vision_odometry_adapter.py': [(308,405),(815,952)],
 'native/tools/vision_state_validation.py': [(220,248),(620,655)],
 'native/tools/velocity_command_diagnostic.py': [(828,885),(965,1022)],
 'navigation_collect.py': [(430,565)],
 'navigation_deploy.py': [(65,145)],
 'navigation_probe.py': [(255,332)],
 'native/config/attitude_altitude.yaml': [(1,139)],
}
roles = {
 'async_log': '进程级标准流缓冲接管、有界日志队列和后台写入线程。',
 'attitude_altitude_core': '姿态定高任务的阶段、参考、垂向控制和恢复托管；只形成计划。',
 'attitude_types': '飞行动作门、物理参数、Feedback和Output数据合同。',
 'rc_navigation': '新地面证据、零预发送、人工解锁和导航开关边沿的准入状态机。',
 'runtime': 'IPC请求授权、路线选择、命令事务、Core调用和连续任务恢复。',
 'publication_boundary': '目标与心跳分别提交前重采上下文，记录非原子发布结果。',
 'publication_guard': '解锁/上锁/释放/降落/姿态输出的纯策略判定。',
 'vertical_controller': 'NED测量转上正高度/速度，执行外环和速度PI、限幅、抗积分饱和及slew。',
 'vertical_feedback_guard': '以新采样检查速度差诊断和z/z_deriv位置积分一致性，保留硬故障锁存。',
 'receive_events': '识别接收队列中必须先交控制步观察的离散、无效和跳变事件。',
 'receive_schedule': '控制ROS补读次数/时间及何时让出给控制步。',
 'source_clock': '同步源时钟、外壳戳、原始测量戳和单调接收进展的独立寿命检查。',
 'discrete_event_latch': '保留同轮危险和恢复事件FIFO，不让健康尾帧覆盖中间异常。',
 'vision_navigation': '旧NavigationCommand外环与VisionState缓存/时钟/来源检查。',
 'velocity_command_input': '新VelocityCommand的独立离线预览，不进入Runtime或PX4出口。',
 'vision_ros_adapter': '生成ROS消息到内部纯值的字段/版本/有效位适配。',
 'vision_resource_budget': '每身份字段256 UTF-8字节的应用层资源与编码预算。',
 'unix_server': '受路径租约约束的单客户端非阻塞IPC，负责连接、分帧、回复与断连。',
 'socket_lease': '使用文件锁保护合作启动器的控制socket命名空间。',
 'parent_lifetime': '配置父进程死亡信号并复查父PID竞态。',
 'authority': '有人RC或无RC自主合同的首错策略，不修改控制权。',
 'authority_telemetry': '从选中RC源和独立开关消息整理可接管事实，保留Kill观测。',
 'velocity_core': '保留的通用位置/速度路线，与当前人工RC姿态高度主链分开。',
 'fc01_system_node': 'ROS回调→快照→Runtime→最终发布→审计→下一任务准备的单线程适配主循环。',
 'fc01_config_check': '只读验证生产参数读取与人工解锁路线。',
}
notes = {
 'native/config/ground.yaml': '每项通用速度参数与正式1.5m姿态定高路线已经区分；部分相邻说明重复。',
 PREFIX+'vertical_controller.hpp': 'const引用、初始化列表、PI单位、NED正负、浮点顺序、试算积分与真实提交解释准确；不要求初学者自行推导抗饱和。',
 PREFIX+'vertical_feedback_guard.hpp': '梯形积分窗口、原始样本微秒与主机秒、重复样本早退、仅诊断速度差与硬故障路径已区分。',
 PREFIX+'publication_boundary.hpp': '转发引用、同步lambda、可空借用指针、真实本地提交和异常重抛说明准确；仍有相邻重复段。',
 PREFIX+'source_clock.hpp': '微秒源年龄与单调接收进展分别解释，uint64先减后转和因果水位饱和说明充分。',
 PREFIX+'receive_events.hpp': '事件谓词不是授权；允许忽略明确无效且不用的水平字段和保留健康恢复边沿均有说明，部分重复句可合并。',
 PREFIX+'vision_ros_adapter.hpp': '字段适配与坐标变换、NaN/有效位、实际速度与目标速度以及256字节资源预算均有明确边界。',
 PREFIX+'vision_resource_budget.hpp': 'string_view借用、noexcept、UTF-8字节预算与多字节解析逐项说明；空串是否合法仍交协议检查。',
 PREFIX+'discrete_event_latch.hpp': '借用指针寿命、健康尾帧不能清锁存、clear与acknowledge不同有解释；仍可补充deque分配异常边界。',
 PREFIX+'attitude_reference.hpp': 'optional、规范化容差、const借用与副本可写、yaw半角和活动reset拒绝说明明确。',
 PREFIX+'authority.hpp': '控制策略不是PX4模式；首错优先级、锁定、接管以及确认合同的区别解释准确。',
 PREFIX+'attitude_wire.hpp': 'pair中first/second和真实target先发布、double转float、FRD推力符号均有说明。',
 'native/tools/vision_odometry_adapter.py': '关键转换路径按坐标链、杆臂和速度语义分段，明确尚未输出转换后的协方差；清理按Node/Context/信号责任展开。',
 'native/tools/velocity_command_diagnostic.py': 'main说明了只读性质、两步构造、信号仅置位、清理顺序及构造基类中途失败的边界；嵌套类仍较长。',
 'native/tools/vision_state_validation.py': '协方差半正定检查的数值容差与实际允许不确定性已经区分；本模块是离线校验器，不等于真实ROS适配路径。',
 'navigation_collect.py': '样本接收时刻不冒充源同步；Node→自有Context的逐项释放与首错传播解释清楚，异常链算法仍需Python异常基础。',
 'navigation_deploy.py': '日志构造取得句柄后的责任与失败清理说明明确；异常链处理与多个工具重复，适合下轮有回归保护后共享。',
 'navigation_probe.py': '证据写入失败不跳过Node和自有Context清理，原始错误与次生清理错误的可见顺序有充分说明。',
}

def stripped_cpp(source):
 return re.sub(r'R"([^\s()]*)\([\s\S]*?\)\1"|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/',lambda m:re.sub(r'[^\n]',' ',m[0]),source)

def dense_cpp(source):
 result=[]; depth=0
 for line_no,line in enumerate(stripped_cpp(source).splitlines(),1):
  semicolons=0
  for ch in line:
   if ch=='(':depth+=1
   elif ch==')':depth=max(0,depth-1)
   elif ch==';' and depth==0:semicolons+=1
  if semicolons>=2:result.append(line_no)
 return result

rows=[]
changed=set(subprocess.check_output(['git','-C',str(ROOT),'diff',START,HEAD,'--name-only'],text=True).splitlines())
for e in inv['rows']:
 path=e['path'];data=(ROOT/path).read_bytes();source=data.decode();f= fiches.get(path,{})
 item={**e,'sha256':hashlib.sha256(data).hexdigest(),'changed_since_overnight_start':path in changed,
       'role_evidence':roles.get(Path(path).stem) or f.get('head_comment_or_docstring','').split('\n')[0][:260] or '职责需由下列结构/调用入口继续核对；路径不能替代人工语义审查。',
       'entry_structure':f.get('structure',[]),
       'long_functions':[m for m in metrics if m['path']==path],
       'compressed_statement_review_lines':dense_cpp(source) if e['language']=='cpp' else [],
       'line_length_review_lines':[i for i,s in enumerate(source.splitlines(),1) if len(s)>120],
       'confirmed_all_statements_beginner_explained':False,
       'independent_readability_status':'not_fully_reassessed',
       'review_depth':'automated_inventory_and_structure_only',
       'manually_inspected_line_ranges':[],
       'assessment': '已对当前字节建立路径、职责入口、结构和复杂度索引；未宣称每个分支均已独立读懂。',
       'outstanding_actions':[]}
 if e['category']!='active':
  item['review_depth']='provenance_and_sha_only'
  item['independent_readability_status']='historical_or_generated_preserved'
  item['assessment']='历史原字节/生成载荷单列保留，不计当前中文化完成数量。'
  item['outstanding_actions']=['保留历史字节；需要维护时修改实际生成输入/当前正向源码，不直接改历史证据。']
 elif path in full:
  item['review_depth']='full_file_manual_read'
  item['manually_inspected_line_ranges']=[[1,e['lines']]]
  item['independent_readability_status']='readable_at_reviewed_scope'
  item['assessment']=notes.get(path,'职责、输入输出及主要语法或配置语义可从当前局部注释和声明理解；本结论不是控制安全证明。')
 elif path in key:
  item['review_depth']='manual_key_flow_inspection'
  item['manually_inspected_line_ranges']=[list(x) for x in key[path]]
  item['independent_readability_status']='improved_but_guidance_or_structure_pending'
  item['assessment']=notes.get(path,'关键执行顺序/状态副作用已有业务中文说明；长流程仍需配合导读，未逐条复核全文件。')
 if e['category']=='active':
  if path.startswith(('tests/','native/tests/')):
   item['outstanding_actions'].append('结合具体测试入口核对夹具假设、合成/实测边界、时序与断言失败原因；入口索引不等于逐断言人工审查。')
  if item['long_functions']:
   item['outstanding_actions'].append('按long_functions所列行范围优先补执行路径图或窄纯函数；控制/浮点/发布时序改动须先有基线差分。')
  include_lines=[i for i,l in enumerate(source.splitlines(),1) if '#define main' in l or re.search(r'#include\s+".*\.cpp"',l)]
  if include_lines:
   item['cross_cpp_fixture_lines']=include_lines
   item['outstanding_actions'].append('宏重命名main再包含.cpp复用夹具仍耦合；后续提取无副作用公共支持头并验证所有依赖。')
  if item['compressed_statement_review_lines']:
   item['outstanding_actions'].append('复核compressed_statement_review_lines；分号压缩只是候选信号，不自动判定错误或允许重排。')
  if item['review_depth']=='automated_inventory_and_structure_only':
   item['outstanding_actions'].append('当前仅索引；后续逐分支独立核对中文注释与真实副作用、异常和资源归属，不能用既有自评替代。')
  if not item['outstanding_actions']:
   item['outstanding_actions']=['无本次样本中已确认的阻断性可读性问题；下一次业务改动同时更新相关中文解释。']
 rows.append(item)

source_rows=[r for r in rows if r['category']=='active']; current_head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
changed_hashes=[r['path'] for r in rows if hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()!=r['sha256']]
tracked_manifest=[]
for path in subprocess.check_output(['git','-C',str(ROOT),'ls-files','-z']).decode().strip('\0').split('\0'):
 tracked_manifest.append({'path':path,'sha256':hashlib.sha256((ROOT/path).read_bytes()).hexdigest(),'scope':'source_candidate' if any(r['path']==path for r in rows) else 'documentation_data_or_other'})
summary={'tracked_files':len(tracked_manifest),'all_source_configuration_metadata_candidates':len(rows),
 'current_scanner_source_count':316,'explicit_additional_metadata':7,'current_source_and_metadata_candidates':len(source_rows),
 'categories':dict(Counter(r['category'] for r in rows)),
 'current_languages':dict(Counter(r['language'] for r in source_rows)),
 'current_review_depths':dict(Counter(r['review_depth'] for r in source_rows)),
 'current_full_manual_file_count':sum(r['review_depth']=='full_file_manual_read' for r in source_rows),
 'current_key_flow_file_count':sum(r['review_depth']=='manual_key_flow_inspection' for r in source_rows),
 'all_files_fully_reassessed':False,
 'current_candidate_paths_changed_since_overnight_start':sum(r['changed_since_overnight_start'] for r in source_rows),
 'files_with_cross_cpp_fixture_include':sum(bool(r.get('cross_cpp_fixture_lines')) for r in source_rows),
 'files_with_compressed_statement_candidates':sum(bool(r['compressed_statement_review_lines']) for r in source_rows),
 'source_changed_during_audit':changed_hashes,'head_changed_during_audit':current_head!=HEAD}
ledger={'schema_version':1,'source_head':HEAD,'overnight_start':START,
 'quality_basis':'当前SHA256与职责/接口/单位/异常/所有权/执行顺序共同评估；不按汉字数量判完成。',
 'review_depth_definitions':{'full_file_manual_read':'本次人工读完该文件；仅可读性范围，不是穷尽正确性证明。','manual_key_flow_inspection':'人工核对列出的关键路径/范围，不能扩展为全文件全分支。','automated_inventory_and_structure_only':'扫描当前字节与结构、入口索引，尚未完成独立逐分支人工审查。','provenance_and_sha_only':'历史/生成类别的身份、来源和当前字节摘要。'},
 'summary':summary,'files':rows,'all_tracked_file_manifest':tracked_manifest,
 'all_source_criteria_met':False}
(OUT/'final_readability_ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
(OUT/'final_readability_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
with (OUT/'final_file_index.tsv').open('w') as output:
 output.write('path\tlanguage\tcategory\tlines\tsha256\treview_depth\tstatus\n')
 for r in rows:output.write('\t'.join(str(r[k]) for k in ['path','language','category','lines','sha256','review_depth','independent_readability_status'])+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
