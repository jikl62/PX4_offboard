# Stage 4 部署与构建证据审查记录

基线 f46468c21cac677dec0a3b300eb779de2fca44fd。实际功能修复由 root 独立审查后提交 d66b9057073b4fea82baefa7cf259ef2a9c7b12f；本代理没有提交、推送、部署或启停服务。

## 逐文件结论

- navigation_install.py：补20处中文合同及关键边界。解释旧source_key不能替代正式ARM64证据；staging有界复用、同用户flock、run注入、配置候选与现场runtime区别；所有拒绝与真正服务修改的前后关系。完整AST与d66b905相同。保留prepare/deploy长协调器，避免为短而短地移动地面复验和服务时序。旧rollback只凭marker判服务归属，本函数未重新确认旧配置动作门，注释不再把它升级成配置已验证保证。
- navigation_deploy.py：补11处中文合同，保留原docstring。解释只校验payload列举条目、原子文件可见性与fsync区别、候选YAML不写现场runtime、offline令牌失效顺序、在线事务锁由restore持有、日志返回/错误/关闭边界。完整AST与d66b905相同。DeploymentLog.step的18行只限制错误尾部缓存，完整日志仍可增长；terminate后的安全收尾依赖所选子程序本身，注释不作无限制保证。
- navigation_build_evidence.py：补19处原函数中文合同，新增纯_native_build_commands职责。保留commit声明与文件SHA的不同作用、依赖/环境覆盖、递归树链接/路径计数、ELF头/动态库/CMake的独立检查、复用拒绝与重建选择、链接和JSON非原子联合发布、文件锁与真正持有的区别。纯helper的返回AST与历史内联表达式完全相同，归一化后整文件AST相同（包含原docstrings）。
- tests/test_overnight_stage4_deployment.py：原5项独立资源归属回归；再加3项可读性差分，其中一个方法实际遍历8种协调器场景，不把子场景冒称独立测试。不会执行CMake/systemctl/Agent/控制器，只有Git只读导出历史源码和临时文件。

## P2 修复及真实复现

atomic_json和build_release安装软链原来在独占创建失败时仍finally unlink已有.tmp-PID或.install-new-PID。原版5项测试出现1FAIL/3ERROR，对应普通文件/symlink四种碰撞证据被误删；修复只在创建成功后允许清理，碰撞仍抛原FileExistsError，不重试、不覆盖。新增测试还确认自有临时项在replace或序列化失败后清理、同一注入OSError对象保留、原install与完整旧证据不变。修复后5/5及旧build13/13通过。

## 验证

最终针对性58/58，无跳过。含原install18、deploy5、build13、activation14和本阶段8项。保留原真实systemd-analyze verify静态检查；所有实际服务管理和构建工具由替身接管。Black与scoped git diff --check通过。安装/部署完整AST相同；构建除明确的纯参数提取外完整AST相同。确定性协调器比较新建、复用、三个命令阶段失败、输入变化、外来目录、外来链接的argv/kwargs、异常身份、stdout、证据返回值、文件字节、安装目标与残留路径，8种均相同。

## 环境、配置与生命周期边界

Humble/SDK缺失、工具/来源目录错误、架构不符、旧清单不符、编译期间输入变化、已有非托管安装路径都保留原拒绝机制；未修改CLI/字段/错误文本/配置参数。锁只约束遵守相同协议的调用者，文件fsync没有被写成目录断电持久性保证。真实ARM64/板上负载/ROS硬件行为不由host fixture证明。当前包仍有先前载荷预算/旧清单阻塞，未重建或宣称可部署安装包。

## 剩余债与未实施候选

1. 旧prepare/deploy与正式build_release仍承担多阶段协调；本轮只提取可独立验证的argv生成，不挪动关键时序。
2. 旧deploy中途失败可能保留已完成外部修改，完整补偿恢复依赖正式navigation_restore链；不是本轮新引入。
3. DeploymentLog.finish与install.boot的日志/handler关闭顺序存在清理动作本身失败后跳过后续动作的候选；未在本轮建立独立复现，因此不冒称已修复，也未改它们行为。
4. 资源归属修复证明本操作创建失败时不删旧临时项，不宣称已实现对抗同用户恶意替换路径的inode租约协议。

详细命令、结果与最终源码SHA见verification.json，原始日志同目录。
