# Stage 4 打包/历史自启入口只读补审

四文件与本阶段起点f46468c逐字节一致，SHA见readonly_packaging_review.json。未执行打包器、自解包器、真实服务命令或控制程序，未修改策略/预算/源码。

## 逐文件保留理由

- build_bundle.py：历史控制源包。显式源文件与测试/文档后缀规则、固定ZIP时间/权限、归档SHA、base64与原stdin转交已有中文说明。HEADER整体作为既有行为合同保留，嵌入的320文件/4MiB/每项1MiB拒绝规则不改；目标冲突先检查、已有相同文件复用、单文件fsync+link不覆盖。ZipFile上下文关闭压缩资源，BytesIO仅内存。正常构建只写指定输出，不自动运行载荷；默认运行生成安装器才会exec旧start入口，不能把构建与执行混称无副作用。
- build_autostart_bundle.py：17项显式NAMES避免任意工作目录进入包；复用HEADER时只替换目录/入口标识，固定ZIP时间/权限与SHA。它生成文件而不安装服务；运行生成包的默认动作与extract-only不同，保留现有区别。当前64行实现短、职责单一，无需再拆分。CLI保留sys.argv[1]历史合同，缺参数会产生IndexError，属于可改善的错误提示而非已证实飞控问题。
- build_navigation_bundle.py：正式源码包与历史包独立。names排除运行态文件/缓存/receive A-B实验，保护未提交和新文件也进入实际源码摘要；make_manifest不把Git身份声明当文件字节身份。既有清单不符明确拒绝；guard维持512文件/8MiB/每项1MiB，不能通过删历史证据或放宽预算掩盖当前超限。生成包的默认动作是offline；extract-only不执行部署。新目录用renameat2/RENAME_NOREPLACE一次发布，失败由自己stage的finally收尾；已有目录检查的是包中预期条目是否相同，额外运行态文件可以存在。不把“预期条目一致”误说成已审查所有额外文件。HEADER字符串整体不动，避免注释重排进入生成载荷。
- autostart.py：独立fc01-standby服务而非fc01-navigation服务；unit标记与路径校验防止覆盖外来服务。install先--validate环境/关闭动作门配置，install_service对相同unit仍daemon-reload和enable --now，重复操作没有restart/stop但可能启动已停止服务，这是CLI显式install的既有行为。无限优雅停止、KillMode=process、不发送SIGKILL保持。status/report只查询与读文件；report白名单、ZIP上下文与命令15秒超时已有说明。不能从active或末尾固定显示语句推断当前飞控状态。该历史接口不应替代正式导航激活的地面/构建/进程证据链。

## 可解释边界与待处理疑点

1. 已存在发行阻塞：正式源码总量/旧清单不满足验收，当前生成器拒绝是保护而非新缺陷。本补审未重新测量总量，没有冒称已得到新安装包。
2. P3/错误提示：build_autostart缺参数直接索引argv；导航make_manifest仅在git命令非零时返回None，git可执行文件不存在仍会OSError，现有“Git不可用保留None”中文表述偏宽。这里只读识别分支，未实施新修复。
3. P3/候选：autostart.status对JSON根类型、updated_unix及status/reason的异常类型覆盖不完整，畸形本地快照可能给出traceback；尚未针对这些分支建立本轮独立复现，不说已修复或影响控制。
4. 旧源包构建器/新源码包的输出文件与sidecar顺序写入，写盘失败可能留下部分输出；不具有“两文件原子提交”的合同。自解包器有SHA/CRC/路径检查，但不是任意时序、目录替换攻击或断电持久性的数学证明。
5. 历史autostart报告只限定文件白名单和命令显示尾部，没有正式navigation_report同等的全报告字节预算。当前未修改包策略或报告规则。

## 报告组的只读交叉审查

_record_status_identity(capture,initial)仅把原json解码、session/native_state选字段块移动为纯内存辅助函数；capture仍是相同对象、顺序相同，返回同一row。没有读文件/查询服务/控制授权。无效JSON/Unicode或非字典仍回落空观测，其余异常继续传播到原ZIP上下文完成关闭。新测试把helper原块内联后验证整个AST（含原docstrings）相同，同时比较只读命令、归档成员顺序与实际字节、原异常身份、输出流关闭。独立执行ReportReadabilityEquivalenceTests四方法，4/4通过，无跳过（0.039秒）；未重跑全量。
