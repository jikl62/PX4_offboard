"""Immutable Stage4 baseline versus current nine deterministic host traces."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
CACHE=Path(__file__).resolve().parent
BASELINE='f46468c21cac677dec0a3b300eb779de2fca44fd'
folder=CACHE/'current_baseline_traces'
folder.mkdir(exist_ok=False)
baseline=folder/'baseline'
baseline.mkdir()
raw=subprocess.check_output(['git','archive',BASELINE],cwd=ROOT)
with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
    for m in archive.getmembers():
        if m.name.startswith('/') or '..' in Path(m.name).parts:
            raise RuntimeError('unsafe archive path')
    archive.extractall(baseline)
# Existing driver's marker is only the fixture ownership schema, not source identity.
(folder/'.fc01-stage2-python').write_text('5198d33f25aaaf2abc7e4b078169ae84d5c4b2c4\n')
driver=ROOT/'tests/stage2_python_trace.py'
results=[]
for scenario in ('render','report','service','activation','standby','launcher','launcher_entry','fcctl','probe'):
    streams=[]
    commands=[]
    for label,root in (('baseline',baseline),('current',ROOT)):
        cmd=[sys.executable,str(driver),str(root),str(folder/'fixture'),scenario]
        if scenario=='probe':
            # Both source trees already contain the Stage3 disk-full cleanup repair.
            cmd.append('--probe-cleanup-fixed')
        result=subprocess.run(cmd,cwd=ROOT,capture_output=True,timeout=30)
        (folder/(scenario+'-'+label+'.json')).write_bytes(result.stdout)
        (folder/(scenario+'-'+label+'.stderr')).write_bytes(result.stderr)
        commands.append({'argv':cmd,'exit':result.returncode})
        if result.returncode:
            raise RuntimeError(scenario+' '+label+': '+result.stderr.decode(errors='replace'))
        json.loads(result.stdout)
        streams.append(result.stdout)
    row={'scenario':scenario,'equal_bytes':streams[0]==streams[1],
         'bytes':list(map(len,streams)),
         'sha256':[hashlib.sha256(s).hexdigest() for s in streams], 'commands':commands}
    results.append(row)
    print(scenario+': '+('equal' if row['equal_bytes'] else 'DIFFERENT'),flush=True)
summary={'baseline':BASELINE,'baseline_archive_sha256':hashlib.sha256(raw).hexdigest(),
         'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),
         'normalization':'none beyond the existing driver; exact canonical JSON stdout bytes',
         'probe_both_cleanup_fixed':True,'trace_driver_fixture_marker':'legacy ownership schema only; actual source is Git archive above',
         'scenarios':results,'all_equal':all(r['equal_bytes'] for r in results)}
(CACHE/'current_baseline_traces.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
sys.exit(0 if summary['all_equal'] else 1)
