import ast
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
CACHE=Path(__file__).resolve().parent
initial=json.loads((CACHE/'initial.json').read_text())
base=initial['head']
changed=subprocess.check_output(['git','diff','--name-only',base],cwd=ROOT,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
files=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
python_files=sorted({p for p in files+untracked if p.endswith('.py') and (ROOT/p).is_file()})
compiled=[]
for path in python_files:
    compile((ROOT/path).read_bytes(),str(ROOT/path),'exec')
    compiled.append(path)
checks=[]
for path in changed+untracked:
    if not path.endswith('.py') or path.startswith('tests/'):
        continue
    original=base
    if path=='feedback_age_probe.py': original='c666d7797c216a60b8c2bc031ec77ae1aa89fadc'
    if path in ('launcher.py','navigation_build_evidence.py','navigation_report.py'): continue
    before=subprocess.check_output(['git','show',original+':'+path],cwd=ROOT)
    after=(ROOT/path).read_bytes()
    checks.append({'path':path,'baseline':original,'complete_ast_equal':ast.dump(ast.parse(before))==ast.dump(ast.parse(after)),
                   'sha256':hashlib.sha256(after).hexdigest()})
protected={p:s for p,s in initial['sha256'].items() if p.startswith('dist/') or p.startswith('native/config/') or p.endswith(('.cpp','.hpp','.h','.msg','.sh')) or p in ('FC01_RELEASE.json','navigation_settings.json','vision_settings.json') or Path(p).name in ('CMakeLists.txt','package.xml')}
protection=[{'path':p,'sha256':s,'unchanged':(ROOT/p).is_file() and hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==s} for p,s in protected.items()]
old_refs={line.split(' ',1)[1]:line.split(' ',1)[0] for line in initial['refs'] if line.split(' ',1)[1].startswith(('refs/heads/','refs/remotes/')) and line.split(' ',1)[1]!='refs/heads/'+initial['branch']}
current_refs=dict((line.split(' ',1)[1],line.split(' ',1)[0]) for line in subprocess.check_output(['git','show-ref'],cwd=ROOT,text=True).splitlines())
refs_equal=all(current_refs.get(ref)==sha for ref,sha in old_refs.items())
result={'baseline':base,'compiled_python_count':len(compiled),'compiled_python':compiled,
        'python_complete_ast_checks':checks,'all_complete_ast_equal':all(c['complete_ast_equal'] for c in checks),
        'helper_extractions_checked_by':['test_overnight_stage4_deployment','test_overnight_stage4_launcher_readability','test_overnight_stage4_reporting'],
        'protected_file_count':len(protection),'protected_files':protection,'all_protected_bytes_equal':all(c['unchanged'] for c in protection),
        'other_local_heads_and_remote_tracking_refs_unchanged':refs_equal,'preserved_refs':old_refs,
        'changed_python':sorted(p for p in changed+untracked if p.endswith('.py')),
        'unchanged_critical_source':['navigation_service.py','navigation_restore.py','standby.py'],
        'critical_source_equal':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==initial['sha256'][p] for p in ['navigation_service.py','navigation_restore.py','standby.py']}}
(CACHE/'static_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
command=['python3','-m','black','--check']+result['changed_python']
env=__import__('os').environ.copy();env['PYTHONPATH']='/home/jikl62/.cache/fc01-chinese-20261111/format_tools'
r=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,env=env)
(CACHE/'format_final.log').write_text('command: '+repr(command)+'\n'+r.stdout+r.stderr)
result['black_check_exit']=r.returncode
r=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True,text=True)
(CACHE/'diff_check_final.log').write_text(r.stdout+r.stderr)
result['diff_check_exit']=r.returncode
(CACHE/'static_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('compiled_python_count','protected_file_count','all_complete_ast_equal','all_protected_bytes_equal','other_local_heads_and_remote_tracking_refs_unchanged','black_check_exit','diff_check_exit')}))
assert result['all_complete_ast_equal'] and result['all_protected_bytes_equal'] and refs_equal and not r.returncode and not result['black_check_exit']
