"""Stage4 host-only regression wrapper; no device or real management commands."""
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest

ROOT = Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
CACHE = Path(__file__).resolve().parent
SUITES = {
    'targeted': ['test_overnight_stage4_deployment', 'test_overnight_stage4_launcher_resources',
                 'test_overnight_stage4_launcher_readability', 'test_overnight_stage4_reporting',
                 'test_overnight_stage4_tools', 'test_feedback_age_probe', 'test_launcher'],
    'root': None,
    'native': None,
}
name = sys.argv[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
folder = ROOT / ('native/tests' if name == 'native' else 'tests')
sys.path.insert(0, str(folder))
paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
paths += [str(p.relative_to(ROOT)) for p in (ROOT/'tests').glob('test_overnight_stage4*.py')]
manifest = {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
            for p in sorted(set(paths)) if p.endswith('.py') and (ROOT/p).is_file()}
(CACHE/(name+'_tested_sources.json')).write_text(json.dumps(manifest, indent=2)+'\n')
loader = unittest.TestLoader()
suite = loader.loadTestsFromNames(SUITES[name]) if SUITES[name] else loader.discover(str(folder), pattern='test_*.py')
start=time.monotonic()
with (CACHE/(name+'_final.log')).open('w') as log:
    log.write('command: python3 '+str(Path(__file__).resolve())+' '+name+'\n')
    log.flush()
    runner=unittest.TextTestRunner(stream=log, verbosity=2)
    result=runner.run(suite)
summary = {
    'suite':name, 'duration_seconds':time.monotonic()-start, 'test_methods': result.testsRun,
    'failures': [{'test':str(t),'traceback':detail} for t,detail in result.failures],
    'errors':[{'test':str(t),'traceback':detail} for t,detail in result.errors],
    'skipped':[[str(t),why] for t,why in result.skipped],
    'expected_failures':len(result.expectedFailures), 'unexpected_successes':len(result.unexpectedSuccesses),
    'success':result.wasSuccessful(),
    'unchanged_tested_python_sources': all((ROOT/p).is_file() and hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==sha for p,sha in manifest.items()),
}
(CACHE/(name+'_final.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v if k not in ('failures','errors','skipped') else len(v) for k,v in summary.items()},ensure_ascii=False))
sys.exit(0 if result.wasSuccessful() else 1)
