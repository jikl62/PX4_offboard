"""复用Git中已审查的驱动，只把不可变比较基线切为本阶段初始提交。"""
from pathlib import Path
import json,os,sys,time,unittest
ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
CACHE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tests'))
import test_stage3_control_equivalence as existing
existing.BASELINE='5b86eeb4094ada009903c0140f66289cfe89411e'
os.environ['FC01_STAGE3_TRACE_DIR']=str(CACHE/'traces')
loader=unittest.TestLoader()
suite=unittest.TestSuite([loader.loadTestsFromTestCase(existing.Stage3CoreEquivalenceTests),loader.loadTestsFromTestCase(existing.Stage3PoweredNodeEquivalenceTests)])
started=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(suite)
(CACHE/'dynamic_result.json').write_text(json.dumps({'baseline':existing.BASELINE,'test_methods':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'passed':result.wasSuccessful(),'seconds':time.monotonic()-started,'drivers_unchanged':True,'scope':'Pure host Core, Runtime and production SystemNode with fake ROS and sinks; no flight or real node.'},indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() else 1)
