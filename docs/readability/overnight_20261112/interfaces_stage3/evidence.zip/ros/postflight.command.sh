set -eo pipefail
source /opt/ros/humble/setup.bash
source /home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs/share/px4_msgs/local_setup.bash
source /home/jikl62/.cache/fc01-interfaces-stage3-irwed8ap/ros/install/setup.bash
export PYTHONDONTWRITEBYTECODE=1
export ROS_LOCALHOST_ONLY=1
unset ROS_DISCOVERY_SERVER CYCLONEDDS_URI FASTRTPS_DEFAULT_PROFILES_FILE FASTDDS_DEFAULT_PROFILES_FILE RMW_FASTRTPS_USE_QOS_FROM_XML ROS_STATIC_PEERS
export ROS_DOMAIN_ID=218
/usr/bin/python3 /home/jikl62/.cache/fc01-interfaces-stage3-irwed8ap/ros/preflight_domain.py /home/jikl62/.cache/fc01-interfaces-stage3-irwed8ap/ros/vision_domain_postflight.json
export ROS_DOMAIN_ID=219
/usr/bin/python3 /home/jikl62/.cache/fc01-interfaces-stage3-irwed8ap/ros/preflight_domain.py /home/jikl62/.cache/fc01-interfaces-stage3-irwed8ap/ros/velocity_domain_postflight.json
/usr/bin/python3 - <<'IDENTITY'
from pathlib import Path
import json
import os
import platform
import rclpy
import sys
import px4_msgs
import jikl_fc01_system.msg._velocity_command as velocity_command
result = {'ros_distro':os.environ.get('ROS_DISTRO'), 'python':sys.version, 'architecture':platform.machine(), 'rclpy_file':rclpy.__file__, 'px4_msgs_file':px4_msgs.__file__, 'generated_velocity_message_file':velocity_command.__file__}
Path('/home/jikl62/.cache/fc01-interfaces-stage3-irwed8ap/ros/runtime_identity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
IDENTITY
