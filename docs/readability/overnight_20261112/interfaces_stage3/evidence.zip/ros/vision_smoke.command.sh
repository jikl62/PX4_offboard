set -eo pipefail
source /opt/ros/humble/setup.bash
source /home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs/share/px4_msgs/local_setup.bash
source /home/jikl62/.cache/fc01-interfaces-stage3-irwed8ap/ros/install/setup.bash
export PYTHONDONTWRITEBYTECODE=1
export ROS_LOCALHOST_ONLY=1
unset ROS_DISCOVERY_SERVER CYCLONEDDS_URI FASTRTPS_DEFAULT_PROFILES_FILE FASTDDS_DEFAULT_PROFILES_FILE RMW_FASTRTPS_USE_QOS_FROM_XML ROS_STATIC_PEERS
export ROS_DOMAIN_ID=218
/usr/bin/python3 /home/jikl62/.cache/fc01-interfaces-stage3-irwed8ap/ros/preflight_domain.py /home/jikl62/.cache/fc01-interfaces-stage3-irwed8ap/ros/vision_domain_preflight.json
/usr/bin/python3 /home/jikl62/FC01_OrangePi_Navigation_20261028/tests/ros_vision_smoke.py --check-resource-budget --report /home/jikl62/.cache/fc01-interfaces-stage3-irwed8ap/ros/vision_smoke.report.json
