from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028');CACHE=Path(__file__).resolve().parent;out=CACHE/'sanitizers';out.mkdir(exist_ok=True)
results=[]
for name in ['test_rc_navigation','test_vertical_integral_reversal','test_vertical_feedback_regression','test_stage3_publication_combinations','test_stage3_state_invariants']:
 source=ROOT/'native/tests'/(name+'.cpp');binary=out/name
 command=['g++','-std=c++17','-O1','-g','-fno-omit-frame-pointer','-fno-pie','-no-pie','-fsanitize=address,undefined','-Wall','-Wextra','-Werror','-pedantic','-pthread','-I',str(ROOT/'native/src/jikl_fc01_system/include'),str(source),'-o',str(binary)]
 started=time.monotonic()
 with (out/(name+'.build.log')).open('w') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 item={'name':name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'compile_command':command,'compile_exit':p.returncode}
 if not p.returncode:
  env={**os.environ,'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
  with (out/(name+'.run.log')).open('w') as log:run=subprocess.run([str(binary)],stdout=log,stderr=subprocess.STDOUT,env=env,timeout=60)
  item.update(run_exit=run.returncode,ASAN_OPTIONS=env['ASAN_OPTIONS'],UBSAN_OPTIONS=env['UBSAN_OPTIONS'])
 item['seconds']=time.monotonic()-started;results.append(item)
 (CACHE/'sanitizers_result.json').write_text(json.dumps(results,indent=2)+'\n')
 if p.returncode or item.get('run_exit')!=0:sys.exit(1)
