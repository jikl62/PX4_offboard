from pathlib import Path
import ast,hashlib,json,shutil,subprocess,sys
ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
CACHE=Path(__file__).resolve().parent
BASELINE='d8d14ff30be6bc89dce805205f6489795a5efa5e'
sys.path.insert(0,str(ROOT/'tests'))
import readability_equivalence as check
baseline,identity=check.git_baseline(ROOT,BASELINE)
changed=[name for name,value in baseline.items() if not (ROOT/name).exists() or (ROOT/name).read_bytes()!=value.data]
exceptions={
 'native/scripts/test.sh':'OVN-01: per-test fault injection link flags; functional commit 59c49b2',
 'native/scripts/r62_cpp_regressions.sh':'OVN-01: per-test fault injection link flags; functional commit 59c49b2',
 'native/tools/velocity_command_diagnostic.py':'OVN-08: explicit resources and exception propagation; functional commit 8d2bfd8; comments compared separately',
 'navigation_service.py':'named profile factory, normalized AST and deterministic differential tests'
}
selected={name:{} for name in changed if name not in exceptions}
report=check.compare(ROOT,baseline,clang=shutil.which('clang++'),inventory=selected)
report['baseline']=identity
report['intentional_exclusions']=exceptions
report['unchanged_baseline_files_bytes_equal']=len(baseline)-len(changed)
report['changed_existing_files']=changed
fixed,_=check.git_baseline(ROOT,'8d2bfd8')
report['diagnostic_readability_after_fix']=check.compare(ROOT,fixed,clang=shutil.which('clang++'),inventory={'native/tools/velocity_command_diagnostic.py':{}})
cpp=[name for name in selected if name.endswith('.hpp')]
report['cpp_token_counts']={name:len(check.cpp_structure((ROOT/name).read_bytes(),shutil.which('clang++'))) for name in cpp}
msgs=[name for name in selected if name.endswith('.msg')]
report['message_declaration_counts']={name:len(check.message_structure((ROOT/name).read_text())) for name in msgs}
guards=['native/config/','dist/']
report['protected_guards']={prefix:all((ROOT/name).read_bytes()==item.data for name,item in baseline.items() if name.startswith(prefix)) for prefix in guards}
report['release_manifest_bytes_equal']=(ROOT/'FC01_RELEASE.json').read_bytes()==baseline['FC01_RELEASE.json'].data
report['initial_core_stage_files_changed']=[name for name in changed if name.endswith(('runtime.hpp','attitude_altitude_core.hpp','rc_navigation.hpp','vertical_controller.hpp','vertical_feedback_guard.hpp','attitude_types.hpp','fc01_system_node.cpp','receive_events.hpp','publication_boundary.hpp','discrete_event_latch.hpp'))]
report['passed']=report['passed'] and report['diagnostic_readability_after_fix']['passed'] and all(report['protected_guards'].values()) and report['release_manifest_bytes_equal'] and not report['initial_core_stage_files_changed']
(CACHE/'structure_result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({key:report[key] for key in ['passed','checked_files','counts','errors','unchanged_baseline_files_bytes_equal','protected_guards','initial_core_stage_files_changed']},indent=2))
sys.exit(0 if report['passed'] else 1)
