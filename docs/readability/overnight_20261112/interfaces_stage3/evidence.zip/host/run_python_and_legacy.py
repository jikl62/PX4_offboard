from pathlib import Path
import json,os,subprocess,sys,time
ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
CACHE=Path(__file__).resolve().parent
commands=[('python-full',[sys.executable,'-m','unittest','discover','-s','tests','-p','test_*.py','-v']),('legacy-native-runner',['bash','native/scripts/test.sh'])]
results=[]
for label,command in commands:
    start=time.monotonic()
    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
    with (CACHE/(label+'.log')).open('w') as output:
        result=subprocess.run(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
    results.append(dict(label=label,command=command,exit=result.returncode,seconds=time.monotonic()-start,log=label+'.log'))
    (CACHE/'python_legacy_result.json').write_text(json.dumps(results,indent=2)+'\n')
    if result.returncode:sys.exit(result.returncode)
