from pathlib import Path
import json,subprocess,time,sys
ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028');CACHE=Path(__file__).resolve().parent
commands=[('cmake-configure',['cmake','-S',str(ROOT/'native/tests'),'-B',str(CACHE/'ctest-build'),'-DCMAKE_BUILD_TYPE=Debug']),('cmake-build',['cmake','--build',str(CACHE/'ctest-build'),'-j2']),('ctest',['ctest','--test-dir',str(CACHE/'ctest-build'),'--output-on-failure','-j2','--output-junit',str(CACHE/'ctest-junit.xml')])]
results=[]
for label,command in commands:
 start=time.monotonic()
 with (CACHE/(label+'.log')).open('w') as output:p=subprocess.run(command,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT)
 results.append({'label':label,'command':command,'exit':p.returncode,'seconds':time.monotonic()-start,'log':label+'.log'})
 (CACHE/'host_tests_result.json').write_text(json.dumps(results,indent=2)+'\n')
 if p.returncode:sys.exit(p.returncode)
